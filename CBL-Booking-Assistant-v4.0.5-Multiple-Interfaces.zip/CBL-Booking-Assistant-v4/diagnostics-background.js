"use strict";

// A persistent single writer for metadata-only troubleshooting. This module does
// not read bodies, cookies, headers, page HTML or any account information.
(() => {
  if (!globalThis.CBLDiagnostic) importScripts("diagnostic.js");
  const { sanitize, STORAGE_KEY, MAX_ENTRIES, MAX_BYTES } = CBLDiagnostic;
  const META_KEY = "cblDiagnosticMeta";
  const MAX_EVENT_BYTES = 64 * 1024;
  const FLUSH_DELAY = 150;
  let entries = [];
  let entryBytes = [];
  let retainedBytes = 2;
  let enabled = false;
  let dirty = false;
  let flushTimer = null;
  let queue = Promise.resolve();
  let lastError = "";
  let meta = { startedAt: null, lastEventAt: null, updatedAt: null, droppedCount: 0, recordedCount: 0 };

  function bytes(value) { return new TextEncoder().encode(JSON.stringify(value)).byteLength; }
  function enqueue(operation) {
    const result = queue.then(operation);
    queue = result.catch(() => {});
    return result;
  }
  function resetTimer() { clearTimeout(flushTimer); flushTimer = null; }
  function finiteNumber(value, fallback = 0) { const number = Number(value); return Number.isFinite(number) && number >= 0 ? number : fallback; }
  function timeValue(value, fallback = Date.now()) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 && number <= Date.now() + 60000 ? number : fallback;
  }
  function iso(value) { return new Date(value).toISOString(); }
  function eventValue(event, tabId = null) {
    if (!event || typeof event !== "object" || Array.isArray(event)) return null;
    const ts = timeValue(event.ts ?? Date.parse(event.time));
    const output = {
      time: iso(ts), ts,
      category: sanitize(String(event.category || "INFO")).slice(0, 80),
      message: sanitize(String(event.message || "")).slice(0, 1200),
      data: sanitize(event.data ?? null),
      source: Number.isInteger(tabId) && tabId >= 0 ? "tab" : "background",
      tabId: Number.isInteger(tabId) && tabId >= 0 ? tabId : null
    };
    if (bytes(output) > MAX_EVENT_BYTES) output.data = { truncated: true, reason: "Event exceeded the safe size limit" };
    return output;
  }
  function append(entry, count = true) {
    const size = bytes(entry);
    entries.push(entry);
    entryBytes.push(size);
    retainedBytes += size + (entries.length > 1 ? 1 : 0);
    if (count) {
      meta.recordedCount++;
      if (!meta.startedAt) meta.startedAt = entry.time;
      meta.lastEventAt = entry.time;
    }
    while (entries.length > MAX_ENTRIES || retainedBytes > MAX_BYTES) {
      entries.shift();
      retainedBytes -= entryBytes.shift() + (entries.length > 0 ? 1 : 0);
      meta.droppedCount++;
    }
  }

  const initialization = (async () => {
    const stored = await chrome.storage.local.get(["bookingSettings", STORAGE_KEY, META_KEY]);
    enabled = stored.bookingSettings?.diagnosticsEnabled === true;
    const previousMeta = stored[META_KEY] || {};
    meta.recordedCount = finiteNumber(previousMeta.recordedCount);
    meta.droppedCount = finiteNumber(previousMeta.droppedCount);
    for (const key of ["startedAt", "lastEventAt", "updatedAt"]) {
      const value = previousMeta[key];
      if (typeof value === "string" && Number.isFinite(Date.parse(value))) meta[key] = iso(Date.parse(value));
    }
    const legacy = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
    for (const value of legacy) {
      const entry = eventValue(value, value?.source === "tab" ? value.tabId : null);
      if (entry) append(entry, false);
    }
    meta.recordedCount = Math.max(meta.recordedCount, legacy.length);
    if (entries.length) {
      meta.startedAt ||= entries[0].time;
      meta.lastEventAt ||= entries[entries.length - 1].time;
    }
    // Migrate legacy logs once so old plaintext account data is not retained.
    if (legacy.length) { dirty = true; await persist(); }
  })();
  queue = initialization.catch(() => {});

  async function ready() { await initialization; }
  async function persist() {
    if (!dirty) return;
    const updatedAt = iso(Date.now());
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: entries, [META_KEY]: { ...meta, updatedAt, retainedBytes } });
      meta.updatedAt = updatedAt;
      dirty = false;
      lastError = "";
    } catch (error) {
      lastError = sanitize(String(error?.message || "Storage write failed"));
      throw error;
    }
  }
  function scheduleFlush() {
    if (!enabled || flushTimer) return;
    flushTimer = setTimeout(() => { flushTimer = null; api.flush().catch(() => {}); }, FLUSH_DELAY);
  }
  function currentStatus() {
    return { enabled, entryCount: entries.length, retainedBytes, maxEntries: MAX_ENTRIES, maxBytes: MAX_BYTES, droppedCount: meta.droppedCount, recordedCount: meta.recordedCount, startedAt: meta.startedAt, lastEventAt: meta.lastEventAt, updatedAt: meta.updatedAt, pendingWrite: dirty, lastError };
  }
  function snapshot(settings = {}, runtime = {}) {
    const safeSettings = {};
    for (const key of ["enabled", "diagnosticsEnabled", "autoConfirm", "recoveryEnabled", "performanceMode", "autoResumeAfterRateLimit", "waitForTargetBranch", "notifications", "sound", "pageNotifications"]) if (typeof settings[key] === "boolean") safeSettings[key] = settings[key];
    for (const key of ["companyResponseSeconds", "refreshSeconds", "companyAttempts", "companySkipCount", "branchRefreshSeconds"]) if (typeof settings[key] === "number" && Number.isFinite(settings[key])) safeSettings[key] = settings[key];
    if (["cash", "card"].includes(settings.bookingMode)) safeSettings.bookingMode = settings.bookingMode;
    if (["first_available", "random_from_5", "specific", "disabled"].includes(settings.companyMode)) safeSettings.companyMode = settings.companyMode;
    if (typeof settings.selectedBranchId === "string" && /^[a-z0-9_-]{1,100}$/i.test(settings.selectedBranchId)) safeSettings.selectedBranchId=globalThis.CBLDiagnostic.sanitize(settings.selectedBranchId);
    const safeRuntime = {};
    if (["idle", "running", "opening", "company", "branch", "branch_wait", "confirm", "confirm_pending", "branch_selected", "confirming", "success", "completed", "cooldown", "error", "stopped", "manual"].includes(runtime.phase)) safeRuntime.phase = runtime.phase;
    for (const key of ["ownerTabId", "startedAt", "nextRefreshAt", "cooldownUntil", "rateLimitCount", "updatedAt"]) if (typeof runtime[key] === "number" && Number.isFinite(runtime[key])) safeRuntime[key] = runtime[key];
    if (typeof runtime.errorCode === "string" && /^[A-Z0-9_:-]{0,80}$/.test(runtime.errorCode)) safeRuntime.errorCode = runtime.errorCode;
    return { settings: safeSettings, runtime: safeRuntime };
  }

  const api = {
    async record(category, message, data = null, tabId = null) {
      return api.recordBatch([{ ts: Date.now(), category, message, data }], tabId);
    },
    recordBatch(events, tabId = null) {
      return enqueue(async () => {
        await ready();
        if (!enabled || !Array.isArray(events)) return { accepted: 0, enabled };
        let accepted = 0;
        const batch = events.slice(0, 1000);
        for (const event of batch) {
          const entry = eventValue(event, tabId);
          if (!entry) continue;
          append(entry);
          if (entry.category === "DIAGNOSTIC_BUFFER") meta.droppedCount += finiteNumber(entry.data?.dropped);
          accepted++;
        }
        if (events.length > batch.length) meta.droppedCount += events.length - batch.length;
        if (accepted || events.length > batch.length) { dirty = true; scheduleFlush(); }
        return { accepted, enabled, entryCount: entries.length };
      });
    },
    flush() { resetTimer(); return enqueue(async () => { await ready(); await persist(); return currentStatus(); }); },
    clear() {
      resetTimer();
      return enqueue(async () => {
        await ready();
        entries = []; entryBytes = []; retainedBytes = 2;
        meta = { startedAt: null, lastEventAt: null, updatedAt: null, droppedCount: 0, recordedCount: 0 };
        dirty = true;
        await persist();
        return currentStatus();
      });
    },
    status() { return enqueue(async () => { await ready(); return currentStatus(); }); },
    exportReport() {
      resetTimer();
      return enqueue(async () => {
        await ready();
        await persist();
        const stored = await chrome.storage.local.get(["bookingSettings", "bookingRuntime"]);
        const manifest = chrome.runtime.getManifest?.() || {};
        const safeEntries = entries.map(entry => eventValue(entry, entry.source === "tab" ? entry.tabId : null));
        const categoryCounts = Object.create(null);
        for (const entry of safeEntries) categoryCounts[entry.category] = (categoryCounts[entry.category] || 0) + 1;
        return {
          schemaVersion: 1, extensionVersion: chrome.runtime.getManifest?.().version || "4.0.5", generatedAt: iso(Date.now()), displayTimezone:"Africa/Tripoli",
          environment: { manifestVersion: Number(manifest.manifest_version) || 3, minimumChromeVersion: /^\d+(?:\.\d+)*$/.test(manifest.minimum_chrome_version || "") ? manifest.minimum_chrome_version : "109", platformOrigin: "https://fcms.cbl.gov.ly" },
          recording: currentStatus(),
          retention: { strategy: "Keep newest entries; discard oldest on entry or byte limit", maxEntries: MAX_ENTRIES, maxBytes: MAX_BYTES, droppedCount: meta.droppedCount, oldestRetainedAt: safeEntries[0]?.time || null, newestRetainedAt: safeEntries[safeEntries.length - 1]?.time || null },
          counts: { recorded: meta.recordedCount, retained: safeEntries.length, dropped: meta.droppedCount, byCategory: categoryCounts },
          privacy: { sanitized: true, excluded: ["request/response bodies", "authentication headers", "cookies", "page HTML", "account details", "personal names", "email addresses", "URL query values and fragments"], note: "Review the report before sharing; collection is limited to extension events and network metadata." },
          context: snapshot(stored.bookingSettings, stored.bookingRuntime),
          entries: safeEntries
        };
      });
    }
  };

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.bookingSettings) return;
    const nextEnabled = changes.bookingSettings.newValue?.diagnosticsEnabled === true;
    enqueue(async () => {
      await ready();
      enabled = nextEnabled;
      if (!enabled) { resetTimer(); await persist(); }
    }).catch(() => {});
  });
  globalThis.CBLDiagnostics = Object.freeze(api);
})();
