"use strict";
globalThis.CBLTrial = (() => {
  const KEY = "cblTrialUiOptions";
  const interfaces = Object.freeze({circular:"دائري",compact:"مدمج",capsule:"كبسولة",ios:"آيفون",dashboard:"لوحة تحكم",minimal:"بسيط",classic:"كلاسيكي"});
  const circularPresets = Object.freeze({obsidian:"Obsidian Ring",pearl:"Pearl Soft",royal:"Royal Dial",glacier:"Glacier Touch"});
  const themes = new Set(["obsidian","pearl","royal","glacier","ios-dark","ios-light","glass","dark","light","purple","blue","red","emerald","sand"]);
  const layoutWidths = Object.freeze({mini:240,small:280,compact:320,standard:360,full:440});
  const appearanceKeys = ["theme","interfaceStyle","layout","popupWidth","autoFitPopup","density","show"];
  const defaults = {
    theme: "obsidian", interfaceStyle:"circular", circularVersion:1, appearanceVersion: 1, layout: "standard", popupWidth:0, autoFitPopup:true, density:"compact", performanceMode: true,
    beneficiaryEnabled: true, historyEnabled: true,
    timerEnabled: true, timerDirection: "down", timerDecimals: true,
    timerStyle: "ring", timerShape:"rounded",timerFont:"rounded",timerAutoFit:true, timerAnchor: "center", timerSize: 120,
    timerOpacity: 85, timerX: 0.5, timerY: 0.5,
    timerWidth: 145, timerHeight: 145, timerMoved: false,
    cardOrder: ["company","branch","refresh","live","phase"],
    show: {company:true, branch:true, refresh:true, live:true,
      phase:true, history:true, evidence:true, beneficiary:true,bookingMode:true,autoConfirm:true,headerDetails:true,quickNav:true,diagnostics:true}
  };
  const visibilityProfiles = Object.freeze({all:{...defaults.show},essential:Object.fromEntries(Object.keys(defaults.show).map(key=>[key,["bookingMode","phase"].includes(key)]))});
  async function ui() {
    const stored = await chrome.storage.local.get(KEY);
    return normalizeUi(stored[KEY]);
  }
  function normalizeUi(value) {
    const data = value && typeof value === "object" ? value : {};
    // Adopt the requested circular design once without changing booking options.
    const requestedTheme = data.circularVersion === 1 ? data.theme || defaults.theme : defaults.theme;
    const theme = themes.has(requestedTheme) ? requestedTheme : defaults.theme;
    const requestedInterface = data.circularVersion === 1 ? data.interfaceStyle : defaults.interfaceStyle;
    const interfaceStyle = Object.hasOwn(interfaces,requestedInterface) ? requestedInterface :
      Object.hasOwn(circularPresets,theme) ? "circular" : ["ios-dark","ios-light"].includes(theme) ? "ios" : "classic";
    const layout = Object.hasOwn(layoutWidths,data.layout) ? data.layout : defaults.layout;
    const popupWidth = Number(data.popupWidth)>0 ? Math.round(number(data.popupWidth,360,240,440)) : 0;
    return {...defaults, ...data, theme, interfaceStyle, layout,popupWidth,autoFitPopup:data.autoFitPopup !== false,density:data.density === "comfortable" ? "comfortable" : "compact",
      timerShape:["rounded","circle","star","digits"].includes(data.timerShape) ? data.timerShape : defaults.timerShape,
      timerFont:["rounded","mono","digital","classic"].includes(data.timerFont) ? data.timerFont : defaults.timerFont, timerAutoFit:data.timerAutoFit !== false, circularVersion:1, appearanceVersion:1,
      show:{...defaults.show,...(data.show || {})}};
  }
  async function saveUi(patch) {
    const current = await ui();
    const next = normalizeUi({...current,...patch,show:{...current.show,...(patch.show || {})}});
    if (appearanceKeys.some(key=>Object.hasOwn(patch,key) && JSON.stringify(current[key]) !== JSON.stringify(next[key])))
      next.previousAppearance=Object.fromEntries(appearanceKeys.map(key=>[key,current[key]]));
    await chrome.storage.local.set({[KEY]:next});
    return next;
  }
  async function restoreAppearance() {
    const current=await ui();
    if (!current.previousAppearance) return current;
    const patch=Object.fromEntries(appearanceKeys.filter(key=>Object.hasOwn(current.previousAppearance,key)).map(key=>[key,current.previousAppearance[key]]));
    return saveUi(patch);
  }
  function alertsMuted(settings={}) {return settings.notifications === false && settings.sound === false && settings.pageNotifications === false;}
  async function setAlertsMuted(muted) {
    const result=await chrome.runtime.sendMessage({type:"SET_ALERTS_MUTED",muted:!!muted});
    if (!result?.ok) throw new Error(result?.error || "تعذر تغيير كتم التنبيهات.");
    return result;
  }
  async function state() {
    const result = await chrome.runtime.sendMessage({type:"GET_STATE"});
    if (!result?.ok) throw new Error(result?.error || "تعذر قراءة حالة الإضافة.");
    return result;
  }
  async function saveSettings(patch) {
    const stored = await chrome.storage.local.get(["bookingSettings","bookingRuntime"]);
    const previous = stored.bookingSettings || {};
    if (patch.bookingMode && patch.bookingMode !== (previous.bookingMode || "cash") &&
        (previous.enabled || stored.bookingRuntime?.phase === "confirm_pending")) {
      await chrome.runtime.sendMessage({type:"STOP_SESSION"});
      patch = {...patch,enabled:false};
    }
    const next = {...previous,...patch};
    await chrome.storage.local.set({bookingSettings:next});
    return next;
  }
  function number(value, fallback, min, max) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(Math.max(min,Math.min(max,parsed))*10)/10 : fallback;
  }
  async function platformTab() {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.id || !String(tab.url || "").startsWith("https://fcms.cbl.gov.ly/")) {
      throw new Error("افتح منصة الحجز في علامة التبويب الحالية.");
    }
    return tab;
  }
  async function deliver(tabId, message) {
    try { return await chrome.tabs.sendMessage(tabId,message); }
    catch {
      await chrome.scripting.insertCSS({target:{tabId},files:["page-notify.css"]}).catch(()=>{});
      await chrome.scripting.executeScript({target:{tabId},files:[
        "branch-data.js","company-data.js","i18n.js","diagnostic.js",
        "page-notify.js","content.js","evidence-content.js","timer-overlay.js"
      ]});
      return chrome.tabs.sendMessage(tabId,message);
    }
  }
  function applyTheme(value, target=document.documentElement) {
    target.dataset.theme = value.theme;
    target.dataset.design = value.interfaceStyle || (["ios-dark","ios-light"].includes(value.theme) ? "ios" : "classic");
    target.dataset.layout = value.layout;
    target.dataset.density=value.density || "compact";
    target.style.setProperty("--popup-width",`${value.popupWidth || layoutWidths[value.layout] || 360}px`);
    target.style.setProperty("--popup-max-height","600px");
    target.dataset.performance = value.performanceMode ? "on" : "off";
  }
  return {KEY,defaults,interfaces,circularPresets,layoutWidths,visibilityProfiles,restoreAppearance,alertsMuted,setAlertsMuted,ui,normalizeUi,saveUi,state,saveSettings,number,platformTab,deliver,applyTheme};
})();
