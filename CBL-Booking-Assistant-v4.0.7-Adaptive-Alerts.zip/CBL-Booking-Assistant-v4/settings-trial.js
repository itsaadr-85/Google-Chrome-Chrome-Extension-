"use strict";
(() => {
  const $ = selector => document.querySelector(selector);
  const T = CBLTrial;
  const Audio = CBLBookAudio;
  const circularPresets = new Set(["obsidian", "pearl", "royal", "glacier"]);
  const soundEventLabels = {
    company_options:"ظهور قائمة الشركات",company_selected:"تثبيت اختيار الشركة",
    branch_available:"توفر الفرع المطلوب",confirm_submitted:"إرسال تأكيد الحجز",
    booking_success:"نجاح الحجز من المنصة"
  };
  let settings = {}, ui = {}, evidence = {}, catalog = [];
  let eventSaveQueue = Promise.resolve();
  const status = text => { $("#settingsStatus").textContent = text; };
  const send = async message => {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || "تعذر الحفظ.");
    return response;
  };
  const parse = element => {
    if (element.type === "checkbox") return element.checked;
    if (element.type === "number" || element.type === "range") return Number(element.value);
    return element.value;
  };
  function revealSection(hash = location.hash) {
    const section = document.getElementById(hash.replace(/^#/, ""));
    if (!section?.classList.contains("settings-section")) return;
    section.open = true;
    for (const link of document.querySelectorAll('.settings-sidebar a[href^="#"]')) {
      if (link.hash === hash) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  }
  for (const checkbox of document.querySelectorAll('input[type="checkbox"]'))
    checkbox.setAttribute("role", "switch");
  for (const link of document.querySelectorAll('.settings-sidebar a[href^="#"]'))
    link.addEventListener("click", () => revealSection(link.hash));
  window.addEventListener("hashchange", () => revealSection());
  async function protect(work,successMessage="تم حفظ الإعداد.") {
    try { await work(); if (successMessage !== null) status(successMessage); }
    catch(error) { status(String(error?.message || error)); }
  }
  async function previewSound(tone,volume) {
    const response=await send({type:"PREVIEW_SOUND",tone,volume});
    if (response.muted) status("التنبيهات مكتومة؛ ألغِ الكتم لسماع المعاينة.");
    else if (response.played === true) status("تم تشغيل معاينة الصوت.");
    else status("لم تعمل المعاينة. تحقق من إعداد الصوت وحاول مجددًا.");
  }
  function renderAlertMute() {
    const muted=T.alertsMuted(settings);
    const button=$("#muteAllAlerts");
    button.setAttribute("aria-pressed",String(muted));
    button.setAttribute("aria-label",muted ? "إلغاء كتم جميع التنبيهات" : "كتم جميع التنبيهات");
    button.querySelector("span").textContent=muted ? "إلغاء كتم التنبيهات" : "كتم جميع التنبيهات";
    button.querySelector("use").setAttribute("href",muted ? "#settings-icon-alerts-muted" : "#settings-icon-alerts");
    $("#muteSummary").textContent=muted
      ? "الأصوات وإشعارات المتصفح والصفحة مكتومة. المراقبة والحجز مستمران."
      : "التنبيهات حسب المفاتيح أدناه. الكتم العام يحفظ اختيارك لاستعادته عند إلغاء الكتم.";
  }
  function buildEventSounds() {
    const list=$("#eventSoundList");
    for (const event of Audio.events) {
      const row=document.createElement("fieldset");
      row.className="event-sound-row";row.dataset.soundEvent=event;
      const legend=document.createElement("legend");legend.textContent=soundEventLabels[event];row.append(legend);
      for (const [field,title] of [["enabled","تشغيل صوت الحدث"],["tone","النغمة"],["volume","مستوى الصوت"]]) {
        const label=document.createElement("label");label.className="setting-field";
        const caption=document.createElement("span");caption.textContent=title;label.append(caption);
        const control=document.createElement(field === "tone" ? "select" : "input");
        control.dataset.eventField=field;
        control.setAttribute("aria-label",`${title}: ${soundEventLabels[event]}`);
        if (field === "enabled") {control.type="checkbox";control.setAttribute("role","switch");}
        else if (field === "tone") {
          for (const tone of Audio.toneNames) {
            const option=document.createElement("option");option.value=tone;option.textContent=Audio.labels[tone] || tone;control.append(option);
          }
        } else {
          control.type="range";control.min="0";control.max="100";control.step="1";
          control.id=`event-volume-${event}`;
          label.classList.add("event-volume-field");
        }
        label.append(control);
        if (field === "volume") {
          const output=document.createElement("output");output.htmlFor=control.id;
          output.className="event-volume-value";label.append(output);
          control.addEventListener("input",()=>{output.textContent=`${control.value}٪`;});
        }
        control.addEventListener("change",()=>protect(()=>saveEventSound(event,field,parse(control))));
        row.append(label);
      }
      const button=document.createElement("button");button.type="button";
      button.className="settings-button event-sound-preview";button.dataset.eventPreview=event;
      button.textContent="معاينة صوت الحدث";
      button.setAttribute("aria-label",`معاينة صوت ${soundEventLabels[event]}`);
      button.addEventListener("click",()=>protect(async()=>{
        await eventSaveQueue;
        const config=Audio.normalizeEventSounds(settings.eventSounds)[event];
        await previewSound(config.tone,config.volume);
      },null));
      row.append(button);list.append(row);
    }
    const globalTone=document.querySelector('[data-setting="soundTone"]');
    const known=new Set([...globalTone.options].map(option=>option.value));
    for (const tone of Audio.toneNames) if (!known.has(tone)) {
      const option=document.createElement("option");option.value=tone;option.textContent=Audio.labels[tone] || tone;globalTone.append(option);
    }
  }
  function saveEventSound(event,field,value) {
    eventSaveQueue=eventSaveQueue.catch(()=>{}).then(async()=>{
      const stored=await chrome.storage.local.get("bookingSettings");
      const current=Audio.normalizeEventSounds(stored.bookingSettings?.eventSounds || settings.eventSounds);
      const eventSounds=Audio.normalizeEventSounds({...current,[event]:{...current[event],[field]:value}});
      settings=await T.saveSettings({eventSounds});render();
    });
    return eventSaveQueue;
  }
  function renderEventSounds() {
    const eventSounds=Audio.normalizeEventSounds(settings.eventSounds);
    for (const row of document.querySelectorAll("[data-sound-event]")) {
      const value=eventSounds[row.dataset.soundEvent];
      for (const control of row.querySelectorAll("[data-event-field]")) {
        if (control.type === "checkbox") control.checked=value.enabled;
        else control.value=value[control.dataset.eventField];
      }
      row.querySelector("output").textContent=`${value.volume}٪`;
    }
  }
  buildEventSounds();
  function render() {
    ui = {...T.defaults,...ui,show:{...T.defaults.show,...(ui.show || {})}};
    T.applyTheme(ui);
    for (const button of document.querySelectorAll("[data-theme-choice]"))
      button.setAttribute("aria-pressed",String(ui.theme === button.dataset.themeChoice));
    for (const button of document.querySelectorAll("[data-interface-choice]"))
      button.setAttribute("aria-pressed",String(ui.interfaceStyle === button.dataset.interfaceChoice));
    const selectedCircular = circularPresets.has(ui.theme);
    for (const button of document.querySelectorAll("[data-circular-preset]"))
      button.setAttribute("aria-pressed",String(selectedCircular && ui.theme === button.dataset.circularPreset));
    if (!selectedCircular || !["circular", "compact", "capsule"].includes(ui.interfaceStyle))
      $("#additionalAppearance").open = true;
    if (["glass", "dark", "light", "purple", "blue", "red", "emerald", "sand"].includes(ui.theme))
      $(".classic-themes").open = true;
    for (const element of document.querySelectorAll("[data-setting]")) {
      const value = settings[element.dataset.setting];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const row of document.querySelectorAll("[data-cash-only]")) row.hidden = settings.bookingMode === "card";
    const branchInterval = document.querySelector('[data-setting="branchRefreshSeconds"]');
    if (branchInterval) branchInterval.disabled = settings.waitForTargetBranch === false;
    for (const element of document.querySelectorAll("[data-ui]")) {
      const value = ui[element.dataset.ui];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const element of document.querySelectorAll("[data-evidence]")) {
      const value = evidence[element.dataset.evidence];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const element of document.querySelectorAll("[data-show]"))
      element.checked = ui.show?.[element.dataset.show] !== false;
    renderAlertMute();renderEventSounds();
    renderOrder();
  }
  function renderOrder() {
    const names={company:"استراتيجية الشركة",branch:"الفرع المطلوب",refresh:"تحديث الصفحة",live:"LIVE"};
    const list=$("#cardOrderList");list.replaceChildren();
    const order=(Array.isArray(ui.cardOrder) ? ui.cardOrder : T.defaults.cardOrder).filter(key=>names[key]);
    for (const [index,key] of order.entries()) {
      if (!names[key]) continue;
      const row=document.createElement("div");row.className="order-item";
      const label=document.createElement("span");label.textContent=names[key];row.append(label);
      for (const [symbol,shift] of [["↑",-1],["↓",1]]) {
        const button=document.createElement("button");button.type="button";button.textContent=symbol;
        button.setAttribute("aria-label",`${shift<0?"رفع":"خفض"} ${names[key]}`);
        button.disabled=index+shift<0 || index+shift>=order.length;
        button.addEventListener("click",()=>protect(async()=>{
          const next=[...order];[next[index],next[index+shift]]=[next[index+shift],next[index]];
          ui=await T.saveUi({cardOrder:[...next,"phase"]});render();
        }));
        row.append(button);
      }
      list.append(row);
    }
  }
  function branches() {
    const select = $("#settingsBranch");
    select.replaceChildren();
    for (const item of [...catalog].sort((a,b)=>Number(a.order)-Number(b.order))) {
      const option=document.createElement("option");option.value=item.id;option.textContent=item.name;
      select.append(option);
    }
  }
  for (const button of document.querySelectorAll("[data-theme-choice]")) button.addEventListener("click",() => protect(async () => {
    ui = await T.saveUi({theme:button.dataset.themeChoice});render();
  }));
  for (const button of document.querySelectorAll("[data-interface-choice]")) button.addEventListener("click",() => protect(async () => {
    ui = await T.saveUi({interfaceStyle:button.dataset.interfaceChoice});render();
  }));
  for (const button of document.querySelectorAll("[data-circular-preset]")) button.addEventListener("click",() => protect(async () => {
    ui = await T.saveUi({theme:button.dataset.circularPreset});render();
  }));
  for (const element of document.querySelectorAll("[data-setting]")) element.addEventListener("change",() => protect(async () => {
    const key=element.dataset.setting;
    let value=parse(element);
    if (["refreshSeconds","branchRefreshSeconds"].includes(key)) value=T.number(value,2,.5,30);
    if (key==="notificationDuration") value=T.number(value,5,.1,30);
    if (key==="notificationOpacity") value=T.number(value,88,20,100);
    if (key==="companySkipCount") value=Math.floor(T.number(value,5,0,20));
    if (key==="companyResponseSeconds") value=Math.floor(T.number(value,8,3,30));
    if (key==="companyAttempts") value=Math.floor(T.number(value,2,1,3));
    settings=await T.saveSettings({[key]:value});render();
    if (key === "companyMode" && ["specific", "random_from_5"].includes(value))
      $("#companySelectionDetails").open = true;
    if (key === "diagnosticsEnabled") await diagnosticSummary();
  }));
  for (const element of document.querySelectorAll("[data-ui]")) element.addEventListener("change",() => protect(async () => {
    const key=element.dataset.ui;
    let value=parse(element);
    if (key === "popupWidth") value=Number.isFinite(value) && value>0 ? Math.round(T.number(value,360,240,440)) : 0;
    if (key === "timerSize") value=T.number(value,T.defaults.timerSize,40,200);
    if (key === "timerWidth") value=T.number(value,T.defaults.timerWidth,72,320);
    if (key === "timerHeight") value=T.number(value,T.defaults.timerHeight,52,300);
    ui=await T.saveUi(key==="timerAnchor" ? {[key]:value,timerMoved:false} : {[key]:value});
    render();
  }));
  for (const element of document.querySelectorAll("[data-show]")) element.addEventListener("change",() => protect(async () => {
    ui=await T.saveUi({show:{[element.dataset.show]:element.checked}});render();
  }));
  async function saveEvidence() {
    const value = {};
    for (const element of document.querySelectorAll("[data-evidence]")) value[element.dataset.evidence]=parse(element);
    evidence=(await send({type:"EVIDENCE_SET_OPTIONS",...value})).options;render();
  }
  for (const element of document.querySelectorAll("[data-evidence]"))
    element.addEventListener("change",() => protect(saveEvidence));
  $("#resetTimer").addEventListener("click",() => protect(async () => {
    ui=await T.saveUi({timerAnchor:"center",timerX:.5,timerY:.5,
      timerWidth:145,timerHeight:145,timerSize:120,timerMoved:false});render();
  }));
  $("#resetLayout").addEventListener("click",() => protect(async () => {
    ui=await T.saveUi({show:{...T.defaults.show},layout:T.defaults.layout,popupWidth:T.defaults.popupWidth,
      autoFitPopup:T.defaults.autoFitPopup,density:T.defaults.density,cardOrder:[...T.defaults.cardOrder]});render();
  }));
  $("#restoreAppearance").addEventListener("click",()=>protect(async()=>{
    const saved=ui.previousAppearance;
    ui=await T.restoreAppearance();render();
    status(saved ? "تمت استعادة المظهر السابق. خيارات الحجز محفوظة." : "لا يوجد مظهر سابق محفوظ بعد.");
  },null));
  for (const [selector,profile] of [["#visibilityEssential","essential"],["#visibilityAll","all"]])
    $(selector).addEventListener("click",() => protect(async () => {
      ui=await T.saveUi({show:{...T.visibilityProfiles[profile]}});render();
    },"تم تحديث العناصر الظاهرة. خيارات الحجز محفوظة."));
  $("#muteAllAlerts").addEventListener("click",()=>protect(async()=>{
    const response=await T.setAlertsMuted(!T.alertsMuted(settings));
    settings=response.settings;render();
    status(response.muted ? "تم كتم جميع التنبيهات. الحجز والمراقبة مستمران." : "تمت استعادة إعدادات التنبيهات.");
  },null));
  $("#soundPreview").addEventListener("click",() => protect(() => previewSound(settings.soundTone || "bell",85),null));
  $("#openShortcuts").addEventListener("click",() =>
    chrome.tabs.create({url:"chrome://extensions/shortcuts"}).catch(error => status(String(error))));
  $("#openOriginalSettings").addEventListener("click",() =>
    chrome.tabs.create({url:chrome.runtime.getURL("settings.html")}).catch(error => status(String(error))));
  async function diagnosticSummary() {
    const data=await send({type:"DIAGNOSTIC_STATUS"});
    $("#diagnosticStatus").textContent=`${data.enabled ? "التسجيل يعمل" : "التسجيل متوقف"} — ${data.entryCount || 0} حدث محفوظ${data.droppedCount ? ` — حُذفت ${data.droppedCount} أحداث قديمة بسبب حد التخزين` : ""}.`;
  }
  $("#diagnosticExport").addEventListener("click",()=>protect(async()=>{
    await send({type:"DIAGNOSTIC_EXPORT"});
  },"اختر مكان حفظ ملف JSON، ثم أرسله للمراجعة."));
  $("#diagnosticRefresh").addEventListener("click",()=>protect(diagnosticSummary));
  $("#diagnosticClear").addEventListener("click",()=>protect(async()=>{await send({type:"DIAGNOSTIC_CLEAR"});await diagnosticSummary();}));
  async function load() {
    const [state,uiOptions,ev]=await Promise.all([T.state(),T.ui(),send({type:"EVIDENCE_GET_STATUS"})]);
    settings=state.settings;catalog=state.catalog;ui=uiOptions;evidence=ev.options;
    branches();render();
    if (["specific","random_from_5"].includes(settings.companyMode)) $("#companySelectionDetails").open = true;
    revealSection(location.hash || "#appearance");
    await diagnosticSummary();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[T.KEY]) ui = T.normalizeUi(changes[T.KEY].newValue);
    if (changes.bookingSettings) settings = changes.bookingSettings.newValue || {};
    if (changes.cblEvidenceTrialOptions) evidence = changes.cblEvidenceTrialOptions.newValue || {};
    if (changes[T.KEY] || changes.bookingSettings || changes.cblEvidenceTrialOptions) render();
  });
  load().catch(error=>status(String(error?.message || error)));
})();
