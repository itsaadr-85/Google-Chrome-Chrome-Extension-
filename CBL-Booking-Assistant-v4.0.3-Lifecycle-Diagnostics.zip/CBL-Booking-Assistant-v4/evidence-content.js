"use strict";

// Trial module: reads only the visible profile and account detail fields.
(() => {
  if (window.top !== window || window.__CBL_EVIDENCE_TRIAL__) return;
  window.__CBL_EVIDENCE_TRIAL__ = true;

  const normal = value => String(value || "")
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/\s+/g, " ").trim();
  const compact = value => normal(value).replace(/\s/g, "");
  const visible = element => !!(element && element.isConnected &&
    (element.getClientRects().length || element === document.body));

  function nearLabel(label, validator) {
    const wanted = normal(label);
    const nodes = document.querySelectorAll("span,div,p,dt,th,td,label,strong,small");
    for (const node of nodes) {
      if (!visible(node) || node.children.length > 0 || normal(node.textContent) !== wanted) continue;
      const parent = node.parentElement;
      if (!parent) continue;
      const candidates = [
        ...[...parent.children].filter(child => child !== node && !child.contains(node)),
        parent.nextElementSibling,
        parent.previousElementSibling
      ].filter(Boolean);
      for (const candidate of candidates) {
        if (!visible(candidate)) continue;
        const raw = normal(candidate.innerText || candidate.textContent);
        const result = validator(raw);
        if (result) return result;
      }
      const row = normal(parent.innerText || parent.textContent).replace(wanted, "").trim();
      const result = validator(row);
      if (result) return result;
    }
    return "";
  }

  const asIban = value => {
    const found = compact(value).toUpperCase().match(/LY\d{23}/);
    return found ? found[0] : "";
  };
  const asAccountNumber = value => {
    const found = compact(value).match(/(?:^|\D)(\d{8,25})(?:\D|$)/);
    return found ? found[1] : "";
  };
  const asName = value => {
    const name = normal(value);
    if (name.length < 5 || name.length > 100 || /\d|رقم|الاسم|تعديل/.test(name)) return "";
    return name;
  };
  const asBank = value => {
    const bank = normal(value);
    return /مصرف|بنك|bank/i.test(bank) && bank.length <= 100 ? bank : "";
  };

  function readPage() {
    const bodyText = document.body?.innerText || "";
    const pathname = globalThis.location?.pathname || "";
    const name = bodyText.includes("البيانات الشخصية")
      ? nearLabel("الاسم", asName) : "";
    // The account list displays several IBANs. Read only a detail page
    // containing both labelled fields and a labelled bank name.
    const accountDetail = bodyText.includes("رقم الحساب المصرفي الدولي") &&
      bodyText.includes("رقم الحساب") && bodyText.includes("المصرف");
    const iban = accountDetail
      ? nearLabel("رقم الحساب المصرفي الدولي (IBAN)", asIban) ||
        nearLabel("رقم الحساب المصرفي الدولي", asIban)
      : "";
    const accountNumber = accountDetail
      ? nearLabel("رقم الحساب", asAccountNumber) : "";
    const bank = accountDetail ? nearLabel("المصرف", asBank) : "";
    return {
      name,
      account: iban && accountNumber && bank
        ? { iban, accountNumber, bank } : null,
      accountId: !pathname.includes("/purchase-requests/")
        ? pathname.match(/\/bank-accounts\/([0-9a-f-]{36})(?:\/|$)/i)?.[1] || ""
        : ""
    };
  }

  let lastName = "";
  let lastIban = "";
  function scan() {
    const page = readPage();
    if (page.name && page.name !== lastName) {
      lastName = page.name;
      chrome.runtime.sendMessage({ type: "EVIDENCE_PROFILE_FOUND", name: page.name }).catch(() => {});
    }
    if (page.account && page.account.iban !== lastIban) {
      lastIban = page.account.iban;
      chrome.runtime.sendMessage({ type: "EVIDENCE_ACCOUNT_FOUND", account: page.account,
        accountId: page.accountId }).catch(() => {});
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "EVIDENCE_READ_PAGE") return false;
    sendResponse({ ok: true, ...readPage() });
    return false;
  });

  let watching = false;
  let successSent = false;
  let checkTimer = null;
  let successAttempts = 0;
  let successInFlight = false;
  function singleVisibleIban() {
    const values = [...new Set((document.body?.innerText || "")
      .toUpperCase().match(/LY(?:\s*\d){23}/g)?.map(asIban).filter(Boolean) || [])];
    return values.length === 1 ? values[0] : "";
  }
  async function successCheck() {
    if (successSent || !document.body) return;
    if (!normal(document.body.innerText).includes("يرجى التوجه الى الفرع")) return;
    if (successAttempts >= 5 || successInFlight) return;
    successAttempts++;
    successInFlight = true;
    try {
      const result = await chrome.runtime.sendMessage({
        type: "EVIDENCE_SUCCESS",
        visibleIban: singleVisibleIban()
      });
      if (result?.ok) {
        successSent = true;
        observer?.disconnect();
        successInFlight = false;
        return;
      }
    } catch {}
    successInFlight = false;
    setTimeout(() => successCheck().catch(() => {}), 200);
  }
  let observer = null;
  function watchSuccess() {
    if (watching) return;
    watching = true;
    observer = new MutationObserver(() => {
      if (checkTimer) return;
      checkTimer = setTimeout(() => { checkTimer = null; successCheck().catch(() => {}); }, 90);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    successCheck().catch(() => {});
  }

  document.addEventListener("click", event => {
    const button = event.target?.closest?.('button,input[type="submit"]');
    if (!button || !normal(button.textContent || button.value).includes("تاكيد الحجز")) return;
    if (normal(document.body?.innerText).includes("يرجى التوجه الى الفرع")) return;
    chrome.runtime.sendMessage({
      type: "EVIDENCE_ARM",
      requestIban: singleVisibleIban()
    }).catch(() => {});
    watchSuccess();
  }, true);

  chrome.runtime.sendMessage({ type: "EVIDENCE_PENDING_STATUS" })
    .then(result => { if (result?.pending) watchSuccess(); }).catch(() => {});

  // Profile and account detail pages often finish rendering after document_idle.
  scan();
  let attempts = 0;
  const scanTimer = setInterval(() => {
    scan();
    if (++attempts >= 10 || (lastName && lastIban)) clearInterval(scanTimer);
  }, 1000);
})();
