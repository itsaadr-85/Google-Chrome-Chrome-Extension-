"use strict";


const $ = selector =>
  document.querySelector(
    selector
  );


const COMPANY_MODES =
  new Set([
    "first_available",
    "specific",
    "disabled"
  ]);


const THEMES =
  new Set([
    "emerald",
    "midnight",
    "royal",
    "sand"
  ]);


const UI_STYLES =
  new Set([
    "compact",
    "cards",
    "minimal"
  ]);


const LANGUAGES =
  new Set([
    "ar",
    "en"
  ]);


const FONT_FAMILIES =
  new Set([
    "system",
    "segoe",
    "tahoma",
    "arial"
  ]);


const FONT_SCALES =
  new Set([
    "small",
    "medium",
    "large",
    "xlarge"
  ]);


const FONT_WEIGHTS =
  new Set([
    "normal",
    "bold"
  ]);


const TEXT = {

  ar: {

    brand:
      "مساعد الحجز",

    appearance:
      "المظهر",

    settings:
      "الإعدادات",

    language:
      "اللغة",

    theme:
      "الثيم",

    layout:
      "شكل الواجهة",

    fontFamily:
      "نوع الخط",

    fontScale:
      "حجم الخط",

    fontWeight:
      "سماكة الخط",

    system:
      "تلقائي",

    emerald:
      "زمردي",

    midnight:
      "ليلي",

    royal:
      "ملكي",

    sand:
      "رملي",

    compact:
      "مضغوط",

    cards:
      "بطاقات",

    minimal:
      "بسيط",

    small:
      "صغير",

    medium:
      "متوسط",

    large:
      "كبير",

    xlarge:
      "كبير جدًا",

    normal:
      "عادي",

    bold:
      "غامق",

    branch:
      "الفرع المطلوب",

    target:
      "الهدف",

    branchSearch:
      "⌕ البحث عن فرع...",

    company:
      "شركة الصرافة",

    flexible:
      "مرن",

    firstAvailable:
      "أول شركة متاحة تلقائيًا",

    specific:
      "شركة محددة من القائمة",

    manual:
      "اختيار الشركة يدويًا",

    specificEmpty:
      "حدد الشركة المطلوبة من صفحة الإعدادات.",

    specificName:
      "الشركة المطلوبة: ",

    manualHint:
      "ستنتظر الإضافة حتى تختار شركة الصرافة يدويًا من الموقع.",

    refresh:
      "التحديث",

    tone:
      "النغمة",

    sound:
      "الصوت",

    autoConfirm:
      "تأكيد تلقائي",

    confirmHint:
      "التأكيد يعمل فقط بعد إكمال Cloudflare يدويًا.",

    errorTitle:
      "مشكلة أثناء التشغيل",

    recover:
      "↻ تعافي",

    diagnostic:
      "نسخ التشخيص",

    start:
      "تشغيل",

    stop:
      "إيقاف",

    instantStop:
      "إيقاف فوري",

    ready:
      "جاهز",

    stopped:
      "متوقف",

    monitoring:
      "قيد المراقبة",

    monitoringPill:
      "مراقبة",

    opening:
      "ظهر الخيار",

    openingPill:
      "فتح",

    companyState:
      "اختيار الشركة",

    companyPill:
      "شركة",

    branchState:
      "اختيار الفرع",

    branchPill:
      "فرع",

    confirmState:
      "بانتظار التأكيد",

    confirmPill:
      "Cloudflare",

    success:
      "اكتملت المهمة",

    successPill:
      "نجاح",

    cooldown:
      "توقف آمن",

    cooldownPill:
      "429",

    error:
      "توجد مشكلة",

    errorPill:
      "خطأ",

    defaultMessage:
      "اختر الفرع ثم شغّل المراقبة.",

    selectCompanyFirst:
      "حدد شركة الصرافة المطلوبة من الإعدادات أولًا.",

    openPlatform:
      "افتح منصة الحجز أولًا.",

    stoppedMessage:
      "تم إيقاف مساعد الحجز.",

    diagnosticEmpty:
      "سجل التشخيص فارغ.",

    diagnosticCopied:
      "تم نسخ سجل التشخيص.",

    diagnosticSettings:
      "افتح الإعدادات لنسخ السجل.",

    branchPriority:
      "الأولوية: ",

    branchList:
      "قائمة الفروع: ",

    exists:
      "موجودة",

    missing:
      "غير موجودة",

    branchesDetected:
      "الفروع المكتشفة: ",

    companyAttempt:
      "محاولة الشركة: "
  },


  en: {

    brand:
      "CBL Booking Assistant",

    appearance:
      "Appearance",

    settings:
      "Settings",

    language:
      "Language",

    theme:
      "Theme",

    layout:
      "Layout",

    fontFamily:
      "Font",

    fontScale:
      "Font size",

    fontWeight:
      "Font weight",

    system:
      "System",

    emerald:
      "Emerald",

    midnight:
      "Midnight",

    royal:
      "Royal",

    sand:
      "Sand",

    compact:
      "Compact",

    cards:
      "Cards",

    minimal:
      "Minimal",

    small:
      "Small",

    medium:
      "Medium",

    large:
      "Large",

    xlarge:
      "Extra large",

    normal:
      "Normal",

    bold:
      "Bold",

    branch:
      "Target branch",

    target:
      "Target",

    branchSearch:
      "⌕ Search branches...",

    company:
      "Exchange company",

    flexible:
      "Flexible",

    firstAvailable:
      "First available company",

    specific:
      "Specific company",

    manual:
      "Manual company selection",

    specificEmpty:
      "Select the required company from Settings.",

    specificName:
      "Required company: ",

    manualHint:
      "The assistant will wait for you to select the exchange company manually.",

    refresh:
      "Refresh",

    tone:
      "Tone",

    sound:
      "Sound",

    autoConfirm:
      "Auto confirm",

    confirmHint:
      "Auto confirm works only after you complete Cloudflare manually.",

    errorTitle:
      "Operation problem",

    recover:
      "↻ Recover",

    diagnostic:
      "Copy diagnostics",

    start:
      "Start",

    stop:
      "Stop",

    instantStop:
      "Emergency stop",

    ready:
      "Ready",

    stopped:
      "Stopped",

    monitoring:
      "Monitoring",

    monitoringPill:
      "Watch",

    opening:
      "Option detected",

    openingPill:
      "Open",

    companyState:
      "Selecting company",

    companyPill:
      "Company",

    branchState:
      "Selecting branch",

    branchPill:
      "Branch",

    confirmState:
      "Awaiting confirmation",

    confirmPill:
      "Cloudflare",

    success:
      "Task completed",

    successPill:
      "Success",

    cooldown:
      "Safe pause",

    cooldownPill:
      "429",

    error:
      "Attention required",

    errorPill:
      "Error",

    defaultMessage:
      "Select the branch, then start monitoring.",

    selectCompanyFirst:
      "Select the required exchange company in Settings first.",

    openPlatform:
      "Open the booking platform first.",

    stoppedMessage:
      "Booking assistant stopped.",

    diagnosticEmpty:
      "Diagnostic log is empty.",

    diagnosticCopied:
      "Diagnostic log copied.",

    diagnosticSettings:
      "Open Settings to copy the diagnostic log.",

    branchPriority:
      "Priority: ",

    branchList:
      "Branch list: ",

    exists:
      "available",

    missing:
      "missing",

    branchesDetected:
      "Branches detected: ",

    companyAttempt:
      "Company attempt: "
  }
};


let settings = {};
let runtime = {};
let catalog = [];


function language() {

  return LANGUAGES.has(
    settings.uiLanguage
  )
    ? settings.uiLanguage
    : "ar";
}


function t(key) {

  return (
    TEXT[language()]?.[key] ??
    TEXT.ar[key] ??
    key
  );
}


function optionText(
  select,
  value,
  text
) {

  const option = [
    ...select.options
  ].find(
    item =>
      item.value === value
  );

  if (option) {
    option.textContent =
      text;
  }
}


/* =========================================================
   ELEMENTS
========================================================= */


const favoriteBranch =
  $("#favoriteBranch");

const branchSearch =
  $("#branchSearch");

const searchResults =
  $("#searchResults");

const companyMode =
  $("#companyMode");

const companyHint =
  $("#companyHint");

const refreshSeconds =
  $("#refreshSeconds");

const soundTone =
  $("#soundTone");

const soundEnabled =
  $("#soundEnabled");

const autoConfirm =
  $("#autoConfirm");

const confirmHint =
  $("#confirmHint");

const statusDot =
  $("#statusDot");

const statusTitle =
  $("#statusTitle");

const statusPhase =
  $("#statusPhase");

const statusMessage =
  $("#statusMessage");

const errorPanel =
  $("#errorPanel");

const errorMessage =
  $("#errorMessage");

const errorDetails =
  $("#errorDetails");

const recoverButton =
  $("#recoverButton");

const appearanceButton =
  $("#appearanceButton");

const appearancePanel =
  $("#appearancePanel");

const languageSelect =
  $("#languageSelect");

const themeSelect =
  $("#themeSelect");

const styleSelect =
  $("#styleSelect");

const fontFamilySelect =
  $("#fontFamilySelect");

const fontScaleSelect =
  $("#fontScaleSelect");

const fontWeightSelect =
  $("#fontWeightSelect");


/* =========================================================
   SAVE SETTINGS
========================================================= */


async function saveSettings(
  patch = {}
) {

  settings = {
    ...settings,
    ...patch
  };

  await chrome.storage.local.set({
    bookingSettings:
      settings
  });
}


/* =========================================================
   TRANSLATION
========================================================= */


function applyTranslations() {

  const lang =
    language();

  document.documentElement.lang =
    lang;

  document.documentElement.dir =
    lang === "ar"
      ? "rtl"
      : "ltr";


  $("#brandTitle").textContent =
    t("brand");

  appearanceButton.title =
    t("appearance");

  appearanceButton.setAttribute(
    "aria-label",
    t("appearance")
  );

  $("#settingsButton").title =
    t("settings");

  $("#settingsButton").setAttribute(
    "aria-label",
    t("settings")
  );


  $("#languageLabel").textContent =
    t("language");

  $("#themeLabel").textContent =
    t("theme");

  $("#styleLabel").textContent =
    t("layout");

  $("#fontFamilyLabel").textContent =
    t("fontFamily");

  $("#fontScaleLabel").textContent =
    t("fontScale");

  $("#fontWeightLabel").textContent =
    t("fontWeight");


  optionText(
    languageSelect,
    "ar",
    lang === "ar"
      ? "العربية"
      : "Arabic"
  );

  optionText(
    languageSelect,
    "en",
    "English"
  );


  optionText(
    themeSelect,
    "emerald",
    t("emerald")
  );

  optionText(
    themeSelect,
    "midnight",
    t("midnight")
  );

  optionText(
    themeSelect,
    "royal",
    t("royal")
  );

  optionText(
    themeSelect,
    "sand",
    t("sand")
  );


  optionText(
    styleSelect,
    "compact",
    t("compact")
  );

  optionText(
    styleSelect,
    "cards",
    t("cards")
  );

  optionText(
    styleSelect,
    "minimal",
    t("minimal")
  );


  optionText(
    fontFamilySelect,
    "system",
    t("system")
  );


  optionText(
    fontScaleSelect,
    "small",
    t("small")
  );

  optionText(
    fontScaleSelect,
    "medium",
    t("medium")
  );

  optionText(
    fontScaleSelect,
    "large",
    t("large")
  );

  optionText(
    fontScaleSelect,
    "xlarge",
    t("xlarge")
  );


  optionText(
    fontWeightSelect,
    "normal",
    t("normal")
  );

  optionText(
    fontWeightSelect,
    "bold",
    t("bold")
  );


  $("#branchTitle").textContent =
    t("branch");

  $("#branchBadge").textContent =
    t("target");

  branchSearch.placeholder =
    t("branchSearch");

  favoriteBranch.setAttribute(
    "aria-label",
    t("branch")
  );


  $("#companyTitle").textContent =
    t("company");

  $("#companyBadge").textContent =
    t("flexible");


  optionText(
    companyMode,
    "first_available",
    t("firstAvailable")
  );

  optionText(
    companyMode,
    "specific",
    t("specific")
  );

  optionText(
    companyMode,
    "disabled",
    t("manual")
  );


  $("#refreshLabel").textContent =
    t("refresh");

  $("#toneLabel").textContent =
    t("tone");

  $("#soundLabel").textContent =
    t("sound");

  $("#autoConfirmLabel").textContent =
    t("autoConfirm");

  confirmHint.textContent =
    t("confirmHint");

  $("#errorTitle").textContent =
    t("errorTitle");

  recoverButton.textContent =
    t("recover");

  $("#copyDiagnostic").textContent =
    t("diagnostic");

  $("#startButtonText").textContent =
    t("start");

  $("#stopButtonText").textContent =
    t("stop");

  $("#footerStopText").textContent =
    t("instantStop");


  optionText(
    refreshSeconds,
    "5",
    lang === "ar"
      ? "5 ث"
      : "5 s"
  );

  optionText(
    refreshSeconds,
    "10",
    lang === "ar"
      ? "10 ث"
      : "10 s"
  );

  optionText(
    refreshSeconds,
    "15",
    lang === "ar"
      ? "15 ث"
      : "15 s"
  );

  optionText(
    refreshSeconds,
    "20",
    lang === "ar"
      ? "20 ث"
      : "20 s"
  );

  optionText(
    refreshSeconds,
    "30",
    lang === "ar"
      ? "30 ث"
      : "30 s"
  );


  optionText(
    soundTone,
    "classic",
    lang === "ar"
      ? "كلاسيكية"
      : "Classic"
  );

  optionText(
    soundTone,
    "bell",
    lang === "ar"
      ? "جرس"
      : "Bell"
  );

  optionText(
    soundTone,
    "double",
    lang === "ar"
      ? "مزدوجة"
      : "Double"
  );

  optionText(
    soundTone,
    "rise",
    lang === "ar"
      ? "صاعدة"
      : "Rising"
  );

  optionText(
    soundTone,
    "soft",
    lang === "ar"
      ? "هادئة"
      : "Soft"
  );


  renderCompany();
  renderConfirm();
  renderStatus();
}


/* =========================================================
   APPEARANCE
========================================================= */


function applyAppearance() {

  const theme =
    THEMES.has(
      settings.uiTheme
    )
      ? settings.uiTheme
      : "emerald";


  const style =
    UI_STYLES.has(
      settings.uiStyle
    )
      ? settings.uiStyle
      : "compact";


  const lang =
    LANGUAGES.has(
      settings.uiLanguage
    )
      ? settings.uiLanguage
      : "ar";


  const fontFamily =
    FONT_FAMILIES.has(
      settings.fontFamily
    )
      ? settings.fontFamily
      : "system";


  const fontScale =
    FONT_SCALES.has(
      settings.fontScale
    )
      ? settings.fontScale
      : "medium";


  const fontWeight =
    FONT_WEIGHTS.has(
      settings.fontWeight
    )
      ? settings.fontWeight
      : "normal";


  const fontMap = {

    system:
      '"Segoe UI", Tahoma, Arial, sans-serif',

    segoe:
      '"Segoe UI", sans-serif',

    tahoma:
      'Tahoma, Arial, sans-serif',

    arial:
      'Arial, sans-serif'
  };


  document.documentElement.dataset.theme =
    theme;

  document.documentElement.dataset.fontScale =
    fontScale;

  document.documentElement.dataset.fontWeight =
    fontWeight;

  document.documentElement.style.setProperty(
    "--ui-font-family",
    fontMap[fontFamily]
  );


  document.body.dataset.uiStyle =
    style;


  settings.uiLanguage =
    lang;

  settings.uiTheme =
    theme;

  settings.uiStyle =
    style;

  settings.fontFamily =
    fontFamily;

  settings.fontScale =
    fontScale;

  settings.fontWeight =
    fontWeight;


  languageSelect.value =
    lang;

  themeSelect.value =
    theme;

  styleSelect.value =
    style;

  fontFamilySelect.value =
    fontFamily;

  fontScaleSelect.value =
    fontScale;

  fontWeightSelect.value =
    fontWeight;


  applyTranslations();
}


appearanceButton.addEventListener(
  "click",
  () => {

    appearancePanel.classList.toggle(
      "hidden"
    );
  }
);


languageSelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      uiLanguage:
        languageSelect.value
    });

    applyAppearance();
  }
);


themeSelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      uiTheme:
        themeSelect.value
    });

    applyAppearance();
  }
);


styleSelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      uiStyle:
        styleSelect.value
    });

    applyAppearance();
  }
);


fontFamilySelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      fontFamily:
        fontFamilySelect.value
    });

    applyAppearance();
  }
);


fontScaleSelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      fontScale:
        fontScaleSelect.value
    });

    applyAppearance();
  }
);


fontWeightSelect.addEventListener(
  "change",
  async () => {

    await saveSettings({
      fontWeight:
        fontWeightSelect.value
    });

    applyAppearance();
  }
);


/* =========================================================
   BRANCHES
========================================================= */


function favoriteBranches() {

  return catalog
    .filter(
      item =>
        item.favorite &&
        !item.hidden
    )
    .sort(
      (a, b) =>
        Number(a.order) -
        Number(b.order)
    );
}


function selectedBranchItem() {

  return (
    catalog.find(
      item =>
        item.id ===
        settings.selectedBranchId
    ) ||
    null
  );
}


function renderBranches() {

  favoriteBranch.replaceChildren();


  const favorites =
    favoriteBranches();


  const selected =
    selectedBranchItem();


  if (
    selected &&
    !selected.hidden &&
    !favorites.some(
      item =>
        item.id ===
        selected.id
    )
  ) {

    const option =
      document.createElement(
        "option"
      );

    option.value =
      selected.id;

    option.textContent =
      `✓ ${selected.name}`;

    favoriteBranch.append(
      option
    );
  }


  favorites.forEach(
    item => {

      const option =
        document.createElement(
          "option"
        );

      option.value =
        item.id;

      option.textContent =
        item.name;

      favoriteBranch.append(
        option
      );
    }
  );


  if (
    selected &&
    !selected.hidden
  ) {

    favoriteBranch.value =
      selected.id;
  }
}


function renderSearch(
  query
) {

  const results =
    CBL_BRANCH_LIBRARY
      .searchCatalog(
        catalog,
        query,
        false
      )
      .slice(
        0,
        14
      );


  searchResults.replaceChildren();


  if (
    !query.trim() ||
    !results.length
  ) {

    searchResults.classList.add(
      "hidden"
    );

    return;
  }


  results.forEach(
    item => {

      const button =
        document.createElement(
          "button"
        );

      button.type =
        "button";

      button.textContent =
        item.name;


      button.addEventListener(
        "click",
        async () => {

          await saveSettings({
            selectedBranchId:
              item.id
          });

          branchSearch.value =
            "";

          searchResults.classList.add(
            "hidden"
          );

          renderBranches();
        }
      );


      searchResults.append(
        button
      );
    }
  );


  searchResults.classList.remove(
    "hidden"
  );
}


favoriteBranch.addEventListener(
  "change",
  async () => {

    await saveSettings({
      selectedBranchId:
        favoriteBranch.value
    });
  }
);


branchSearch.addEventListener(
  "input",
  () => {

    renderSearch(
      branchSearch.value
    );
  }
);


/* =========================================================
   COMPANY
========================================================= */


async function enforceCompanyMode() {

  if (
    !COMPANY_MODES.has(
      settings.companyMode
    )
  ) {

    settings.companyMode =
      "first_available";

    await saveSettings({
      companyMode:
        "first_available"
    });
  }
}


function renderCompany() {

  companyMode.value =
    COMPANY_MODES.has(
      settings.companyMode
    )
      ? settings.companyMode
      : "first_available";


  if (
    companyMode.value ===
    "specific"
  ) {

    const name =
      String(
        settings.companyName ||
        ""
      ).trim();


    companyHint.textContent =
      name
        ? `${t("specificName")}${name}`
        : t("specificEmpty");


    companyHint.classList.remove(
      "hidden"
    );

    return;
  }


  if (
    companyMode.value ===
    "disabled"
  ) {

    companyHint.textContent =
      t("manualHint");

    companyHint.classList.remove(
      "hidden"
    );

    return;
  }


  companyHint.classList.add(
    "hidden"
  );
}


companyMode.addEventListener(
  "change",
  async () => {

    await saveSettings({
      companyMode:
        companyMode.value
    });

    renderCompany();
  }
);


/* =========================================================
   REFRESH
========================================================= */


refreshSeconds.addEventListener(
  "change",
  async () => {

    const value =
      Number(
        refreshSeconds.value
      );


    if (
      ![
        5,
        10,
        15,
        20,
        30
      ].includes(value)
    ) {
      return;
    }


    await saveSettings({
      refreshSeconds:
        value
    });
  }
);


/* =========================================================
   SOUND
========================================================= */


soundTone.addEventListener(
  "change",
  async () => {

    await saveSettings({
      soundTone:
        soundTone.value
    });
  }
);


soundEnabled.addEventListener(
  "change",
  async () => {

    await saveSettings({
      sound:
        soundEnabled.checked
    });
  }
);


$("#previewTone").addEventListener(
  "click",
  async () => {

    await chrome.runtime.sendMessage({
      type:
        "PREVIEW_SOUND",

      tone:
        soundTone.value
    });
  }
);


/* =========================================================
   AUTO CONFIRM
========================================================= */


function renderConfirm() {

  autoConfirm.checked =
    Boolean(
      settings.autoConfirm
    );


  confirmHint.classList.toggle(
    "hidden",
    !autoConfirm.checked
  );
}


autoConfirm.addEventListener(
  "change",
  async () => {

    await saveSettings({
      autoConfirm:
        autoConfirm.checked
    });

    renderConfirm();
  }
);


/* =========================================================
   STATUS
========================================================= */


function formatErrorDetails(
  details
) {

  if (
    !details ||
    typeof details !==
      "object"
  ) {
    return "";
  }


  const output = [];


  if (
    Array.isArray(
      details.targets
    )
  ) {

    output.push(
      `${t("branchPriority")}${details.targets.join(" ← ")}`
    );
  }


  if (
    typeof details.selectFound ===
    "boolean"
  ) {

    output.push(
      `${t("branchList")}${
        details.selectFound
          ? t("exists")
          : t("missing")
      }`
    );
  }


  if (
    Number.isFinite(
      details.optionCount
    )
  ) {

    output.push(
      `${t("branchesDetected")}${details.optionCount}`
    );
  }


  if (
    Number.isFinite(
      details.attemptsUsed
    )
  ) {

    output.push(
      `${t("companyAttempt")}${
        details.attemptsUsed
      }/${
        settings.companyAttempts ||
        2
      }`
    );
  }


  if (
    details.reason
  ) {

    output.push(
      String(
        details.reason
      )
    );
  }


  return output.join(
    " • "
  );
}


function renderStatus() {

  const phase =
    runtime.phase ||
    "idle";


  const states = {

    idle: {
      title:
        t("ready"),

      pill:
        t("stopped"),

      dot:
        ""
    },


    running: {
      title:
        t("monitoring"),

      pill:
        t("monitoringPill"),

      dot:
        "running"
    },


    opening: {
      title:
        t("opening"),

      pill:
        t("openingPill"),

      dot:
        "running"
    },


    company: {
      title:
        t("companyState"),

      pill:
        t("companyPill"),

      dot:
        "running"
    },


    branch: {
      title:
        t("branchState"),

      pill:
        t("branchPill"),

      dot:
        "running"
    },


    confirm: {
      title:
        t("confirmState"),

      pill:
        t("confirmPill"),

      dot:
        "running"
    },


    success: {
      title:
        t("success"),

      pill:
        t("successPill"),

      dot:
        "success"
    },


    cooldown: {
      title:
        t("cooldown"),

      pill:
        t("cooldownPill"),

      dot:
        "warning"
    },


    error: {
      title:
        t("error"),

      pill:
        t("errorPill"),

      dot:
        "error"
    }
  };


  const current =
    states[phase] ||
    states.idle;


  statusTitle.textContent =
    current.title;

  statusPhase.textContent =
    current.pill;

  statusMessage.textContent =
    runtime.message ||
    t("defaultMessage");

  statusDot.className =
    `status-dot ${current.dot}`;


  const hasError =
    phase === "error";


  errorPanel.classList.toggle(
    "hidden",
    !hasError
  );


  if (hasError) {

    errorMessage.textContent =
      runtime.message ||
      t("error");


    errorDetails.textContent =
      formatErrorDetails(
        runtime.errorDetails
      );


    recoverButton.disabled =
      settings.recoveryEnabled ===
        false ||
      runtime.errorDetails
        ?.recoverable ===
        false;
  }
}


/* =========================================================
   PLATFORM TAB
========================================================= */


async function activeTab() {

  const tabs =
    await chrome.tabs.query({
      active:
        true,

      currentWindow:
        true
    });


  return tabs[0];
}


function isPlatform(
  url
) {

  return String(
    url ||
    ""
  ).startsWith(
    "https://fcms.cbl.gov.ly/"
  );
}


async function deliver(
  tabId,
  message
) {

  try {

    await chrome.tabs.sendMessage(
      tabId,
      message
    );

    return true;

  } catch {

    try {

      /*
       * إذا كان تبويب المنصة مفتوحًا
       * قبل تحديث الإضافة، نحقن ملفات
       * v3.4 يدويًا ثم نعيد الإرسال.
       */

      try {

        await chrome.scripting.insertCSS({
          target: {
            tabId
          },

          files: [
            "page-notify.css"
          ]
        });

      } catch {}


      await chrome.scripting.executeScript({

        target: {
          tabId
        },

        files: [
          "branch-data.js",
          "company-data.js",
          "i18n.js",
          "diagnostic.js",
          "page-notify.js",
          "content.js"
        ]
      });


      await new Promise(
        resolve =>
          setTimeout(
            resolve,
            180
          )
      );


      await chrome.tabs.sendMessage(
        tabId,
        message
      );


      return true;

    } catch {

      return false;
    }
  }
}


/* =========================================================
   START
========================================================= */


$("#startButton").addEventListener(
  "click",
  async () => {

    /*
     * Specific company requires
     * a configured name.
     *
     * Manual mode does NOT.
     */

    if (
      companyMode.value ===
        "specific" &&
      !String(
        settings.companyName ||
        ""
      ).trim()
    ) {

      runtime = {
        ...runtime,

        phase:
          "error",

        message:
          t("selectCompanyFirst"),

        errorDetails: {
          recoverable:
            false
        }
      };


      renderStatus();

      return;
    }


    const tab =
      await activeTab();


    if (
      !tab?.id ||
      !isPlatform(
        tab.url
      )
    ) {

      runtime = {
        ...runtime,

        phase:
          "error",

        message:
          t("openPlatform"),

        errorDetails: {
          recoverable:
            false
        }
      };


      renderStatus();

      return;
    }


    const result =
      await chrome.runtime.sendMessage({

        type:
          "START_SESSION",

        tabId:
          tab.id,

        settings: {
          ...settings,

          refreshSeconds:
            Number(
              refreshSeconds.value
            ),

          companyMode:
            companyMode.value,

          sound:
            soundEnabled.checked,

          soundTone:
            soundTone.value,

          autoConfirm:
            autoConfirm.checked,

          uiLanguage:
            languageSelect.value,

          uiTheme:
            themeSelect.value,

          uiStyle:
            styleSelect.value,

          fontFamily:
            fontFamilySelect.value,

          fontScale:
            fontScaleSelect.value,

          fontWeight:
            fontWeightSelect.value
        }
      });


    if (
      !result?.ok
    ) {

      runtime = {
        ...runtime,

        phase:
          "error",

        message:
          String(
            result?.error ||
            "START_SESSION failed"
          )
      };

      renderStatus();

      return;
    }


    settings =
      result.settings ||
      settings;


    runtime =
      result.runtime ||
      runtime;


    const delivered =
      await deliver(
        tab.id,
        {
          type:
            "START_BOOKING_ASSISTANT"
        }
      );


    if (!delivered) {

      runtime = {
        ...runtime,

        phase:
          "error",

        message:
          language() === "ar"
            ? "تعذر الاتصال بصفحة المنصة. أعد تحميل الصفحة ثم جرّب."
            : "Could not connect to the platform page. Reload it and try again."
      };
    }


    renderStatus();
  }
);


/* =========================================================
   STOP
========================================================= */


$("#stopButton").addEventListener(
  "click",
  async () => {

    try {

      const tab =
        await activeTab();


      if (
        tab?.id &&
        isPlatform(
          tab.url
        )
      ) {

        await deliver(
          tab.id,
          {
            type:
              "STOP_BOOKING_ASSISTANT"
          }
        );
      }

    } catch {}


    await chrome.runtime.sendMessage({
      type:
        "STOP_SESSION"
    });


    runtime = {
      ...runtime,

      phase:
        "idle",

      message:
        t("stoppedMessage")
    };


    renderStatus();
  }
);


/* =========================================================
   RECOVERY
========================================================= */


recoverButton.addEventListener(
  "click",
  async () => {

    if (
      settings.recoveryEnabled ===
      false
    ) {
      return;
    }


    const tab =
      await activeTab();


    if (
      !tab?.id ||
      !isPlatform(
        tab.url
      )
    ) {
      return;
    }


    await deliver(
      tab.id,
      {
        type:
          "RECOVER_BOOKING_ASSISTANT"
      }
    );
  }
);


/* =========================================================
   DIAGNOSTICS
========================================================= */


$("#copyDiagnostic").addEventListener(
  "click",
  async () => {

    const stored =
      await chrome.storage.local.get(
        "cblDiagnosticLog"
      );


    const entries =
      Array.isArray(
        stored.cblDiagnosticLog
      )
        ? stored.cblDiagnosticLog
        : [];


    const text =
      entries
        .map(
          entry => {

            let line =
              `[${entry.time}] ${entry.category} ${entry.message}`;


            if (
              entry.data != null
            ) {

              line +=
                `\n${JSON.stringify(
                  entry.data,
                  null,
                  2
                )}`;
            }


            return line;
          }
        )
        .join(
          "\n\n"
        );


    if (!text) {

      statusMessage.textContent =
        t("diagnosticEmpty");

      return;
    }


    try {

      await navigator.clipboard.writeText(
        text
      );

      statusMessage.textContent =
        t("diagnosticCopied");

    } catch {

      statusMessage.textContent =
        t("diagnosticSettings");
    }
  }
);


/* =========================================================
   SETTINGS PAGE
========================================================= */


$("#settingsButton").addEventListener(
  "click",
  () => {

    chrome.runtime.openOptionsPage();
  }
);


/* =========================================================
   STORAGE CHANGES
========================================================= */


chrome.storage.onChanged.addListener(
  (
    changes,
    area
  ) => {

    if (
      area !==
      "local"
    ) {
      return;
    }


    if (
      changes.bookingRuntime
    ) {

      runtime = {
        ...runtime,
        ...(
          changes.bookingRuntime
            .newValue ||
          {}
        )
      };

      renderStatus();
    }


    if (
      changes.bookingSettings
    ) {

      settings = {
        ...settings,
        ...(
          changes.bookingSettings
            .newValue ||
          {}
        )
      };


      refreshSeconds.value =
        String(
          settings.refreshSeconds ||
          5
        );


      soundTone.value =
        settings.soundTone ||
        "bell";


      soundEnabled.checked =
        settings.sound !==
        false;


      applyAppearance();

      renderCompany();

      renderConfirm();
    }


    if (
      changes.branchCatalog
    ) {

      catalog =
        Array.isArray(
          changes.branchCatalog
            .newValue
        )
          ? changes.branchCatalog
              .newValue
          : catalog;


      renderBranches();
    }
  }
);


/* =========================================================
   INITIAL LOAD
========================================================= */


async function load() {

  const response =
    await chrome.runtime.sendMessage({
      type:
        "GET_STATE"
    });


  if (
    !response?.ok
  ) {

    throw new Error(
      response?.error ||
      "GET_STATE failed"
    );
  }


  settings =
    response.settings ||
    {};


  runtime =
    response.runtime ||
    {};


  catalog =
    response.catalog ||
    CBL_BRANCH_LIBRARY
      .createDefaultCatalog();


  /*
   * Appearance defaults.
   */

  if (
    !LANGUAGES.has(
      settings.uiLanguage
    )
  ) {
    settings.uiLanguage =
      "ar";
  }


  if (
    !THEMES.has(
      settings.uiTheme
    )
  ) {
    settings.uiTheme =
      "emerald";
  }


  if (
    !UI_STYLES.has(
      settings.uiStyle
    )
  ) {
    settings.uiStyle =
      "compact";
  }


  if (
    !FONT_FAMILIES.has(
      settings.fontFamily
    )
  ) {
    settings.fontFamily =
      "system";
  }


  if (
    !FONT_SCALES.has(
      settings.fontScale
    )
  ) {
    settings.fontScale =
      "medium";
  }


  if (
    !FONT_WEIGHTS.has(
      settings.fontWeight
    )
  ) {
    settings.fontWeight =
      "normal";
  }


  await enforceCompanyMode();


  refreshSeconds.value =
    String(
      settings.refreshSeconds ||
      5
    );


  soundTone.value =
    settings.soundTone ||
    "bell";


  soundEnabled.checked =
    settings.sound !==
    false;


  applyAppearance();

  renderBranches();

  renderCompany();

  renderConfirm();

  renderStatus();


  /*
   * حفظ defaults الجديدة
   * حتى تراها Settings لاحقًا.
   */

  await saveSettings({

    uiLanguage:
      settings.uiLanguage,

    uiTheme:
      settings.uiTheme,

    uiStyle:
      settings.uiStyle,

    fontFamily:
      settings.fontFamily,

    fontScale:
      settings.fontScale,

    fontWeight:
      settings.fontWeight
  });
}


load().catch(
  error => {

    console.error(
      "CBL popup error",
      error
    );


    runtime = {

      phase:
        "error",

      message:
        String(
          error?.message ||
          error
        )
    };


    renderStatus();
  }
);
