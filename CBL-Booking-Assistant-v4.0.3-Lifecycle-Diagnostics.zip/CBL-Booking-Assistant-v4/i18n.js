"use strict";

(() => {
  const STRINGS = {
    ar: {
      assistantName:
        "مساعد الحجز",

      ready:
        "جاهز",

      stopped:
        "متوقف",

      monitoring:
        "قيد المراقبة",

      start:
        "تشغيل",

      stop:
        "إيقاف",

      settings:
        "الإعدادات",

      appearance:
        "المظهر",

      language:
        "اللغة",

      arabic:
        "العربية",

      english:
        "English",

      theme:
        "الثيم",

      layout:
        "شكل الواجهة",

      font:
        "نوع الخط",

      fontSize:
        "حجم الخط",

      fontWeight:
        "سماكة الخط",

      normal:
        "عادي",

      bold:
        "غامق",

      targetBranch:
        "الفرع المطلوب",

      exchangeCompany:
        "شركة الصرافة",

      firstAvailable:
        "أول شركة متاحة تلقائيًا",

      specificCompany:
        "شركة محددة من القائمة",

      manualCompany:
        "اختيار الشركة يدويًا",

      refresh:
        "التحديث",

      sound:
        "الصوت",

      autoConfirm:
        "تأكيد تلقائي",

      companyOptionAppeared:
        "ظهر اختيار شركة الصرافة",

      branchFound:
        "تم العثور على الفرع",

      branchVerified:
        "تم اختيار الفرع والتحقق منه",

      companyVerified:
        "تم اعتماد شركة الصرافة",

      branchUnavailable:
        "الفرع المطلوب غير متاح",

      manualBranchRequired:
        "اختر فرعًا آخر يدويًا",

      bookingReady:
        "الحجز جاهز للتأكيد",

      confirmClicked:
        "تم الضغط على تأكيد الحجز",

      designer:
        "المصمم",

      city:
        "المدينة",

      phone:
        "الهاتف",

      email:
        "البريد الإلكتروني"
    },

    en: {
      assistantName:
        "CBL Booking Assistant",

      ready:
        "Ready",

      stopped:
        "Stopped",

      monitoring:
        "Monitoring",

      start:
        "Start",

      stop:
        "Stop",

      settings:
        "Settings",

      appearance:
        "Appearance",

      language:
        "Language",

      arabic:
        "Arabic",

      english:
        "English",

      theme:
        "Theme",

      layout:
        "Layout",

      font:
        "Font",

      fontSize:
        "Font size",

      fontWeight:
        "Font weight",

      normal:
        "Normal",

      bold:
        "Bold",

      targetBranch:
        "Target branch",

      exchangeCompany:
        "Exchange company",

      firstAvailable:
        "First available company",

      specificCompany:
        "Specific company",

      manualCompany:
        "Manual company selection",

      refresh:
        "Refresh",

      sound:
        "Sound",

      autoConfirm:
        "Auto confirm",

      companyOptionAppeared:
        "Exchange company option detected",

      branchFound:
        "Target branch found",

      branchVerified:
        "Branch selected and verified",

      companyVerified:
        "Exchange company confirmed",

      branchUnavailable:
        "Target branch unavailable",

      manualBranchRequired:
        "Select another branch manually",

      bookingReady:
        "Booking ready for confirmation",

      confirmClicked:
        "Confirm booking button clicked",

      designer:
        "Designer",

      city:
        "City",

      phone:
        "Phone",

      email:
        "Email"
    }
  };

  function normalizeLanguage(value) {
    return value === "en"
      ? "en"
      : "ar";
  }

  function getLanguage() {
    return normalizeLanguage(
      document.documentElement
        .dataset
        .cblLanguage ||
      "ar"
    );
  }

  function t(key, language = null) {
    const lang =
      normalizeLanguage(
        language ||
        getLanguage()
      );

    return (
      STRINGS[lang]?.[key] ??
      STRINGS.ar?.[key] ??
      key
    );
  }

  function applyLanguage(
    language
  ) {
    const lang =
      normalizeLanguage(
        language
      );

    document.documentElement
      .dataset
      .cblLanguage =
      lang;

    document.documentElement
      .lang =
      lang;

    document.documentElement
      .dir =
      lang === "ar"
        ? "rtl"
        : "ltr";

    return lang;
  }

  globalThis.CBLI18N =
    Object.freeze({
      STRINGS,
      t,
      applyLanguage,
      normalizeLanguage
    });
})();
