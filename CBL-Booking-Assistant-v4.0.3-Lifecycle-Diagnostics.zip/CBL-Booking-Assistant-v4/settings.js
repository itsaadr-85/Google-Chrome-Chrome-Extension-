"use strict";


const $ = selector =>
  document.querySelector(
    selector
  );


const TEXT = {

  ar: {

    settingsTitle:
      "إعدادات مساعد الحجز",

    settingsDescription:
      "إعداد الشركات والفروع والمظهر والتنبيهات والحماية.",

    appearance:
      "المظهر واللغة",

    language:
      "اللغة",

    theme:
      "الثيم",

    layout:
      "شكل الواجهة",

    fontFamily:
      "نوع الخط",

    fontSize:
      "حجم الخط",

    fontWeight:
      "سماكة الخط",

    small:
      "صغير",

    medium:
      "متوسط",

    large:
      "كبير",

    xlarge:
      "كبير جدًا",

    normal:
      "عادي",

    bold:
      "غامق",

    companySelection:
      "اختيار شركة الصرافة",

    companyMode:
      "طريقة الاختيار",

    firstAvailable:
      "أول شركة متاحة تلقائيًا",

    specificCompany:
      "شركة محددة من القائمة",

    manualCompany:
      "اختيار الشركة يدويًا",

    requiredCompany:
      "الشركة المطلوبة",

    attempts:
      "عدد المحاولات",

    companyNote:
      "النقر الحقيقي على الشركة هو الخيار الأول، ويتم التحقق من اعتماد حقول الشركة قبل اعتبار العملية ناجحة.",

    companyManager:
      "إدارة شركات الصرافة",

    companySearch:
      "ابحث في شركات الصرافة...",

    companyManagerNote:
      "★ للمفضلة — 👁 للإظهار أو الإخفاء — ↑ ↓ للترتيب. الشركات المضافة يمكن تعديلها أو حذفها.",

    newCompany:
      "اسم شركة الصرافة",

    addCompany:
      "+ إضافة شركة",

    resetCompanies:
      "استعادة الشركات الافتراضية",

    branchManager:
      "إدارة الفروع",

    branchSearch:
      "ابحث في جميع الفروع، بما فيها المخفية...",

    branchManagerNote:
      "★ للمفضلة — 👁 للإظهار أو الإخفاء — ↑ ↓ لترتيب المفضلة.",

    newBranch:
      "اسم الفرع كما يظهر بالضبط في المنصة",

    addBranch:
      "+ إضافة فرع",

    resetBranches:
      "استعادة الفروع الافتراضية",

    pageNotifications:
      "التنبيهات داخل صفحة المنصة",

    enablePageNotifications:
      "تفعيل التنبيهات داخل الصفحة",

    notificationPosition:
      "مكان التنبيه",

    notificationDuration:
      "مدة التنبيه بالثواني",

    notificationCountdown:
      "إظهار العداد التنازلي",

    notificationPageBorder:
      "إظهار إطار حول الصفحة عند الأحداث المهمة",

    topRight:
      "أعلى اليمين",

    topCenter:
      "أعلى الوسط",

    topLeft:
      "أعلى اليسار",

    middleRight:
      "وسط اليمين",

    middleLeft:
      "وسط اليسار",

    bottomRight:
      "أسفل اليمين",

    bottomCenter:
      "أسفل الوسط",

    bottomLeft:
      "أسفل اليسار",

    confirmation:
      "التأكيد",

    autoConfirm:
      "التأكيد التلقائي بعد اكتمال الشروط",

    cloudflareNote:
      "الإضافة لا تحل ولا تتجاوز Cloudflare. يجب إكماله يدويًا أولًا.",

    diagnostics:
      "التشخيص",

    enableDiagnostics:
      "تفعيل سجل التشخيص",

    diagnosticNote:
      "يسجل أحداث الفرع والشركة وLivewire بدون Cookies أو كلمات المرور أو رموز Cloudflare.",

    refreshLog:
      "تحديث السجل",

    copyLog:
      "نسخ السجل",

    clearLog:
      "مسح",

    diagnosticPlaceholder:
      "سيظهر سجل التشخيص هنا...",

    protection:
      "التعافي والحماية",

    recovery:
      "تفعيل التعافي الآمن",

    systemNotifications:
      "إشعارات النظام",

    sound:
      "التنبيهات الصوتية",

    autoResume:
      "الاستئناف الآمن بعد HTTP 429",

    about:
      "حول الإضافة",

    designer:
      "المصمم",

    city:
      "المدينة",

    phone:
      "الهاتف",

    email:
      "البريد",

    copy:
      "نسخ",

    saved:
      "✓ تم الحفظ",

    autosave:
      "يتم الحفظ تلقائيًا.",

    custom:
      "مضافة يدويًا",

    builtIn:
      "افتراضية",

    favoriteOn:
      "إزالة من المفضلة",

    favoriteOff:
      "إضافة للمفضلة",

    show:
      "إظهار",

    hide:
      "إخفاء",

    edit:
      "تعديل",

    remove:
      "حذف",

    up:
      "تحريك للأعلى",

    down:
      "تحريك للأسفل",

    duplicateCompany:
      "هذه الشركة موجودة بالفعل.",

    duplicateBranch:
      "هذا الفرع موجود بالفعل.",

    resetCompaniesConfirm:
      "هل تريد استعادة شركات الصرافة الافتراضية؟",

    resetBranchesConfirm:
      "هل تريد استعادة قائمة الفروع الافتراضية؟",

    editCompanyPrompt:
      "اكتب الاسم الجديد للشركة:",

    copied:
      "تم النسخ.",

    emptyDiagnostic:
      "سجل التشخيص فارغ.",

    copiedDiagnostic:
      "تم نسخ سجل التشخيص."
  },


  en: {

    settingsTitle:
      "CBL Booking Assistant Settings",

    settingsDescription:
      "Companies, branches, appearance, notifications and protection.",

    appearance:
      "Appearance & Language",

    language:
      "Language",

    theme:
      "Theme",

    layout:
      "Layout",

    fontFamily:
      "Font",

    fontSize:
      "Font size",

    fontWeight:
      "Font weight",

    small:
      "Small",

    medium:
      "Medium",

    large:
      "Large",

    xlarge:
      "Extra large",

    normal:
      "Normal",

    bold:
      "Bold",

    companySelection:
      "Exchange Company Selection",

    companyMode:
      "Selection mode",

    firstAvailable:
      "First available company",

    specificCompany:
      "Specific company",

    manualCompany:
      "Manual company selection",

    requiredCompany:
      "Required company",

    attempts:
      "Attempts",

    companyNote:
      "The real company element is clicked first, and platform adoption is verified before success.",

    companyManager:
      "Exchange Company Manager",

    companySearch:
      "Search exchange companies...",

    companyManagerNote:
      "★ favorite — 👁 show/hide — ↑ ↓ order. Custom companies can be edited or deleted.",

    newCompany:
      "Exchange company name",

    addCompany:
      "+ Add company",

    resetCompanies:
      "Restore default companies",

    branchManager:
      "Branch Manager",

    branchSearch:
      "Search all branches, including hidden branches...",

    branchManagerNote:
      "★ favorite — 👁 show/hide — ↑ ↓ favorite order.",

    newBranch:
      "Branch name exactly as shown by the platform",

    addBranch:
      "+ Add branch",

    resetBranches:
      "Restore default branches",

    pageNotifications:
      "In-page Notifications",

    enablePageNotifications:
      "Enable notifications inside the platform page",

    notificationPosition:
      "Notification position",

    notificationDuration:
      "Duration in seconds",

    notificationCountdown:
      "Show countdown",

    notificationPageBorder:
      "Show page border for important events",

    topRight:
      "Top right",

    topCenter:
      "Top center",

    topLeft:
      "Top left",

    middleRight:
      "Middle right",

    middleLeft:
      "Middle left",

    bottomRight:
      "Bottom right",

    bottomCenter:
      "Bottom center",

    bottomLeft:
      "Bottom left",

    confirmation:
      "Confirmation",

    autoConfirm:
      "Automatically confirm after all conditions are satisfied",

    cloudflareNote:
      "The extension does not solve or bypass Cloudflare. Complete it manually first.",

    diagnostics:
      "Diagnostics",

    enableDiagnostics:
      "Enable diagnostic log",

    diagnosticNote:
      "Logs branch, company and Livewire events without cookies, passwords or Cloudflare tokens.",

    refreshLog:
      "Refresh log",

    copyLog:
      "Copy log",

    clearLog:
      "Clear",

    diagnosticPlaceholder:
      "Diagnostic log will appear here...",

    protection:
      "Recovery & Protection",

    recovery:
      "Enable safe recovery",

    systemNotifications:
      "System notifications",

    sound:
      "Sound notifications",

    autoResume:
      "Safe resume after HTTP 429",

    about:
      "About",

    designer:
      "Designer",

    city:
      "City",

    phone:
      "Phone",

    email:
      "Email",

    copy:
      "Copy",

    saved:
      "✓ Saved",

    autosave:
      "Changes are saved automatically.",

    custom:
      "Custom",

    builtIn:
      "Built-in",

    favoriteOn:
      "Remove favorite",

    favoriteOff:
      "Add favorite",

    show:
      "Show",

    hide:
      "Hide",

    edit:
      "Edit",

    remove:
      "Delete",

    up:
      "Move up",

    down:
      "Move down",

    duplicateCompany:
      "This company already exists.",

    duplicateBranch:
      "This branch already exists.",

    resetCompaniesConfirm:
      "Restore the default exchange company list?",

    resetBranchesConfirm:
      "Restore the default branch list?",

    editCompanyPrompt:
      "Enter the new company name:",

    copied:
      "Copied.",

    emptyDiagnostic:
      "Diagnostic log is empty.",

    copiedDiagnostic:
      "Diagnostic log copied."
  }
};


let settings = {};
let branchCatalog = [];
let companyCatalog = [];


const saveStatus =
  $("#saveStatus");


function lang() {

  return settings.uiLanguage ===
    "en"
    ? "en"
    : "ar";
}


function t(key) {

  return (
    TEXT[lang()]?.[key] ??
    TEXT.ar[key] ??
    key
  );
}


function flashSaved() {

  saveStatus.textContent =
    t("saved");

  setTimeout(
    () => {
      saveStatus.textContent =
        t("autosave");
    },
    900
  );
}


async function saveSettings(
  patch = {}
) {

  settings = {
    ...settings,
    ...patch
  };

  await chrome.storage.local.set({
    bookingSettings:
      settings
  });

  flashSaved();
}


async function saveBranches() {

  await chrome.storage.local.set({
    branchCatalog
  });

  flashSaved();
}


async function saveCompanies() {

  await chrome.storage.local.set({
    companyCatalog
  });

  flashSaved();
}


/* =========================================================
   APPEARANCE
========================================================= */


function applyAppearance() {

  const theme =
    [
      "emerald",
      "midnight",
      "royal",
      "sand"
    ].includes(
      settings.uiTheme
    )
      ? settings.uiTheme
      : "emerald";


  const style =
    [
      "compact",
      "cards",
      "minimal"
    ].includes(
      settings.uiStyle
    )
      ? settings.uiStyle
      : "compact";


  const scale =
    [
      "small",
      "medium",
      "large",
      "xlarge"
    ].includes(
      settings.fontScale
    )
      ? settings.fontScale
      : "medium";


  const weight =
    settings.fontWeight ===
      "bold"
      ? "bold"
      : "normal";


  const family =
    [
      "system",
      "segoe",
      "tahoma",
      "arial"
    ].includes(
      settings.fontFamily
    )
      ? settings.fontFamily
      : "system";


  const fontMap = {

    system:
      '"Segoe UI", Tahoma, Arial, sans-serif',

    segoe:
      '"Segoe UI", sans-serif',

    tahoma:
      'Tahoma, Arial, sans-serif',

    arial:
      'Arial, sans-serif'
  };


  document.documentElement.lang =
    lang();

  document.documentElement.dir =
    lang() === "ar"
      ? "rtl"
      : "ltr";

  document.documentElement.dataset.theme =
    theme;

  document.documentElement.dataset.fontScale =
    scale;

  document.documentElement.dataset.fontWeight =
    weight;

  document.documentElement.style.setProperty(
    "--ui-font",
    fontMap[family]
  );

  document.body.dataset.uiStyle =
    style;


  $("#uiLanguage").value =
    lang();

  $("#uiTheme").value =
    theme;

  $("#uiStyle").value =
    style;

  $("#fontFamily").value =
    family;

  $("#fontScale").value =
    scale;

  $("#fontWeight").value =
    weight;


  applyTranslations();
}


function applyTranslations() {

  document
    .querySelectorAll(
      "[data-i18n]"
    )
    .forEach(
      element => {

        const key =
          element.dataset.i18n;

        if (
          TEXT[lang()]?.[key]
        ) {
          element.textContent =
            t(key);
        }
      }
    );


  document
    .querySelectorAll(
      "[data-i18n-placeholder]"
    )
    .forEach(
      element => {

        element.placeholder =
          t(
            element.dataset
              .i18nPlaceholder
          );
      }
    );


  saveStatus.textContent =
    t("autosave");


  renderBranches();
  renderCompanies();
  renderSpecificCompany();
}


/* =========================================================
   BUTTON HELPER
========================================================= */


function actionButton(
  text,
  title,
  handler,
  active = false
) {

  const button =
    document.createElement(
      "button"
    );

  button.type =
    "button";

  button.textContent =
    text;

  button.title =
    title;

  if (active) {
    button.classList.add(
      "active"
    );
  }

  button.addEventListener(
    "click",
    handler
  );

  return button;
}


/* =========================================================
   COMPANY CATALOG
========================================================= */


function companyOrder() {

  return Math.max(
    -1,
    ...companyCatalog.map(
      item =>
        Number(item.order) || 0
    )
  ) + 1;
}


function visibleCompanies() {

  const query =
    CBL_COMPANY_LIBRARY
      .normalizeCompanyName(
        $("#companySearch").value
      );


  return [...companyCatalog]
    .filter(
      item => {

        if (!query) {
          return true;
        }

        return CBL_COMPANY_LIBRARY
          .normalizeCompanyName(
            item.name
          )
          .includes(
            query
          );
      }
    )
    .sort(
      (a, b) => {

        if (
          Boolean(a.hidden) !==
          Boolean(b.hidden)
        ) {
          return a.hidden
            ? 1
            : -1;
        }

        if (
          Boolean(a.favorite) !==
          Boolean(b.favorite)
        ) {
          return a.favorite
            ? -1
            : 1;
        }

        return (
          Number(a.order) -
          Number(b.order)
        );
      }
    );
}


function moveCompany(
  item,
  direction
) {

  const list =
    [...companyCatalog]
      .filter(
        entry =>
          entry.favorite &&
          !entry.hidden
      )
      .sort(
        (a, b) =>
          Number(a.order) -
          Number(b.order)
      );


  const index =
    list.findIndex(
      entry =>
        entry.id === item.id
    );


  const next =
    index + direction;


  if (
    index < 0 ||
    next < 0 ||
    next >= list.length
  ) {
    return;
  }


  const other =
    list[next];

  const temp =
    item.order;

  item.order =
    other.order;

  other.order =
    temp;
}


function renderCompanies() {

  const list =
    $("#companyList");

  list.replaceChildren();


  const companies =
    visibleCompanies();


  $("#companyCount").textContent =
    String(
      companyCatalog.length
    );


  for (
    const item of companies
  ) {

    const row =
      document.createElement(
        "div"
      );

    row.className =
      "manager-row";


    if (item.hidden) {

      row.classList.add(
        "hidden-item"
      );
    }


    const info =
      document.createElement(
        "div"
      );

    info.className =
      "item-name";


    const name =
      document.createElement(
        "strong"
      );

    name.textContent =
      item.name;


    const meta =
      document.createElement(
        "span"
      );

    meta.className =
      "item-meta";

    meta.textContent =
      item.custom
        ? t("custom")
        : t("builtIn");


    info.append(
      name,
      meta
    );


    const actions =
      document.createElement(
        "div"
      );

    actions.className =
      "row-actions";


    actions.append(
      actionButton(
        item.favorite
          ? "★"
          : "☆",

        item.favorite
          ? t("favoriteOn")
          : t("favoriteOff"),

        async () => {

          item.favorite =
            !item.favorite;

          if (item.favorite) {
            item.hidden =
              false;

            item.order =
              companyOrder();
          }

          await saveCompanies();

          renderCompanies();
          renderSpecificCompany();
        },

        item.favorite
      )
    );


    actions.append(
      actionButton(
        item.hidden
          ? "🙈"
          : "👁",

        item.hidden
          ? t("show")
          : t("hide"),

        async () => {

          item.hidden =
            !item.hidden;

          if (item.hidden) {
            item.favorite =
              false;
          }

          await saveCompanies();

          renderCompanies();
          renderSpecificCompany();
        },

        !item.hidden
      )
    );


    actions.append(
      actionButton(
        "↑",
        t("up"),

        async () => {

          moveCompany(
            item,
            -1
          );

          await saveCompanies();

          renderCompanies();
          renderSpecificCompany();
        }
      )
    );


    actions.append(
      actionButton(
        "↓",
        t("down"),

        async () => {

          moveCompany(
            item,
            1
          );

          await saveCompanies();

          renderCompanies();
          renderSpecificCompany();
        }
      )
    );


    if (item.custom) {

      actions.append(
        actionButton(
          "✎",
          t("edit"),

          async () => {

            const next =
              prompt(
                t("editCompanyPrompt"),
                item.name
              );


            if (
              next == null
            ) {
              return;
            }


            const name =
              String(next)
                .trim();


            if (!name) {
              return;
            }


            const duplicate =
              companyCatalog.some(
                other =>
                  other.id !==
                    item.id &&
                  CBL_COMPANY_LIBRARY
                    .namesEqual(
                      other.name,
                      name
                    )
              );


            if (duplicate) {

              alert(
                t("duplicateCompany")
              );

              return;
            }


            const oldName =
              item.name;

            item.name =
              name;


            if (
              CBL_COMPANY_LIBRARY
                .namesEqual(
                  settings.companyName,
                  oldName
                )
            ) {

              await saveSettings({
                companyName:
                  name
              });
            }


            await saveCompanies();

            renderCompanies();
            renderSpecificCompany();
          }
        )
      );


      actions.append(
        actionButton(
          "×",
          t("remove"),

          async () => {

            const wasSelected =
              CBL_COMPANY_LIBRARY
                .namesEqual(
                  settings.companyName,
                  item.name
                );


            companyCatalog =
              companyCatalog.filter(
                entry =>
                  entry.id !== item.id
              );


            await saveCompanies();


            if (wasSelected) {

              await saveSettings({
                companyName: ""
              });
            }


            renderCompanies();
            renderSpecificCompany();
          }
        )
      );
    }


    row.append(
      info,
      actions
    );


    list.append(
      row
    );
  }
}


function renderSpecificCompany() {

  const select =
    $("#specificCompany");

  select.replaceChildren();


  const visible =
    [...companyCatalog]
      .filter(
        item =>
          !item.hidden
      )
      .sort(
        (a, b) => {

          if (
            Boolean(a.favorite) !==
            Boolean(b.favorite)
          ) {
            return a.favorite
              ? -1
              : 1;
          }

          return (
            Number(a.order) -
            Number(b.order)
          );
        }
      );


  const empty =
    document.createElement(
      "option"
    );

  empty.value =
    "";

  empty.textContent =
    lang() === "ar"
      ? "— اختر الشركة —"
      : "— Select company —";

  select.append(
    empty
  );


  for (
    const item of visible
  ) {

    const option =
      document.createElement(
        "option"
      );

    option.value =
      item.name;

    option.textContent =
      item.name;

    select.append(
      option
    );
  }


  const current =
    String(
      settings.companyName ||
      ""
    );


  if (
    current &&
    !visible.some(
      item =>
        CBL_COMPANY_LIBRARY
          .namesEqual(
            item.name,
            current
          )
    )
  ) {

    const option =
      document.createElement(
        "option"
      );

    option.value =
      current;

    option.textContent =
      `✓ ${current}`;

    select.append(
      option
    );
  }


  select.value =
    current;


  $("#specificCompanyWrap")
    .classList
    .toggle(
      "hidden",
      $("#companyMode").value !==
        "specific"
    );
}


/* =========================================================
   BRANCH CATALOG
========================================================= */


function branchOrder() {

  return Math.max(
    -1,
    ...branchCatalog.map(
      item =>
        Number(item.order) || 0
    )
  ) + 1;
}


function visibleBranches() {

  const query =
    CBL_BRANCH_LIBRARY
      .normalizeArabic(
        $("#branchSearch").value
      );


  return [...branchCatalog]
    .filter(
      item => {

        if (!query) {
          return true;
        }

        return CBL_BRANCH_LIBRARY
          .normalizeArabic(
            item.name
          )
          .includes(
            query
          );
      }
    )
    .sort(
      (a, b) => {

        if (
          Boolean(a.hidden) !==
          Boolean(b.hidden)
        ) {
          return a.hidden
            ? 1
            : -1;
        }

        if (
          Boolean(a.favorite) !==
          Boolean(b.favorite)
        ) {
          return a.favorite
            ? -1
            : 1;
        }

        return (
          Number(a.order) -
          Number(b.order)
        );
      }
    );
}


function moveBranch(
  item,
  direction
) {

  const list =
    branchCatalog
      .filter(
        entry =>
          entry.favorite &&
          !entry.hidden
      )
      .sort(
        (a, b) =>
          Number(a.order) -
          Number(b.order)
      );


  const index =
    list.findIndex(
      entry =>
        entry.id === item.id
    );


  const next =
    index + direction;


  if (
    index < 0 ||
    next < 0 ||
    next >= list.length
  ) {
    return;
  }


  const other =
    list[next];

  const temporary =
    item.order;

  item.order =
    other.order;

  other.order =
    temporary;
}


function renderBranches() {

  const list =
    $("#branchList");

  list.replaceChildren();


  $("#branchCount").textContent =
    String(
      branchCatalog.length
    );


  for (
    const item of
    visibleBranches()
  ) {

    const row =
      document.createElement(
        "div"
      );

    row.className =
      "manager-row";


    if (item.hidden) {

      row.classList.add(
        "hidden-item"
      );
    }


    const info =
      document.createElement(
        "div"
      );

    info.className =
      "item-name";


    const name =
      document.createElement(
        "strong"
      );

    name.textContent =
      item.name;


    const meta =
      document.createElement(
        "span"
      );

    meta.className =
      "item-meta";

    meta.textContent =
      item.custom
        ? t("custom")
        : t("builtIn");


    info.append(
      name,
      meta
    );


    const actions =
      document.createElement(
        "div"
      );

    actions.className =
      "row-actions";


    actions.append(
      actionButton(
        item.favorite
          ? "★"
          : "☆",

        item.favorite
          ? t("favoriteOn")
          : t("favoriteOff"),

        async () => {

          item.favorite =
            !item.favorite;

          if (item.favorite) {

            item.hidden =
              false;

            item.order =
              branchOrder();
          }

          await saveBranches();

          renderBranches();
        },

        item.favorite
      )
    );


    actions.append(
      actionButton(
        item.hidden
          ? "🙈"
          : "👁",

        item.hidden
          ? t("show")
          : t("hide"),

        async () => {

          item.hidden =
            !item.hidden;

          if (item.hidden) {
            item.favorite =
              false;
          }

          await saveBranches();

          renderBranches();
        },

        !item.hidden
      )
    );


    actions.append(
      actionButton(
        "↑",
        t("up"),

        async () => {

          moveBranch(
            item,
            -1
          );

          await saveBranches();

          renderBranches();
        }
      )
    );


    actions.append(
      actionButton(
        "↓",
        t("down"),

        async () => {

          moveBranch(
            item,
            1
          );

          await saveBranches();

          renderBranches();
        }
      )
    );


    if (item.custom) {

      actions.append(
        actionButton(
          "×",
          t("remove"),

          async () => {

            branchCatalog =
              branchCatalog.filter(
                entry =>
                  entry.id !==
                  item.id
              );

            await saveBranches();

            renderBranches();
          }
        )
      );
    }


    row.append(
      info,
      actions
    );


    list.append(
      row
    );
  }
}


/* =========================================================
   COMPANY EVENTS
========================================================= */


$("#companyMode")
  .addEventListener(
    "change",
    async () => {

      await saveSettings({
        companyMode:
          $("#companyMode").value
      });

      renderSpecificCompany();
    }
  );


$("#specificCompany")
  .addEventListener(
    "change",
    async () => {

      await saveSettings({
        companyName:
          $("#specificCompany")
            .value
      });
    }
  );


$("#companyAttempts")
  .addEventListener(
    "change",
    async () => {

      const value =
        Math.max(
          1,
          Math.min(
            3,
            Number(
              $("#companyAttempts")
                .value
            ) || 2
          )
        );

      await saveSettings({
        companyAttempts:
          value
      });
    }
  );


$("#companySearch")
  .addEventListener(
    "input",
    renderCompanies
  );


$("#addCompany")
  .addEventListener(
    "click",
    async () => {

      const input =
        $("#newCompanyName");

      const name =
        input.value.trim();


      if (!name) {
        return;
      }


      if (
        companyCatalog.some(
          item =>
            CBL_COMPANY_LIBRARY
              .namesEqual(
                item.name,
                name
              )
        )
      ) {

        alert(
          t("duplicateCompany")
        );

        return;
      }


      companyCatalog.push({

        id:
          `custom-company-${Date.now()}`,

        name,

        favorite:
          true,

        hidden:
          false,

        custom:
          true,

        order:
          companyOrder()
      });


      input.value =
        "";


      await saveCompanies();

      renderCompanies();
      renderSpecificCompany();
    }
  );


$("#resetCompanies")
  .addEventListener(
    "click",
    async () => {

      if (
        !confirm(
          t(
            "resetCompaniesConfirm"
          )
        )
      ) {
        return;
      }


      companyCatalog =
        CBL_COMPANY_LIBRARY
          .createDefaultCatalog();


      await saveCompanies();


      const selectedExists =
        companyCatalog.some(
          item =>
            CBL_COMPANY_LIBRARY
              .namesEqual(
                item.name,
                settings.companyName
              )
        );


      if (
        settings.companyName &&
        !selectedExists
      ) {

        await saveSettings({
          companyName: ""
        });
      }


      renderCompanies();
      renderSpecificCompany();
    }
  );


/* =========================================================
   BRANCH EVENTS
========================================================= */


$("#branchSearch")
  .addEventListener(
    "input",
    renderBranches
  );


$("#addBranch")
  .addEventListener(
    "click",
    async () => {

      const input =
        $("#newBranchName");

      const name =
        input.value.trim();


      if (!name) {
        return;
      }


      const normalized =
        CBL_BRANCH_LIBRARY
          .normalizeArabic(
            name
          );


      if (
        branchCatalog.some(
          item =>
            CBL_BRANCH_LIBRARY
              .normalizeArabic(
                item.name
              ) ===
              normalized
        )
      ) {

        alert(
          t("duplicateBranch")
        );

        return;
      }


      branchCatalog.push({

        id:
          `custom-${Date.now()}`,

        name,

        targets: [
          name
        ],

        special:
          false,

        favorite:
          true,

        hidden:
          false,

        custom:
          true,

        order:
          branchOrder()
      });


      input.value =
        "";


      await saveBranches();

      renderBranches();
    }
  );


$("#resetBranches")
  .addEventListener(
    "click",
    async () => {

      if (
        !confirm(
          t(
            "resetBranchesConfirm"
          )
        )
      ) {
        return;
      }


      branchCatalog =
        CBL_BRANCH_LIBRARY
          .createDefaultCatalog();


      await saveBranches();


      await saveSettings({
        selectedBranchId:
          "pair-tobruk-musaid"
      });


      renderBranches();
    }
  );


/* =========================================================
   SIMPLE SETTINGS
========================================================= */


function bindSelect(
  selector,
  key
) {

  $(selector)
    .addEventListener(
      "change",
      async event => {

        await saveSettings({
          [key]:
            event.target.value
        });


        if (
          [
            "uiLanguage",
            "uiTheme",
            "uiStyle",
            "fontFamily",
            "fontScale",
            "fontWeight"
          ].includes(key)
        ) {

          if ($("#waitForTargetBranch")) $("#waitForTargetBranch").checked = settings.waitForTargetBranch !== false;
  if ($("#branchRefreshSeconds")) $("#branchRefreshSeconds").value = String(Math.max(.5, Math.min(30, Number(settings.branchRefreshSeconds)||2)));
  if ($("#notificationOpacity")) $("#notificationOpacity").value = String(Math.max(20, Math.min(100, Number(settings.notificationOpacity)||88)));
  if ($("#glassTheme")) $("#glassTheme").value = settings.glassTheme || "midnight";

  applyAppearance();
        }
      }
    );
}


function bindCheckbox(
  selector,
  key
) {

  $(selector)
    .addEventListener(
      "change",
      async event => {

        await saveSettings({
          [key]:
            event.target.checked
        });
      }
    );
}


bindSelect(
  "#uiLanguage",
  "uiLanguage"
);

bindSelect(
  "#uiTheme",
  "uiTheme"
);

bindSelect(
  "#uiStyle",
  "uiStyle"
);

bindSelect(
  "#fontFamily",
  "fontFamily"
);

bindSelect(
  "#fontScale",
  "fontScale"
);

bindSelect(
  "#fontWeight",
  "fontWeight"
);

bindSelect(
  "#notificationPosition",
  "notificationPosition"
);


bindCheckbox(
  "#pageNotifications",
  "pageNotifications"
);

bindCheckbox(
  "#notificationCountdown",
  "notificationCountdown"
);

bindCheckbox(
  "#notificationPageBorder",
  "notificationPageBorder"
);

bindCheckbox(
  "#autoConfirm",
  "autoConfirm"
);

bindCheckbox(
  "#diagnosticsEnabled",
  "diagnosticsEnabled"
);

bindCheckbox(
  "#recoveryEnabled",
  "recoveryEnabled"
);

bindCheckbox(
  "#notifications",
  "notifications"
);

bindCheckbox(
  "#sound",
  "sound"
);

bindCheckbox("#pauseOnMouseMove", "pauseOnMouseMove");

$("#settingsSoundTone")?.addEventListener("change", async () => { await saveSettings({soundTone: $("#settingsSoundTone").value}); });

bindCheckbox(
  "#autoResume",
  "autoResumeAfterRateLimit"
);


$("#notificationDuration")
  .addEventListener(
    "change",
    async () => {

      const value =
        Math.max(
          0.1,
          Math.min(
            30,
            Number(
              $("#notificationDuration")
                .value
            ) || 5
          )
        );


      $("#notificationDuration")
        .value =
        String(value);


      await saveSettings({
        notificationDuration:
          value
      });
    }
  );


$("#waitForTargetBranch")?.addEventListener("change", async()=>saveSettings({waitForTargetBranch:$("#waitForTargetBranch").checked}));
$("#branchRefreshSeconds")?.addEventListener("change", async()=>{const v=Math.max(.5,Math.min(30,Number($("#branchRefreshSeconds").value)||2)); $("#branchRefreshSeconds").value=v; await saveSettings({branchRefreshSeconds:v});});
$("#notificationOpacity")?.addEventListener("input", async()=>saveSettings({notificationOpacity:Number($("#notificationOpacity").value)||88}));
$("#glassTheme")?.addEventListener("change", async()=>saveSettings({glassTheme:$("#glassTheme").value}));

/* =========================================================
   DIAGNOSTICS
========================================================= */


function formatDiagnostic(
  entries
) {

  return entries
    .map(
      entry => {

        let line =
          `[${entry.time}] ${entry.category} ${entry.message}`;


        if (
          entry.data != null
        ) {

          line +=
            `\n${JSON.stringify(
              entry.data,
              null,
              2
            )}`;
        }


        return line;
      }
    )
    .join(
      "\n\n"
    );
}


async function loadDiagnostic() {

  const stored =
    await chrome.storage.local.get(
      "cblDiagnosticLog"
    );


  const entries =
    Array.isArray(
      stored.cblDiagnosticLog
    )
      ? stored.cblDiagnosticLog
      : [];


  $("#diagnosticLog").value =
    formatDiagnostic(
      entries
    );
}


$("#refreshLog")
  .addEventListener(
    "click",
    loadDiagnostic
  );


$("#clearLog")
  .addEventListener(
    "click",
    async () => {

      await chrome.storage.local.set({
        cblDiagnosticLog: []
      });

      $("#diagnosticLog").value =
        "";
    }
  );


$("#copyLog")
  .addEventListener(
    "click",
    async () => {

      await loadDiagnostic();


      const value =
        $("#diagnosticLog").value;


      if (!value) {

        alert(
          t("emptyDiagnostic")
        );

        return;
      }


      try {

        await navigator.clipboard
          .writeText(
            value
          );


        alert(
          t("copiedDiagnostic")
        );

      } catch {

        $("#diagnosticLog")
          .select();

        document.execCommand(
          "copy"
        );
      }
    }
  );


/* =========================================================
   ABOUT COPY BUTTONS
========================================================= */


document
  .querySelectorAll(
    "[data-copy]"
  )
  .forEach(
    button => {

      button.addEventListener(
        "click",
        async () => {

          const value =
            button.dataset.copy;


          try {

            await navigator.clipboard
              .writeText(
                value
              );

            button.textContent =
              "✓";

            setTimeout(
              () => {
                button.textContent =
                  t("copy");
              },
              900
            );

          } catch {}
        }
      );
    }
  );


/* =========================================================
   LOAD
========================================================= */


async function load() {

  const response =
    await chrome.runtime
      .sendMessage({
        type:
          "GET_STATE"
      });


  if (
    !response?.ok
  ) {

    throw new Error(
      response?.error ||
      "GET_STATE failed"
    );
  }


  settings =
    response.settings ||
    {};


  branchCatalog =
    response.catalog ||
    CBL_BRANCH_LIBRARY
      .createDefaultCatalog();


  const stored =
    await chrome.storage.local.get(
      "companyCatalog"
    );


  if (
    Array.isArray(
      stored.companyCatalog
    ) &&
    stored.companyCatalog.length
  ) {

    companyCatalog =
      stored.companyCatalog;

  } else {

    companyCatalog =
      CBL_COMPANY_LIBRARY
        .createDefaultCatalog();


    await chrome.storage.local.set({
      companyCatalog
    });
  }


  settings.uiLanguage =
    settings.uiLanguage ===
      "en"
      ? "en"
      : "ar";


  settings.uiTheme =
    [
      "emerald",
      "midnight",
      "royal",
      "sand"
    ].includes(
      settings.uiTheme
    )
      ? settings.uiTheme
      : "emerald";


  settings.uiStyle =
    [
      "compact",
      "cards",
      "minimal"
    ].includes(
      settings.uiStyle
    )
      ? settings.uiStyle
      : "compact";


  settings.fontFamily =
    [
      "system",
      "segoe",
      "tahoma",
      "arial"
    ].includes(
      settings.fontFamily
    )
      ? settings.fontFamily
      : "system";


  settings.fontScale =
    [
      "small",
      "medium",
      "large",
      "xlarge"
    ].includes(
      settings.fontScale
    )
      ? settings.fontScale
      : "medium";


  settings.fontWeight =
    settings.fontWeight ===
      "bold"
      ? "bold"
      : "normal";


  $("#companyMode").value =
    [
      "first_available",
      "random_from_5",
      "specific",
      "disabled"
    ].includes(
      settings.companyMode
    )
      ? settings.companyMode
      : "first_available";


  $("#companyAttempts").value =
    String(
      Math.max(
        1,
        Math.min(
          3,
          Number(
            settings.companyAttempts
          ) || 2
        )
      )
    );


  $("#pageNotifications").checked =
    settings.pageNotifications !==
    false;


  $("#notificationPosition").value =
    settings.notificationPosition ||
    "top-center";


  $("#notificationDuration").value =
    String(
      Math.max(
        1,
        Math.min(
          30,
          Number(
            settings.notificationDuration
          ) || 5
        )
      )
    );


  $("#notificationCountdown").checked =
    settings.notificationCountdown !==
    false;


  $("#notificationPageBorder").checked =
    settings.notificationPageBorder !==
    false;


  $("#autoConfirm").checked =
    Boolean(
      settings.autoConfirm
    );


  $("#diagnosticsEnabled").checked =
    Boolean(
      settings.diagnosticsEnabled
    );


  $("#recoveryEnabled").checked =
    settings.recoveryEnabled !==
    false;


  $("#notifications").checked =
    settings.notifications !==
    false;


  $("#sound").checked =
    settings.sound !==
    false;


  $("#autoResume").checked =
    settings.autoResumeAfterRateLimit !==
    false;


  if ($("#waitForTargetBranch")) $("#waitForTargetBranch").checked = settings.waitForTargetBranch !== false;
  if ($("#branchRefreshSeconds")) $("#branchRefreshSeconds").value = String(Math.max(.5, Math.min(30, Number(settings.branchRefreshSeconds)||2)));
  if ($("#notificationOpacity")) $("#notificationOpacity").value = String(Math.max(20, Math.min(100, Number(settings.notificationOpacity)||88)));
  if ($("#glassTheme")) $("#glassTheme").value = settings.glassTheme || "midnight";

  applyAppearance();

  renderCompanies();

  renderBranches();

  renderSpecificCompany();

  await loadDiagnostic();


  /*
   * نحفظ القيم الافتراضية الجديدة
   * في أول فتح للإعدادات.
   */
  await chrome.storage.local.set({

    bookingSettings: {
      ...settings,

      companyAttempts:
        Number(
          $("#companyAttempts").value
        ),

      pageNotifications:
        $("#pageNotifications").checked,

      notificationPosition:
        $("#notificationPosition").value,

      notificationDuration:
        Number(
          $("#notificationDuration").value
        ),

      notificationCountdown:
        $("#notificationCountdown").checked,

      notificationPageBorder:
        $("#notificationPageBorder").checked
    }
  });
}


load().catch(
  error => {

    console.error(
      "CBL settings error",
      error
    );

    saveStatus.textContent =
      String(
        error?.message ||
        error
      );
  }
);
