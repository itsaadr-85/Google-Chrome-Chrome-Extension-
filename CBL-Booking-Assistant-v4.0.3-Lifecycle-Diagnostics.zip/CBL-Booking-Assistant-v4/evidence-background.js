"use strict";

// Isolated trial feature. Booking selection and confirmation code remains unchanged.
(() => {
  const STATE_KEY = "cblEvidenceTrialSession";
  const OPTIONS_KEY = "cblEvidenceTrialOptions";
  const HISTORY_KEY = "cblEvidenceTrialHistory";
  const SITE_ORIGIN = "https://fcms.cbl.gov.ly";
  const PENDING_LIFETIME = 20 * 60 * 1000;
  let queue = Promise.resolve();
  const tabEpochs = new Map();
  let pendingSequence = 0;

  function epoch(tabId) { return tabEpochs.get(tabId) || 0; }
  function pendingId(tabId) {
    return globalThis.crypto?.randomUUID?.() || `${tabId}-${Date.now()}-${++pendingSequence}`;
  }
  function requestPath(url) {
    try {
      const path = new URL(url).pathname;
      return path.match(/^(.*\/purchase-requests\/[^/]+)(?:\/|$)/)?.[1] || path;
    } catch { return ""; }
  }
  function sameRequest(url, path) {
    if (!siteUrl(url) || !path) return false;
    try {
      const current = new URL(url).pathname;
      return current === path || (/\/purchase-requests\/[^/]+$/.test(path) && current.startsWith(path + "/"));
    } catch { return false; }
  }
  function cancelled() {
    const error = new Error("توقف حفظ الإثبات بعد إغلاق صفحة الحجز أو مغادرتها أو بدء محاولة أخرى.");
    error.code = "EVIDENCE_CANCELLED";
    return error;
  }
  function contextCurrent(binding) {
    const effects = globalThis.CBLPageEffects;
    return epoch(binding.tabId) === binding.epoch && (!effects?.context ||
      effects.context(binding.tabId).generation === binding.context.generation);
  }
  async function checkExport(binding, completed = false) {
    if (!contextCurrent(binding)) throw cancelled();
    const effects = globalThis.CBLPageEffects;
    if (effects?.isPlatformTab && !await effects.isPlatformTab(binding.tabId)) throw cancelled();
    let tab;
    try { tab = await chrome.tabs.get(binding.tabId); } catch { throw cancelled(); }
    if (!contextCurrent(binding) || !sameRequest(tab.pendingUrl || tab.url, binding.path)) throw cancelled();
    const current = await state();
    if (!contextCurrent(binding)) throw cancelled();
    const matches = completed ? !current.pending && current.lastExportId === binding.id :
      current.pending?.id === binding.id && current.pending.tabId === binding.tabId;
    if (!matches) throw cancelled();
    // Account for a navigation delivered while storage/session checks awaited.
    try { tab = await chrome.tabs.get(binding.tabId); } catch { throw cancelled(); }
    if (!contextCurrent(binding) || !sameRequest(tab.pendingUrl || tab.url, binding.path)) throw cancelled();
    return tab;
  }
  async function cancelTab(tabId) {
    if (!Number.isInteger(tabId)) return;
    tabEpochs.set(tabId, epoch(tabId) + 1); // Invalidate before waiting for the state queue.
    await serial(async () => {
      const current = await state();
      if (current.pending?.tabId === tabId) {
        current.pending = null;
        await put(current);
      }
    });
  }
  globalThis.CBLEvidence = { cancelTab };

  function serial(task) {
    const next = queue.then(task, task);
    queue = next.catch(() => {});
    return next;
  }
  async function state() {
    const data = await chrome.storage.session.get(STATE_KEY);
    return { name: "", accounts: {}, accountsById: {}, selectedIban: "", pending: null,
      lastExport: "", ...(data[STATE_KEY] || {}) };
  }
  async function put(value) {
    await chrome.storage.session.set({ [STATE_KEY]: value });
    return value;
  }
  async function options() {
    const data = await chrome.storage.local.get(OPTIONS_KEY);
    return { autoImage: true, autoText: true, folder: "CBL-Bookings",
      filenamePattern: "{name}_{date}_{time}",
      saveAs: false, notifySaved: true, ...(data[OPTIONS_KEY] || {}) };
  }
  function folderName(value) {
    const name = String(value || "CBL-Bookings").trim()
      .replace(/[\\/:*?"<>|\x00-\x1F]/g, "_")
      .replace(/\.\./g, "_").replace(/^\.+|\.+$/g, "").slice(0, 50);
    return name || "CBL-Bookings";
  }
  function siteUrl(url) {
    try { return new URL(url).origin === SITE_ORIGIN; } catch { return false; }
  }
  function accountId(value) {
    const id = String(value || "").toLowerCase();
    return /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(id) ? id : "";
  }
  function requestAccountId(url) {
    try {
      const path = new URL(url).pathname;
      return accountId(path.match(/\/bank-accounts\/([^/]+)(?:\/|$)/i)?.[1]);
    } catch { return ""; }
  }
  function inputAccount(value) {
    const iban = String(value?.iban || "").replace(/\s/g, "").toUpperCase();
    const accountNumber = String(value?.accountNumber || "").replace(/\s/g, "");
    const bank = String(value?.bank || "").trim().slice(0, 100);
    if (!/^LY\d{23}$/.test(iban) || !/^\d{8,25}$/.test(accountNumber) ||
        !/(مصرف|بنك|bank)/i.test(bank)) return null;
    return { iban, accountNumber, bank };
  }
  function filenameName(value, maxLength = 65) {
    return String(value || "صاحب_الحساب").trim()
      .replace(/[\\/:*?"<>|\x00-\x1F]/g, "_")
      .replace(/\s+/g, "_").replace(/^\.+|\.+$/g, "")
      .slice(0, maxLength) || "صاحب_الحساب";
  }
  function baseName(name, time, pattern) {
    const [date,clock] = time.split("_");
    const rendered = String(pattern || "{name}_{date}_{time}")
      .replaceAll("{name}",filenameName(name))
      .replaceAll("{date}",date)
      .replaceAll("{time}",clock);
    return filenameName(rendered,100);
  }
  function stamp() {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Tripoli", year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23"
    }).formatToParts(new Date());
    const p = key => parts.find(part => part.type === key)?.value || "00";
    return `${p("year")}-${p("month")}-${p("day")}_${p("hour")}${p("minute")}${p("second")}`;
  }
  async function saveText(name, account, time, trial = false, check = null) {
    if (!name || !account) throw new Error("افتح الصفحة الرئيسية لقراءة الاسم، ثم اعتمد الحساب من صفحة تفاصيله.");
    const content = [
      "بيانات الحساب المرتبط بالحجز", "",
      `اسم صاحب الحساب: ${name}`,
      `المصرف: ${account.bank}`,
      `رقم الحساب المصرفي الدولي (IBAN): ${account.iban}`,
      `رقم الحساب: ${account.accountNumber}`,
      `وقت الحفظ (طرابلس): ${time}`,
      trial ? "الحالة: ملف تجربة من الحساب الذي اعتمده المستخدم" :
        "الحالة: حُفظ بعد ظهور رسالة نجاح الحجز"
    ].join("\r\n");
    const choice = await options();
    if (check) await check();
    const result = await chrome.downloads.download({
      url: "data:text/plain;charset=utf-8," + encodeURIComponent("\uFEFF" + content),
      filename: `${folderName(choice.folder)}/${baseName(name,time,choice.filenamePattern)}${trial ? "_تجربة" : ""}_بيانات_الحساب.txt`,
      conflictAction: "uniquify", saveAs: choice.saveAs
    });
    if (check) await check();
    return result;
  }
  async function saveImage(tabId, name, time, trial = false, check = null) {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active || !siteUrl(tab.url)) {
      throw new Error("صفحة الحجز ليست علامة التبويب النشطة؛ افتحها لالتقاط صورة الإثبات.");
    }
    const imagePath = requestPath(tab.pendingUrl || tab.url);
    const checkImageTab = async () => {
      const current = await chrome.tabs.get(tabId);
      if (!current.active || !sameRequest(current.pendingUrl || current.url,imagePath)) {
        throw new Error("تغيرت صفحة الصورة أثناء الالتقاط؛ لم تُحفظ صورة من صفحة أخرى.");
      }
    };
    if (check) await check();
    const image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    if (check) await check();
    await checkImageTab();
    const choice = await options();
    if (check) await check();
    await checkImageTab();
    const result = await chrome.downloads.download({
      url: image,
      filename: `${folderName(choice.folder)}/${baseName(name,time,choice.filenamePattern)}${trial ? "_تجربة" : ""}_صورة.png`,
      conflictAction: "uniquify", saveAs: choice.saveAs
    });
    if (check) await check();
    return result;
  }
  function selectedAccount(current, ibans = [], requestId = "") {
    const disclosed = [...new Set(ibans.filter(iban => /^LY\d{23}$/.test(iban)))];
    if (disclosed.length > 1) return null;
    const matchedIban = requestId && current.accountsById?.[requestId];
    if (matchedIban) {
      if (disclosed.length && disclosed[0] !== matchedIban) return null;
      return current.accounts[matchedIban] || null;
    }
    if (requestId) {
      return disclosed.length ? current.accounts[disclosed[0]] || null : null;
    }
    if (disclosed.length === 1) {
      if (current.selectedIban && current.selectedIban !== disclosed[0]) return null;
      return current.accounts[disclosed[0]] || null;
    }
    return current.accounts[current.selectedIban] || null;
  }

  async function exportOnSuccess(tabId, visibleIban) {
    const binding = {
      tabId, epoch: epoch(tabId), id: "", path: "",
      context: globalThis.CBLPageEffects?.context?.(tabId) || { tabId }
    };
    const accepted = await serial(async () => {
      const current = await state();
      if (!current.pending || current.pending.tabId !== tabId ||
          Date.now() - current.pending.at > PENDING_LIFETIME || current.pending.consumed ||
          !contextCurrent(binding)) {
        return null;
      }
      let tab;
      try { tab = await chrome.tabs.get(tabId); } catch { return null; }
      binding.path = current.pending.requestPath || requestPath(tab.pendingUrl || tab.url);
      binding.context.requestPath = binding.path;
      if (!contextCurrent(binding) || !sameRequest(tab.pendingUrl || tab.url, binding.path) ||
          (globalThis.CBLPageEffects?.isPlatformTab && !await globalThis.CBLPageEffects.isPlatformTab(tabId))) return null;
      if (!contextCurrent(binding)) return null;
      current.pending.id ||= pendingId(tabId);
      binding.id = current.pending.id;
      current.pending.consumed = true; // Reject duplicate MutationObserver events.
      await put(current);
      return current;
    });
    if (!accepted) return { ok: false, error: "لا توجد محاولة تأكيد حديثة لهذه الصفحة." };

    try {
      const check = () => checkExport(binding);
      await check();
      const choice = await options();
      await check();
      const time = stamp();
      const name = accepted.name;
      const requestIban = accepted.pending.requestIban;
      const tab = await check();
      const account = selectedAccount(accepted, [requestIban, visibleIban], requestAccountId(tab.url));
      const messages = [];
      if (choice.autoImage) {
        try { await saveImage(tabId, name, time, false, check); messages.push("بدأ تنزيل صورة النجاح"); }
        catch (error) {
          if (error.code === "EVIDENCE_CANCELLED") throw error;
          await check();
          messages.push(`تعذرت الصورة: ${error.message}`);
        }
      }
      await check();
      if (choice.autoText) {
        if (account && name) {
          try { await saveText(name, account, time, false, check); messages.push("بدأ تنزيل ملف TXT"); }
          catch (error) {
            if (error.code === "EVIDENCE_CANCELLED") throw error;
            await check();
            messages.push(`تعذر الملف النصي: ${error.message}`);
          }
        } else {
          messages.push("لم يُحفظ ملف TXT: الاسم أو الحساب المرتبط بالطلب غير مؤكد");
        }
      }
      await check();
      const finish = async () => {
        await check();
        const booking = await chrome.storage.local.get(["bookingSettings", "bookingRuntime"]);
        await check();
        if (Number.isInteger(booking.bookingRuntime?.ownerTabId) && booking.bookingRuntime.ownerTabId !== tabId) return false;
        const stored = await chrome.storage.local.get([HISTORY_KEY, "cblTrialUiOptions"]);
        await check();
        if (stored.cblTrialUiOptions?.historyEnabled !== false) {
          const history = Array.isArray(stored[HISTORY_KEY]) ? stored[HISTORY_KEY] : [];
          history.unshift({ at: time, name: name || "", bank: account?.bank || "",
            image: messages.some(item => item.includes("صورة النجاح")),
            text: messages.some(item => item.includes("ملف TXT")) });
          await chrome.storage.local.set({ [HISTORY_KEY]: history.slice(0, 20) });
          await check();
        }
        // Retain the page binding after confirmation so closure cancels its effects.
        await chrome.storage.local.set({
          bookingSettings: {...booking.bookingSettings, enabled:false},
          bookingRuntime: {...booking.bookingRuntime, phase:"success",
            message:"تم تأكيد الحجز — يرجى التوجه إلى الفرع.",
            ownerTabId:tabId, ownerRequestPath:binding.path,
            nextRefreshAt:null, updatedAt:Date.now()}
        });
        await check();
        await chrome.action.setBadgeBackgroundColor({color:"#15803d"});
        await check();
        await chrome.action.setBadgeText({text:"✓"});
        await check();
        await serial(async () => {
          await check();
          const latest = await state();
          if (!contextCurrent(binding) || latest.pending?.id !== binding.id) throw cancelled();
          latest.lastExport = messages.join(" — ") || "خيارات الحفظ التلقائي معطلة";
          latest.lastExportId = binding.id;
          latest.pending = null;
          await put(latest);
        });
        return true;
      };
      const effects = globalThis.CBLPageEffects;
      const finished = effects?.complete ? await effects.complete(tabId,binding.context,finish) : await finish();
      if (!finished) throw cancelled();
      await checkExport(binding,true);
      if (choice.notifySaved && effects?.notify) {
        await effects.notify("حفظ إثبات الحجز",messages.join(" — ") || "اكتمل الحجز.","evidence_saved",binding.context);
      }
      return { ok: true, message: messages.join(" — ") };
    } catch (error) {
      // Clear only this export's consumed record; a newer ARM owns its own ID.
      await serial(async () => {
        const latest = await state();
        if (latest.pending?.id === binding.id) {
          latest.pending = null;
          await put(latest);
        }
      });
      throw error;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (typeof message?.type !== "string" || !message.type.startsWith("EVIDENCE_")) return false;
    (async () => {
      const pageEvent = ["EVIDENCE_PROFILE_FOUND", "EVIDENCE_ACCOUNT_FOUND",
        "EVIDENCE_ARM", "EVIDENCE_PENDING_STATUS", "EVIDENCE_SUCCESS"].includes(message.type);
      if (pageEvent && (!sender.tab || !siteUrl(sender.tab.url))) {
        throw new Error("الصفحة ليست من منصة الحجز.");
      }
      switch (message.type) {
        case "EVIDENCE_PROFILE_FOUND": {
          const name = String(message.name || "").trim().slice(0, 100);
          if (!name || /\d/.test(name)) throw new Error("اسم غير صالح.");
          await serial(async () => { const s = await state(); s.name = name; await put(s); });
          return { ok: true };
        }
        case "EVIDENCE_ACCOUNT_FOUND": {
          const account = inputAccount(message.account);
          if (!account) throw new Error("بيانات الحساب غير مكتملة.");
          await serial(async () => {
            const s = await state(); s.accounts[account.iban] = account;
            const id = accountId(message.accountId);
            if (id) s.accountsById[id] = account.iban;
            await put(s);
          });
          return { ok: true };
        }
        case "EVIDENCE_SELECT_ACCOUNT": {
          const tab = await chrome.tabs.get(message.tabId);
          if (!siteUrl(tab.url) || !tab.active) throw new Error("افتح تفاصيل الحساب في علامة التبويب النشطة.");
          const path = new URL(tab.url).pathname;
          if (path.includes("/purchase-requests/")) throw new Error("افتح تفاصيل الحساب من حساباتي الشخصية أولًا.");
          const account = inputAccount(message.account);
          if (!account) throw new Error("لم تظهر حقول الحساب كاملة في هذه الصفحة.");
          const id = requestAccountId(tab.url);
          if (!id || id !== accountId(message.accountId)) throw new Error("تعذر ربط الحساب بصفحة تفاصيله.");
          await serial(async () => {
            const s = await state();
            s.accounts[account.iban] = account;
            if (id) s.accountsById[id] = account.iban;
            if (message.name && !s.name) s.name = String(message.name).trim().slice(0, 100);
            s.selectedIban = account.iban;
            await put(s);
          });
          return { ok: true, bank: account.bank, lastFour: account.iban.slice(-4) };
        }
        case "EVIDENCE_ARM": {
          const armedEpoch = epoch(sender.tab.id) + 1;
          tabEpochs.set(sender.tab.id, armedEpoch);
          await serial(async () => {
            let tab;
            try { tab = await chrome.tabs.get(sender.tab.id); } catch { throw cancelled(); }
            if (epoch(sender.tab.id) !== armedEpoch || !siteUrl(tab.pendingUrl || tab.url) ||
                (globalThis.CBLPageEffects?.isPlatformTab && !await globalThis.CBLPageEffects.isPlatformTab(sender.tab.id))) throw cancelled();
            if (epoch(sender.tab.id) !== armedEpoch) throw cancelled();
            const s = await state();
            if (epoch(sender.tab.id) !== armedEpoch) throw cancelled();
            s.pending = { id:pendingId(sender.tab.id), tabId: sender.tab.id, at: Date.now(), consumed: false,
              requestPath:requestPath(tab.pendingUrl || tab.url),
              requestIban: /^LY\d{23}$/.test(message.requestIban) ? message.requestIban : "" };
            await put(s);
          });
          return { ok: true };
        }
        case "EVIDENCE_PENDING_STATUS": {
          const s = await state();
          return { ok: true, pending: !!s.pending && !s.pending.consumed &&
            s.pending.tabId === sender.tab.id && Date.now() - s.pending.at < PENDING_LIFETIME };
        }
        case "EVIDENCE_SUCCESS":
          return exportOnSuccess(sender.tab.id, String(message.visibleIban || ""));
        case "EVIDENCE_GET_STATUS": {
          const s = await state();
          const choice = await options();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          const account = selectedAccount(s, [], id);
          return { ok: true, options: choice, name: s.name,
            bank: account?.bank || "", lastFour: account?.iban.slice(-4) || "",
            lastExport: s.lastExport };
        }
        case "EVIDENCE_GET_ACCOUNT": {
          const s = await state();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          return { ok: true, name: s.name,
            account: selectedAccount(s, [], id),
            requestAccountUnknown: !!id && !s.accountsById?.[id] };
        }
        case "EVIDENCE_GET_HISTORY": {
          const stored = await chrome.storage.local.get(HISTORY_KEY);
          return { ok: true, history: stored[HISTORY_KEY] || [] };
        }
        case "EVIDENCE_SET_OPTIONS": {
          const choice = { autoImage: !!message.autoImage, autoText: !!message.autoText,
            folder: folderName(message.folder),
            filenamePattern: String(message.filenamePattern || "{name}_{date}_{time}").slice(0,100),
            saveAs: !!message.saveAs,
            notifySaved: !!message.notifySaved };
          await chrome.storage.local.set({ [OPTIONS_KEY]: choice });
          return { ok: true, options: choice };
        }
        case "EVIDENCE_EXPORT_TEXT": {
          const s = await state();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          await saveText(s.name, selectedAccount(s, [], id), stamp(), true);
          return { ok: true, message: "بدأ تنزيل ملف TXT التجريبي." };
        }
        case "EVIDENCE_TEST_IMAGE": {
          const s = await state();
          await saveImage(message.tabId, s.name, stamp(), true);
          return { ok: true, message: "بدأ تنزيل صورة الصفحة التجريبية." };
        }
        default: return { ok: false, error: "رسالة غير معروفة." };
      }
    })().then(sendResponse).catch(error => sendResponse({
      ok: false, error: String(error?.message || error)
    }));
    return true;
  });
})();
