"use strict";

(() => {
  function normalizeArabic(value) {
    return String(value || "")
      .normalize("NFKD")
      .replace(/[\u064B-\u065F\u0670]/g, "")
      .replace(/ـ/g, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function makeId(name, index) {
    return "branch-" +
      normalizeArabic(name)
        .replace(/\s+/g, "-")
        .replace(/[^\p{L}\p{N}-]/gu, "")
        .slice(0, 50) +
      "-" + index;
  }

  const FAVORITES = new Set([
    "طبرق",
    "امساعد",
    "درنة",
    "شحات",
    "البيضاء",
    "الجهاد",
    "السوق القديم",
    "الابيار"
  ]);

  const DEFAULT_NAMES = [
    "طبرق",
    "امساعد",
    "درنة",
    "شحات",
    "البيضاء",
    "الجهاد",
    "السوق القديم",
    "الابيار",
    "مراوة",
    "الفرع الرئيسي بنغازي",
    "الهواري",
    "مطار بنينة",
    "اجدابيا",
    "الكفرة",
    "اوجله",
    "الزنتان",
    "العجيلات",
    "الفرع الرئيسي طرابلس",
    "الخليج",
    "النهر الصناعى",
    "الرويسات",
    "الاستقلال",
    "ازوارة",
    "ابى عيسى",
    "مصراتة",
    "زليتن",
    "رجال الاعمال طرابلس",
    "جادو",
    "بئر الغنم",
    "تاورغاء",
    "براك",
    "الرئيسي سبها",
    "غات",
    "غدامس",
    "الخمس",
    "المدار الجديد",
    "بني وليد",
    "تاجوراء",
    "سرت",
    "ترهونة",
    "زاوية المحجوب",
    "سوق الثلاثاء",
    "فرع صبراته",
    "الصابري",
    "فرع الفويهات",
    "الزاوية"
  ];

  function createDefaultCatalog() {
    const output = [{
      id: "pair-tobruk-musaid",
      name: "طبرق أو امساعد",
      targets: ["طبرق", "امساعد"],
      special: true,
      favorite: true,
      hidden: false,
      custom: false,
      order: 0
    }];

    DEFAULT_NAMES.forEach((name, index) => {
      const favorite = FAVORITES.has(name);

      output.push({
        id: makeId(name, index),
        name,
        targets: [name],
        special: false,
        favorite,
        hidden: !favorite,
        custom: false,
        order: index + 1
      });
    });

    return output;
  }

  function aliasesFor(name) {
    const aliases = {
      "طبرق": ["طبرق", "فرع طبرق"],
      "امساعد": ["امساعد", "مساعد", "فرع امساعد", "فرع مساعد"],
      "درنة": ["درنة", "درنه", "فرع درنة"],
      "شحات": ["شحات", "فرع شحات"],
      "البيضاء": ["البيضاء", "البيضا", "فرع البيضاء"],
      "الابيار": ["الابيار", "الأبيار", "ابيار"],
      "اجدابيا": ["اجدابيا", "أجدابيا", "اجدابية", "أجدابية"],
      "اوجله": ["اوجله", "أوجله", "اوجلة", "أوجلة"],
      "ازوارة": ["ازوارة", "أزوارة", "زوارة"],
      "ابى عيسى": ["ابى عيسى", "أبي عيسى", "ابو عيسى", "أبو عيسى"],
      "النهر الصناعى": ["النهر الصناعى", "النهر الصناعي"],
      "بئر الغنم": ["بئر الغنم", "بير الغنم"],
      "الرئيسي سبها": ["الرئيسي سبها", "الفرع الرئيسي سبها", "سبها الرئيسي"],
      "مطار بنينة": ["مطار بنينة", "مطار بنينه", "بنينة المطار"]
    };

    return [...new Set(
      (aliases[name] || [name])
        .map(normalizeArabic)
        .filter(Boolean)
    )];
  }

  function matchesBranch(text, targetName) {
    const current = normalizeArabic(text);

    return aliasesFor(targetName).some(alias =>
      current === alias || current.includes(alias)
    );
  }

  function searchCatalog(catalog, query, includeHidden = false) {
    const needle = normalizeArabic(query);

    return [...catalog]
      .filter(item => includeHidden || !item.hidden)
      .filter(item => !needle || normalizeArabic(item.name).includes(needle))
      .sort((a, b) => Number(a.order) - Number(b.order));
  }

  globalThis.CBL_BRANCH_LIBRARY = Object.freeze({
    normalizeArabic,
    aliasesFor,
    matchesBranch,
    searchCatalog,
    createDefaultCatalog
  });
})();