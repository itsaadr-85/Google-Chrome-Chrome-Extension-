"use strict";
globalThis.CBLTrial = (() => {
  const KEY = "cblTrialUiOptions";
  const defaults = {
    theme: "dark", layout: "standard", performanceMode: true,
    beneficiaryEnabled: true, historyEnabled: true,
    timerEnabled: true, timerDirection: "down", timerDecimals: true,
    timerStyle: "ring", timerAnchor: "center", timerSize: 120,
    timerOpacity: 85, timerX: 0.5, timerY: 0.5,
    timerWidth: 145, timerHeight: 145, timerMoved: false,
    cardOrder: ["company","branch","refresh","live","phase"],
    show: {company:true, branch:true, refresh:true, live:true,
      phase:true, history:true, evidence:true, beneficiary:true}
  };
  async function ui() {
    const stored = await chrome.storage.local.get(KEY);
    const data = stored[KEY] || {};
    return {...defaults, ...data, show:{...defaults.show,...(data.show || {})}};
  }
  async function saveUi(patch) {
    const current = await ui();
    const next = {...current,...patch,show:{...current.show,...(patch.show || {})}};
    await chrome.storage.local.set({[KEY]:next});
    return next;
  }
  async function state() {
    const result = await chrome.runtime.sendMessage({type:"GET_STATE"});
    if (!result?.ok) throw new Error(result?.error || "تعذر قراءة حالة الإضافة.");
    return result;
  }
  async function saveSettings(patch) {
    const stored = await chrome.storage.local.get("bookingSettings");
    const previous = stored.bookingSettings || {};
    if (patch.bookingMode && patch.bookingMode !== (previous.bookingMode || "cash") && previous.enabled) {
      await chrome.runtime.sendMessage({type:"STOP_SESSION"});
      patch = {...patch,enabled:false};
    }
    const next = {...previous,...patch};
    await chrome.storage.local.set({bookingSettings:next});
    return next;
  }
  function number(value, fallback, min, max) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.round(Math.max(min,Math.min(max,parsed))*10)/10 : fallback;
  }
  async function platformTab() {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.id || !String(tab.url || "").startsWith("https://fcms.cbl.gov.ly/")) {
      throw new Error("افتح منصة الحجز في علامة التبويب الحالية.");
    }
    return tab;
  }
  async function deliver(tabId, message) {
    try { return await chrome.tabs.sendMessage(tabId,message); }
    catch {
      await chrome.scripting.insertCSS({target:{tabId},files:["page-notify.css"]}).catch(()=>{});
      await chrome.scripting.executeScript({target:{tabId},files:[
        "branch-data.js","company-data.js","i18n.js","diagnostic.js",
        "page-notify.js","content.js","evidence-content.js","timer-overlay.js"
      ]});
      return chrome.tabs.sendMessage(tabId,message);
    }
  }
  function applyTheme(value, target=document.documentElement) {
    target.dataset.theme = value.theme;
    target.dataset.layout = value.layout;
    target.dataset.performance = value.performanceMode ? "on" : "off";
  }
  return {KEY,defaults,ui,saveUi,state,saveSettings,number,platformTab,deliver,applyTheme};
})();
