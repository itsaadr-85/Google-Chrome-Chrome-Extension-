"use strict";

(() => {
  const status = document.getElementById("evidenceTrialStatus");
  const imageToggle = document.getElementById("evidenceAutoImage");
  const textToggle = document.getElementById("evidenceAutoText");
  const say = value => { status.textContent = value; };
  const request = async value => {
    const result = await chrome.runtime.sendMessage(value);
    if (!result?.ok) throw new Error(result?.error || "تعذر تنفيذ الطلب.");
    return result;
  };
  async function tab() {
    const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!current?.url?.startsWith("https://fcms.cbl.gov.ly/")) {
      throw new Error("افتح منصة الحجز في علامة التبويب الحالية.");
    }
    return current;
  }
  async function refresh() {
    const result = await request({ type: "EVIDENCE_GET_STATUS" });
    imageToggle.checked = result.options.autoImage;
    textToggle.checked = result.options.autoText;
    const pieces = [
      result.name ? `الاسم: ${result.name}` : "الاسم: افتح الصفحة الرئيسية أولًا",
      result.bank ? `الحساب المعتمد: ${result.bank} ••••${result.lastFour}` :
        "الحساب: افتح تفاصيله واضغط اعتماد الحساب المفتوح"
    ];
    if (result.lastExport) pieces.push(result.lastExport);
    say(pieces.join(" | "));
  }
  async function handle(action) {
    try { await action(); }
    catch (error) { say(String(error?.message || error)); }
  }
  async function saveOptions() {
    await request({ type: "EVIDENCE_SET_OPTIONS",
      autoImage: imageToggle.checked, autoText: textToggle.checked });
    say("تم حفظ خيارات الإثبات لهذه النسخة التجريبية.");
  }
  imageToggle.addEventListener("change", () => handle(saveOptions));
  textToggle.addEventListener("change", () => handle(saveOptions));

  document.getElementById("evidenceSelect").addEventListener("click", () => handle(async () => {
    const current = await tab();
    const page = await chrome.tabs.sendMessage(current.id, { type: "EVIDENCE_READ_PAGE" });
    if (!page?.account) throw new Error("افتح صفحة تفاصيل حساب واحد؛ يجب أن تظهر خانات IBAN ورقم الحساب والمصرف.");
    const chosen = await request({ type: "EVIDENCE_SELECT_ACCOUNT", tabId: current.id,
      account: page.account, name: page.name });
    say(`تم اعتماد ${chosen.bank}، رقم IBAN ينتهي بـ ${chosen.lastFour}. افتح الصفحة الرئيسية إذا لم يُقرأ الاسم بعد.`);
  }));
  document.getElementById("evidenceTextTest").addEventListener("click", () =>
    handle(async () => say((await request({ type: "EVIDENCE_EXPORT_TEXT" })).message)));
  document.getElementById("evidenceImageTest").addEventListener("click", () =>
    handle(async () => {
      const current = await tab();
      say((await request({ type: "EVIDENCE_TEST_IMAGE", tabId: current.id })).message);
    }));
  refresh().catch(error => say(String(error?.message || error)));
})();
