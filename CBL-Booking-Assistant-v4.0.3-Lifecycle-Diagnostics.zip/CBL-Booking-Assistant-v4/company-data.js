"use strict";

(() => {
  function normalizeArabic(value) {
    return String(value || "")
      .normalize("NFKD")
      .replace(/[\u064B-\u065F\u0670]/g, "")
      .replace(/ـ/g, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function extractBaseName(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .split(/\s+-\s+/)[0]
      .trim();
  }

  function normalizeCompanyName(value) {
    return normalizeArabic(
      extractBaseName(value)
    )
      /*
       * توحيد:
       * "الصرافة و الخدمات"
       * و
       * "الصرافة والخدمات"
       */
      .replace(/\s+و\s+/g, " و")
      .replace(/\s+/g, " ")
      .trim();
  }

  function namesEqual(a, b) {
    return (
      normalizeCompanyName(a) ===
      normalizeCompanyName(b)
    );
  }

  const DEFAULT_COMPANIES = [
    "الشركة العربية العالمية للصرافة",

    "شركة دوجال للصرافة والخدمات المالية",

    "شركة المدار للصرافة و الخدمات المالية",

    "شركة منارة بنغازي للصرافة والخدمات المالية",

    "شركة اليقين لأعمال الصرافة والخدمات المالية",

    "شركة نجم لاعمال الصرافة والخدمات المالية",

    "شركة جدي للصرافة والخدمات المالية",

    "شركة جبال تيبستي للصرافة والخدمات المالية",

    "شركة بريق الماسة للصرافة و الخدمات المالية",

    "شركة حسبة للصرافة والخدمات المالية",

    "شركة علو الشواهق للصرافة والخدمات المالية",

    "شركة التعاون الدائم للصرافة والخدمات المالية",

    "شركة منارة البيضاء للصرافة",

    "شركة لحظة للصرافة والخدمات المالية",

    "شركة الدرهم للصرافة والخدمات المالية"
  ];

  function makeId(name, index) {
    const slug =
      normalizeCompanyName(name)
        .replace(/\s+/g, "-")
        .replace(/[^\p{L}\p{N}-]/gu, "")
        .slice(0, 48);

    return `company-${slug}-${index}`;
  }

  function createDefaultCatalog() {
    return DEFAULT_COMPANIES.map(
      (name, index) => ({
        id: makeId(name, index),

        name,

        favorite:
          index < 6,

        hidden:
          false,

        custom:
          false,

        order:
          index
      })
    );
  }

  function searchCatalog(
    catalog,
    query = "",
    includeHidden = false
  ) {
    const needle =
      normalizeCompanyName(query);

    return [...(catalog || [])]
      .filter(item =>
        includeHidden ||
        !item.hidden
      )

      .filter(item =>
        !needle ||
        normalizeCompanyName(
          item.name
        ).includes(needle)
      )

      .sort((a, b) => {
        if (
          Boolean(a.favorite) !==
          Boolean(b.favorite)
        ) {
          return a.favorite
            ? -1
            : 1;
        }

        return (
          Number(a.order || 0) -
          Number(b.order || 0)
        );
      });
  }

  globalThis.CBL_COMPANY_LIBRARY =
    Object.freeze({
      normalizeArabic,
      extractBaseName,
      normalizeCompanyName,
      namesEqual,
      searchCatalog,
      createDefaultCatalog
    });
})();
