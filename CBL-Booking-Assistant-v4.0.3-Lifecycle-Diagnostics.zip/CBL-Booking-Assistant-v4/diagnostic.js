"use strict";

// Content scripts send batches. The service worker alone owns persistent storage.
(() => {
  const STORAGE_KEY = "cblDiagnosticLog";
  const MAX_ENTRIES = 10000;
  const MAX_BYTES = 8 * 1024 * 1024;
  const REDACTED = "[REDACTED]";
  const PRIVATE_KEY = /cookie|password|passwd|csrf|turnstile|signature|authorization|session|auth|secret|token|credential|iban|account(?:number|no|id|holder|details)?|card(?:number|no)|national(?:id|number)|passport|phone|mobile|email|address|birth|fullname|firstname|lastname|customername|username|personname|beneficiary|requestbody|responsebody|postdata|payload|headers|html|snapshot/i;
  const UUID = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;

  function safePath(pathname) {
    return String(pathname)
      .replace(UUID, REDACTED)
      .replace(/\/(users?|accounts?|customers?|clients?|profiles?|beneficiaries)\/[^/]+/gi, "/$1/" + REDACTED)
      .replace(/\/[^/]*%[0-9a-f]{2}[^/]*(?=\/|$)/gi, "/" + REDACTED)
      .replace(/\/[A-Za-z0-9_-]{24,}(?=\/|$)/g, "/" + REDACTED)
      .replace(/\d{7,}/g, REDACTED);
  }

  function safeURL(value) {
    try {
      const url = new URL(value);
      // Discard every query value and fragment, including unknown credential keys.
      return url.origin + safePath(url.pathname) + (url.search ? "?[REDACTED]" : "") + (url.hash ? "#[REDACTED]" : "");
    } catch { return "[REDACTED_URL]"; }
  }

  function safeString(value) {
    // Bound work before regex matching, including unexpected enormous exceptions.
    let text = String(value).slice(0, 4096);
    if (/<\s*(?:html|body|script|input|form|div|span|head|table)\b/i.test(text)) return "[REDACTED_HTML]";
    text = text.replace(/\bhttps?:\/\/[^\s\"'<>]+/gi, safeURL);
    // Skip the email search when absent; scanning long arbitrary strings for an
    // email with no @ otherwise causes unnecessary quadratic regex backtracking.
    if (text.includes("@")) text = text.replace(/[^\s@<>]+@[^\s@<>]+\.[A-Za-z]{2,}/g, REDACTED);
    return text
      .replace(/([?&][^=\s&]+)=([^&\s]*)/g, "$1=" + REDACTED)
      .replace(/\bBearer\s+[^\s,;]+/gi, "Bearer " + REDACTED)
      .replace(/\bBasic\s+[^\s,;]+/gi, "Basic " + REDACTED)
      .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, REDACTED)
      .replace(/\b(?:cookie|set-cookie|authorization|x-csrf-token|csrf|password|passwd|token|access[_-]?token|api[_-]?key|auth|session(?:id)?|cf-turnstile-response|turnstile|secret|signature|iban|account(?:\s*(?:number|no|id|holder))?|full\s*name|user\s*name|name|email|phone)\s*[:=]\s*[^\n,;]+/gi, match => match.replace(/([:=]).*/, "$1" + REDACTED))
      .replace(/(?:الاسم|الرقم\s*الوطني|رقم\s*الحساب|البريد\s*الإلكتروني|الهاتف|كلمة\s*المرور)\s*[:=]\s*[^\n,;]+/g, match => match.replace(/([:=]).*/, "$1" + REDACTED))
      .replace(/\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]){11,30}\b/gi, REDACTED)
      .replace(UUID, REDACTED)
      .replace(/\b\d(?:[ -]?\d){6,}\b/g, REDACTED)
      .replace(/\/(users?|accounts?|customers?|clients?|profiles?|beneficiaries)\/[^/\s?#]+/gi, "/$1/" + REDACTED)
      .replace(/\/[A-Za-z0-9_-]{24,}(?=\/|[\s?#]|$)/g, "/" + REDACTED)
      .slice(0, 1200);
  }

  function sanitize(value, depth = 0, budget = { remaining: 800 }, seen = new WeakSet()) {
    if (budget.remaining-- <= 0) return "[MAX_SIZE]";
    if (value == null) return value;
    if (depth > 6) return "[MAX_DEPTH]";
    if (typeof value === "string") return safeString(value);
    if (typeof value === "number") return Number.isFinite(value) ? (Number.isInteger(value) && Math.abs(value) >= 1000000 ? REDACTED : value) : null;
    if (typeof value === "boolean") return value;
    if (typeof value !== "object") return safeString(String(value));
    if (seen.has(value)) return "[CIRCULAR]";
    seen.add(value);
    if (Array.isArray(value)) return value.slice(0, 40).map(item => sanitize(item, depth + 1, budget, seen));
    const output = {};
    for (const [key, item] of Object.entries(value).slice(0, 60)) {
      if (["__proto__", "prototype", "constructor"].includes(key)) continue;
      const normalizedKey = key.replace(/[^a-z0-9]/gi, "");
      const privateKey = PRIVATE_KEY.test(normalizedKey) || /^(?:name|names|body|request|response|person|user|customer|client|contact|identity)$/i.test(normalizedKey) || /الاسم|الرقم.?الوطني|رقم.?الحساب|جواز|البريد|الهاتف|كلمة.?المرور|تاريخ.?الميلاد/.test(key);
      output[safeString(key).slice(0, 100)] = privateKey ? REDACTED : sanitize(item, depth + 1, budget, seen);
      if (budget.remaining <= 0) break;
    }
    return output;
  }

  class DiagnosticLogger {
    constructor(enabled = false) {
      this.enabled = Boolean(enabled);
      this.entries = [];
      this.flushTimer = null;
      this.inFlight = null;
      this.dropped = 0;
    }
    setEnabled(value) {
      this.enabled = Boolean(value);
      if (!this.enabled) {
        clearTimeout(this.flushTimer);
        this.flushTimer = null;
        this.entries = [];
        this.dropped = 0;
      }
    }
    async load() {
      // Compatibility API: never read a global log into a content-script buffer.
    }
    log(category, message, data = null) {
      if (!this.enabled) return;
      if (this.entries.length >= 1000) { this.entries.shift(); this.dropped++; }
      this.entries.push({ time: new Date().toISOString(), ts: Date.now(), category: sanitize(String(category || "INFO")), message: sanitize(String(message || "")), data: sanitize(data) });
      // Fixed batching delay: a busy page cannot postpone persistence indefinitely.
      if (!this.flushTimer) this.flushTimer = setTimeout(() => { this.flushTimer = null; this.flush().catch(() => {}); }, 100);
    }
    async flush() {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
      if (this.inFlight) {
        await this.inFlight;
        // Another pending flush may have acquired the batch while we awaited.
        if (this.inFlight) return this.flush();
      }
      if (!this.enabled || !this.entries.length) return;
      const events = this.entries.splice(0, 200);
      if (this.dropped) {
        events.unshift({ ts: Date.now(), category: "DIAGNOSTIC_BUFFER", message: "Content buffer discarded older entries", data: { dropped: this.dropped } });
        this.dropped = 0;
      }
      const send = (async () => {
        const result = await chrome.runtime.sendMessage({ type: "DIAGNOSTIC_EVENTS", events });
        if (result?.ok === false) throw new Error("Diagnostic batch was not accepted");
      })();
      this.inFlight = send;
      try { await send; }
      catch (error) {
        if (this.enabled) this.entries = events.concat(this.entries).slice(-1000);
        throw error;
      } finally { this.inFlight = null; }
      if (this.enabled && this.entries.length) await this.flush();
    }
    async clear() {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
      this.entries = [];
      this.dropped = 0;
      if (this.inFlight) await this.inFlight.catch(() => {});
      return chrome.runtime.sendMessage({ type: "DIAGNOSTIC_CLEAR" });
    }
  }
  globalThis.CBLDiagnostic = Object.freeze({ DiagnosticLogger, sanitize, STORAGE_KEY, MAX_ENTRIES, MAX_BYTES });
})();
