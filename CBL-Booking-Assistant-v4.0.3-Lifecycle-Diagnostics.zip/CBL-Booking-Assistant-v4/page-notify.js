"use strict";

(() => {

  const ROOT_ID = "cbl-v340-notification-root";

  const BORDER_ID = "cbl-v340-page-border";


  function ensureRoot() {

    let root = document.getElementById(
        ROOT_ID
      );


    if (root) {
      return root;
    }


    root = document.createElement(
        "div"
      );


    root.id = ROOT_ID;


    root.dataset.position = "top-center";


    root.dir = "rtl";


    document.documentElement
      .appendChild(
        root
      );


    return root;
  }


  function ensureBorder() {

    let border = document.getElementById(
        BORDER_ID
      );


    if (border) {
      return border;
    }


    border = document.createElement(
        "div"
      );


    border.id = BORDER_ID;


    document.documentElement
      .appendChild(
        border
      );


    return border;
  }


  function flashBorder(
    type = "info"
  ) {

    const border = ensureBorder();


    border.dataset.type = type;


    border.classList.remove(
      "show"
    );


    void border.offsetWidth;


    border.classList.add(
      "show"
    );


    setTimeout(
      () => {

        border.classList.remove(
          "show"
        );

      },
      1800
    );
  }


  function show({

    type = "info",

    title = "",

    message = "",

    position = "top-center",

    duration = 5,

    countdown = true,

    pageBorder = false,

    direction = "rtl",
    opacity = 88,
    glassTheme = "midnight"

  } = {}) {


    const root = ensureRoot();


    root.dataset.position = position;


    root.style.setProperty("--cbl-toast-opacity", String(Math.max(20, Math.min(100, Number(opacity)||88))/100));
    root.dataset.theme = glassTheme;

    root.dir = direction === "ltr"
        ? "ltr"
        : "rtl";


    const seconds = Math.max(0.1, Math.min(30, Number(duration) || 5));


    const toast = document.createElement(
        "div"
      );


    toast.className = `cbl-v340-toast type-${type}`;


    const content = document.createElement(
        "div"
      );


    content.className = "cbl-v340-toast-content";


    const titleElement = document.createElement(
        "strong"
      );


    titleElement.textContent = String(
        title || ""
      );


    const messageElement = document.createElement(
        "span"
      );


    messageElement.textContent = String(
        message || ""
      );


    content.append(
      titleElement,
      messageElement
    );


    toast.append(
      content
    );


    let counter = null;


    if (
      countdown
    ) {

      counter = document.createElement(
          "div"
        );


      counter.className = "cbl-v340-counter";


      counter.textContent = String(
          seconds
        );


      toast.append(
        counter
      );
    }


    root.appendChild(
      toast
    );


    if (
      pageBorder
    ) {

      flashBorder(
        type
      );
    }


    let remaining = seconds;
    const startedAt = performance.now();
    const timer = setInterval(() => {
      remaining = Math.max(0, seconds - ((performance.now() - startedAt) / 1000));
      if (counter) counter.textContent = remaining < 10 ? remaining.toFixed(1) : String(Math.ceil(remaining));
      if (remaining <= 0) {
        clearInterval(timer);
        toast.classList.add("leave");
        setTimeout(() => toast.remove(), 180);
      }
    }, 100);


    return toast;
  }


  globalThis.CBLPageNotify = Object.freeze({

      show,

      flashBorder
    });

})();
