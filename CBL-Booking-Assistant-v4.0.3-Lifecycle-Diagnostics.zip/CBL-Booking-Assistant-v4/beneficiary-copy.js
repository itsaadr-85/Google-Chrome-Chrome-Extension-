"use strict";
globalThis.CBLBeneficiaryCopy = Object.freeze({
  value(data, kind) {
    const name = String(data?.name || "").trim();
    const account = data?.account;
    if (kind === "name") {
      if (!name) throw new Error("افتح الصفحة الرئيسية لقراءة اسم صاحب الحساب.");
      return name;
    }
    if (!account) throw new Error("افتح تفاصيل الحساب المطلوب من حساباتي الشخصية.");
    if (kind === "iban") return account.iban;
    if (kind === "accountNumber") return account.accountNumber;
    if (kind === "all") {
      if (!name) throw new Error("افتح الصفحة الرئيسية لقراءة الاسم قبل نسخ جميع البيانات.");
      return `الاسم: ${name}\nالمصرف: ${account.bank}\nIBAN: ${account.iban}\nرقم الحساب: ${account.accountNumber}`;
    }
    throw new Error("خيار النسخ غير معروف.");
  }
});
