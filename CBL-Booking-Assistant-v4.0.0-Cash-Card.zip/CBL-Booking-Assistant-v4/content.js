"use strict";

(() => {
  if (window.top !== window || window.__CBL_ASSISTANT_V340__) {
    return;
  }

  window.__CBL_ASSISTANT_V340__ = true;

  const LIB =
    globalThis.CBL_BRANCH_LIBRARY;

  const COMPANY_LIB =
    globalThis.CBL_COMPANY_LIBRARY;

  const DEFAULT_SETTINGS = {
    enabled: false,
  bookingMode: "cash",
  companyResponseSeconds: 8,
    refreshSeconds: 5,
    selectedBranchId: "pair-tobruk-musaid",

    companyMode: "first_available",
    companyName: "",
    companyAttempts: 2,
    companySkipCount: 5,

    diagnosticsEnabled: false,
    recoveryEnabled: true,

    notifications: true,
    sound: true,
    soundTone: "bell",

    autoConfirm: true,
    autoResumeAfterRateLimit: true,

    pageNotifications: true,
    notificationPosition: "top-center",
    notificationDuration: 5,
    notificationCountdown: true,
    notificationPageBorder: true,
    pauseOnMouseMove: false,
    mouseSensitivity: "medium",
    performanceMode: true,
    waitForTargetBranch: true,
    branchRefreshSeconds: 2,
    notificationOpacity: 88,
    glassTheme: "midnight"
  };

  let settings = {
    ...DEFAULT_SETTINGS
  };

  let catalog = [];

  let running = false;

  let refreshTimer = null;
  let branchErrorTimer = null;
  let branchDecisionTimer = null;

  let pageObserver = null;
  let branchObserver = null;
  let confirmObserver = null;

  let confirmTimer = null;
  let observedBranchSelect = null;

  let companyFlowStarted = false;
  let companyListOpening = null;
  let companyAttemptsUsed = 0;
  let companyFlowToken = 0;
  let companyChoiceForRetry = "";

  let branchSelected = false;
  let branchSelectionInProgress = false;
  let branchObserverTimer = null;
  let selectedBranchLabel = "";

  let awaitingAutoConfirm = false;
  let confirmClicked = false;
  let finalizingBooking = false;

  let branchFallbackMode = false;
  let branchFirstDecisionDone = false;

  let confirmClickMonitorAttached = false;
  let mousePauseTriggered = false;
  let mousePauseListenerAttached = false;
  let mouseSessionToken = 0;

  let diagnosticsListenerAttached = false;

  const diagnostic =
    new CBLDiagnostic.DiagnosticLogger(false);

  const normalize = value =>
    LIB.normalizeArabic(value);

  const sleep = ms =>
    new Promise(resolve =>
      setTimeout(resolve, ms)
    );

  const nextFrame = () =>
    new Promise(resolve =>
      requestAnimationFrame(resolve)
    );

  async function loadState() {
    const response =
      await chrome.runtime.sendMessage({
        type: "GET_STATE"
      });

    if (!response?.ok) {
      return false;
    }

    settings = {
      ...DEFAULT_SETTINGS,
      ...(response.settings || {})
    };
    companyChoiceForRetry = String(response.runtime?.selectedCompany || "");

    catalog =
      Array.isArray(response.catalog)
        ? response.catalog
        : [];

    diagnostic.setEnabled(
      settings.diagnosticsEnabled
    );

    await diagnostic.load();

    return true;
  }

  function log(category, message, data = null) {
    diagnostic.log(
      category,
      message,
      data
    );
  }

  async function setRuntime(
    phase,
    message,
    extra = {}
  ) {
    try {
      await chrome.runtime.sendMessage({
        type: "SET_RUNTIME",

        patch: {
          phase,
          message,
          ...extra
        }
      });
    } catch {}
  }

  function notify(title, message, kind = "alert") {
    chrome.runtime.sendMessage({
      type: "NOTIFY",
      title,
      message,
      kind
    }).catch(() => {});
  }

  function pageNotify(
    type,
    title,
    message,
    important = false,
    duration = null
  ) {
    if (
      settings.pageNotifications === false ||
      !globalThis.CBLPageNotify
    ) {
      return;
    }

    try {
      CBLPageNotify.show({
        type,
        title,
        message,

        position:
          settings.notificationPosition ||
          "top-center",

        direction:
          settings.uiLanguage === "en"
            ? "ltr"
            : "rtl",

        duration:
          duration ??
          (
            Number(
              settings.notificationDuration
            ) || 5
          ),

        countdown:
          settings.notificationCountdown !==
          false,

        opacity: Number(settings.notificationOpacity) || 88,
        glassTheme: settings.glassTheme || "midnight",

        pageBorder:
          Boolean(
            important &&
            settings.notificationPageBorder !==
              false
          )
      });
    } catch {}
  }

function clearTimers() {
    clearTimeout(refreshTimer);
    clearTimeout(branchErrorTimer);
    clearTimeout(branchDecisionTimer);

    refreshTimer = null;
    branchErrorTimer = null;
    branchDecisionTimer = null;

    if (confirmTimer) {
      clearInterval(confirmTimer);
      confirmTimer = null;
    }
  }

  function disconnectObservers() {
    pageObserver?.disconnect();
    branchObserver?.disconnect();
    confirmObserver?.disconnect();

    pageObserver = null;
    branchObserver = null;
    confirmObserver = null;

    observedBranchSelect = null;
  }

  function clearEngine() {
    running = false;

    clearTimers();
    disconnectObservers();

    companyFlowToken += 1;
  }

  function stopPreConfirmWork() {
    clearTimeout(refreshTimer);
    clearTimeout(branchErrorTimer);
    clearTimeout(branchDecisionTimer);

    refreshTimer = null;
    branchErrorTimer = null;
    branchDecisionTimer = null;

    pageObserver?.disconnect();
    branchObserver?.disconnect();

    pageObserver = null;
    branchObserver = null;

    observedBranchSelect = null;

    companyFlowToken += 1;
  }

  function isEditPage() {
    if (
      document.querySelector(
        "#bank_branch"
      )
    ) {
      return true;
    }

    if (
      document.querySelector(
        "#company, #company_branch, #company_contract"
      )
    ) {
      return true;
    }

    if (
      document.querySelector(
        ".cf-turnstile"
      ) &&
      findConfirmButton()
    ) {
      return true;
    }

    return /\/purchase-requests\/[^/]+\/edit\/?$/
      .test(location.pathname);
  }

  function isRequestPage() {
    if (
      findEditLink()
    ) {
      return true;
    }

    return (
      location.pathname
        .includes(
          "/purchase-requests"
        ) &&
      !isEditPage()
    );
  }

  function pageShowsRateLimit() {
    const text =
      normalize(
        document.body?.textContent || ""
      );

    return [
      "لقد تجاوزت الحد الاقصي لعدد الطلبات",
      "عدد كبير من الطلبات",
      "يرجي الانتظار",
      "too many requests",
      "http 429"
    ].some(item =>
      text.includes(normalize(item))
    );
  }

  function pageShowsExpiredSession() {
    return Boolean(
      document.querySelector(
        'input[type="password"], form[action*="login"]'
      )
    );
  }

  async function reportError(
    code,
    message,
    details = {},
    recoverable = true
  ) {
    log("ERROR", message, {
      code,
      ...details
    });

    await setRuntime(
      "error",
      message,
      {
        errorCode: code,

        errorDetails: {
          ...details,

          recoverable: Boolean(
            recoverable &&
            settings.recoveryEnabled
          )
        }
      }
    );
  }

  function findEditLink() {
    const links = [
      ...document.querySelectorAll(
        'a[href*="/purchase-requests/"][href*="/edit"]'
      )
    ];

    return links.find(link =>
      normalize(link.textContent || "")
        .includes(
          normalize("اختيار شركة الصرافة")
        )
    ) || null;
  }

  function selectedTarget() {
    return (
      catalog.find(item =>
        item.id === settings.selectedBranchId
      ) ||

      catalog.find(item =>
        item.id === "pair-tobruk-musaid"
      ) ||

      null
    );
  }

  function targetNames() {
    const item = selectedTarget();

    if (!item) {
      return ["طبرق", "امساعد"];
    }

    return Array.isArray(item.targets) &&
      item.targets.length
        ? item.targets
        : [item.name];
  }

  function findBranchSelect() {
    return document.querySelector(
      "#bank_branch"
    );
  }

  function branchOptions(select) {
    return [...(select?.options || [])]
      .filter(option =>
        String(option.value || "").trim() &&
        String(option.textContent || "").trim()
      );
  }

  function findTargetOption(select) {
    const options = branchOptions(select);

    for (const targetName of targetNames()) {
      const aliases = LIB.aliasesFor(targetName);
      const option = options.find(item => {
        const current = normalize(item.textContent || "");
        return aliases.some(alias => current === alias);
      });

      if (option) {
        return {
          option,
          targetName
        };
      }
    }

    return null;
  }

  function verifySelectedBranch(
    select,
    targetName
  ) {
    if (
      !select ||
      !String(select.value || "").trim()
    ) {
      return false;
    }

    const text =
      String(
        select.selectedOptions?.[0]
          ?.textContent || ""
      ).trim();

    const current = normalize(text);
    return LIB.aliasesFor(targetName)
      .some(alias => current === alias);
  }

  function currentBranchIsCorrect() {
    const select = findBranchSelect();

    if (!select) return false;

    return targetNames().some(target =>
      verifySelectedBranch(
        select,
        target
      )
    );
  }

  function companyFields() {
    const value = id =>
      String(
        document.querySelector(`#${id}`)
          ?.value || ""
      ).trim();

    return {
      company: value("company"),
      companyBranch: value("company_branch"),
      companyContract: value("company_contract")
    };
  }

  function isCardBooking() { return settings.bookingMode === "card"; }

  function companyResponseTimeout() {
    return Math.max(3, Math.min(30, Number(settings.companyResponseSeconds) || 8)) * 1000;
  }

  function bookingSelectionsReady() {
    if (!companyIsConfirmed()) return false;
    if (!isCardBooking()) return currentBranchIsCorrect();
    // A visible cash-only field means the selected mode does not match this page.
    const branch = findBranchSelect();
    return !branch || getComputedStyle(branch).display === "none" ||
      getComputedStyle(branch).visibility === "hidden" || branch.getBoundingClientRect().height === 0;
  }

  function companyIsConfirmed() {
    const fields = companyFields();

    return Boolean(
      fields.company &&
      fields.companyContract &&
      (isCardBooking() || fields.companyBranch)
    );
  }

  function logCompanyFields(prefix = "") {
    if (!settings.diagnosticsEnabled) return;

    const fields = companyFields();

    log(
      "FIELD",
      `${prefix} company fields`,
      {
        company:
          fields.company
            ? "filled"
            : "empty",

        company_branch:
          fields.companyBranch
            ? "filled"
            : "empty",

        company_contract:
          fields.companyContract
            ? "filled"
            : "empty"
      }
    );
  }

  function canAttemptBranch() {
    return (
      settings.enabled &&
      running
    );
  }

  function turnstileSolved() {
    return Boolean(
      String(
        document.querySelector(
          '[name="cf-turnstile-response"]'
        )?.value || ""
      ).trim()
    );
  }

  function findConfirmButton() {
    const phrase = normalize("تأكيد الحجز");
    const candidates = [
      ...document.querySelectorAll(
        'button, input[type="submit"]'
      )
    ].filter(element => {
      const text = normalize(
        element.textContent || element.value || ""
      );
      if (!text.includes(phrase)) return false;
      if (!element.isConnected) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.display !== "none" &&
        style.visibility !== "hidden" &&
        rect.width > 0 && rect.height > 0;
    });

    return candidates.find(element =>
      !element.disabled &&
      element.getAttribute("aria-disabled") !== "true"
    ) || candidates[0] || null;
  }

  function installConfirmClickMonitor() {
    if (
      confirmClickMonitorAttached
    ) {
      return;
    }

    confirmClickMonitorAttached =
      true;

    document.addEventListener(
      "click",
      event => {
        let button = null;

        try {
          button =
            event.target?.closest?.(
              'button,input[type="submit"]'
            );
        } catch {}

        if (!button) {
          return;
        }

        const text =
          normalize(
            button.textContent ||
            button.value ||
            ""
          );

        if (
          !text.includes(
            normalize(
              "تأكيد الحجز"
            )
          )
        ) {
          return;
        }

        const automatic =
          button.dataset
            .cblAutoConfirm ===
          "1";

        log(
          "CONFIRM_CLICK",

          automatic
            ? "Automatic confirmation click detected"
            : "Manual confirmation click detected"
        );

        pageNotify(
          "confirm",
          "تم الضغط على تأكيد الحجز",

          automatic
            ? "تم تنفيذ الضغط التلقائي مرة واحدة."
            : "تم اكتشاف الضغط اليدوي على زر التأكيد.",

          true,
          7
        );
      },
      true
    );
  }

async function stopAfterBranch() {
    await diagnostic.flush();

    clearEngine();

    await chrome.runtime.sendMessage({
      type: "COMPLETE_BRANCH_AND_STOP",
      branch: selectedBranchLabel
    });
  }

  async function tryAutoConfirm() {
    if (
      !settings.enabled || !running ||
      !awaitingAutoConfirm ||
      confirmClicked ||
      !settings.autoConfirm
    ) {
      return false;
    }

    if (
      !bookingSelectionsReady()
    ) {
      return false;
    }

    if (
      !companyIsConfirmed()
    ) {
      return false;
    }

    /*
     * لا يتم حل أو تجاوز Cloudflare.
     * ننتظر حل المستخدم له يدويًا.
     */
    if (
      !turnstileSolved()
    ) {
      return false;
    }

    const button =
      findConfirmButton();

    if (
      !button ||
      !button.isConnected
    ) {
      return false;
    }

    if (
      button.disabled ||
      button.getAttribute(
        "aria-disabled"
      ) === "true"
    ) {
      return false;
    }

    confirmClicked = true;

    log(
      "CONFIRM",
      "Company, branch and manual Cloudflare verification confirmed."
    );

    button.dataset
      .cblAutoConfirm =
      "1";

    /*
     * ضغطة واحدة فقط.
     */
    button.click();

    pageNotify(
      "confirm",
      "تم إرسال التأكيد",
      "بانتظار ظهور نتيجة الحجز من المنصة.",
      true,
      5
    );

    try {
      await chrome.runtime.sendMessage({
        type:
          "CONFIRM_SUBMITTED_WAIT_RESULT",

        branch:
          selectedBranchLabel
      });
    } catch {}

    clearEngine();

    return true;
  }

  function installConfirmObserver() {
    if (
      !settings.autoConfirm ||
      !awaitingAutoConfirm
    ) {
      return;
    }

    confirmObserver?.disconnect();

    confirmObserver =
      new MutationObserver(() => {
        tryAutoConfirm().catch(() => {});
      });

    confirmObserver.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true,
        attributes: true
      }
    );

    if (confirmTimer) {
      clearInterval(confirmTimer);
    }

    /*
     * فحص DOM محلي فقط، وليس طلب شبكة.
     */
    confirmTimer =
      setInterval(() => {
        tryAutoConfirm().catch(() => {});
      }, 50);

    tryAutoConfirm().catch(() => {});
  }

  async function stopForManualBranch(
    reason =
      "تم اعتماد شركة الصرافة. اختر فرعًا آخر يدويًا."
  ) {
    branchFallbackMode =
      true;

    awaitingAutoConfirm =
      false;

    pageNotify(
      "warning",
      "اختر فرعًا آخر يدويًا",
      reason,
      true,
      10
    );

    log(
      "STOP",
      "Manual branch selection required",
      {
        reason
      }
    );

    clearEngine();

    try {
      await chrome.runtime.sendMessage({
        type:
          "MANUAL_BRANCH_REQUIRED_STOP",

        reason
      });
    } catch {}

    return true;
  }


  async function finalizeVerifiedBooking() {
    if (
      !bookingSelectionsReady() ||
      finalizingBooking
    ) {
      return false;
    }
    finalizingBooking = true;

    pageNotify(
      "branch",
      "تم التحقق من الاختيارات",
      isCardBooking() ? "تم اعتماد شركة الصرافة لحجز البطاقة." : `الشركة معتمدة والفرع ${selectedBranchLabel || "المطلوب"} صحيح.`,
      true,
      6
    );

    stopPreConfirmWork();

    if (
      !settings.autoConfirm
    ) {
      await stopAfterBranch();

      return true;
    }

    awaitingAutoConfirm =
      true;

    notify(
      isCardBooking() ? "الشركة جاهزة" : "تم اختيار الفرع",
      isCardBooking() ? "شركة الصرافة معتمدة — أكمل التحقق يدويًا." : `${selectedBranchLabel} — أكمل Cloudflare يدويًا.`,
      "branch"
    );

    pageNotify(
      "confirm",
      "الحجز جاهز للتأكيد",
      isCardBooking() ? "شركة الصرافة معتمدة. بانتظار التحقق." : "تم اعتماد الشركة والفرع. بانتظار التحقق.",
      true,
      7
    );

    setRuntime(
      "confirm",
      isCardBooking() ? "الشركة معتمدة. بانتظار التحقق لتأكيد البطاقة." : `تم اختيار ${selectedBranchLabel}. بانتظار إكمال Cloudflare يدويًا.`,
      {
        nextRefreshAt: null,
        errorCode:
          "",

        errorDetails:
          null
      }
    );

    installConfirmObserver();
    return true;
  }


  async function ensureBranchAfterCompany(
    timeoutMs = 900
  ) {
    if (
      currentBranchIsCorrect()
    ) {
      return finalizeVerifiedBooking();
    }

    /*
     * Livewire ربما مسح الفرع.
     */
    branchSelected =
      false;

    const token = companyFlowToken;
    const started = performance.now();

    while (
      performance.now() -
      started <
      timeoutMs
    ) {
      if (!settings.enabled || !running || awaitingAutoConfirm || token !== companyFlowToken) return false;
      attachBranchSelect();

      const select =
        findBranchSelect();

      if (
        select &&
        !select.disabled
      ) {
        const match =
          findTargetOption(
            select
          );

        if (match) {
          const result =
            await trySelectBranch();

          if (
            result ||
            currentBranchIsCorrect()
          ) {
            return true;
          }
        }
      }

      await sleep(10);
    }

    /*
     * بعد اختيار الشركة أصبح
     * الهدف غير متاح.
     */
    if (!settings.enabled || !running || awaitingAutoConfirm || token !== companyFlowToken) return false;
    if (settings.waitForTargetBranch) {
      const seconds = Math.max(0.5, Math.min(30, Number(settings.branchRefreshSeconds) || 2));
      pageNotify("warning", "انتظار الفرع المطلوب", `الفرع غير متاح الآن. تحديث الصفحة بعد ${seconds} ثانية.`, false, Math.min(seconds, 3));
      await setRuntime("branch_wait", `انتظار الفرع المطلوب — تحديث بعد ${seconds} ثانية.`, {nextRefreshAt: Date.now() + seconds * 1000});
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => {
        if (!settings.enabled || awaitingAutoConfirm) return;
        if (currentBranchIsCorrect()) {
          finalizeVerifiedBooking().catch(() => {});
          return;
        }
        location.reload();
      }, seconds * 1000);
      return false;
    }
    clearTimeout(refreshTimer);
    refreshTimer = null;
    pageNotify("branch", "مراقبة الفرع", "التحديث التلقائي متوقف. ستختار الإضافة الفرع إذا ظهر في الصفحة.", false, 4);
    await setRuntime("branch_wait", "شركة الصرافة معتمدة. انتظار الفرع دون تحديث تلقائي.", {nextRefreshAt:null});
    return false;
  }


  async function afterCompanyConfirmed(
    companyLabel = ""
  ) {
    if (
      !companyIsConfirmed()
    ) {
      return false;
    }

    let displayName =
      companyLabel;

    if (
      companyLabel &&
      COMPANY_LIB
        ?.extractBaseName
    ) {
      displayName =
        COMPANY_LIB
          .extractBaseName(
            companyLabel
          );
    }

    pageNotify(
      "company",
      "تم اعتماد شركة الصرافة",

      displayName ||
      "تم تأكيد اختيار الشركة من المنصة.",

      true,
      6
    );

    if (isCardBooking()) {
      selectedBranchLabel = "";
      if (!bookingSelectionsReady()) {
        await reportError("BOOKING_MODE_MISMATCH", "هذه الصفحة تعرض فرع استلام الدولار. اختر وضع دولار كاش ثم أعد التشغيل.", {}, false);
        return false;
      }
      return finalizeVerifiedBooking();
    }
    return ensureBranchAfterCompany();
  }

  async function retryEditPageIfEnabled(message) {
    if (!settings.waitForTargetBranch || !settings.enabled) return false;
    const seconds = Math.max(0.5, Math.min(30, Number(settings.branchRefreshSeconds) || 2));
    await setRuntime("branch_wait", `${message} تحديث صفحة التأكيد بعد ${seconds} ثانية.`,
      {nextRefreshAt:Date.now()+seconds*1000});
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      if (!settings.enabled || awaitingAutoConfirm) return;
      if (companyIsConfirmed() && currentBranchIsCorrect()) {
        finalizeVerifiedBooking().catch(() => {});
        return;
      }
      location.reload();
    }, seconds*1000);
    return true;
  }


  async function evaluateBranchFirst() {
    if (isCardBooking() || branchSelected || awaitingAutoConfirm || !settings.enabled) return false;
    const select = findBranchSelect();
    if (!select || select.disabled || !findTargetOption(select)) return false;
    branchFirstDecisionDone = true;
    return trySelectBranch();
  }

async function handleBranchSuccess(
    select,
    targetName
  ) {
    if (
      !verifySelectedBranch(
        select,
        targetName
      )
    ) {
      return false;
    }

    branchSelected =
      true;

    branchFirstDecisionDone =
      true;

    selectedBranchLabel =
      String(
        select.selectedOptions?.[0]
          ?.textContent ||
        targetName
      )
        .trim()
        .replace(
          /\s+/g,
          " "
        );

    log(
      "BRANCH",
      "Branch selected and verified",
      {
        target:
          targetName,

        selected:
          selectedBranchLabel,

        companyConfirmed:
          companyIsConfirmed()
      }
    );

    pageNotify(
      "branch",
      "تم اختيار الفرع",
      `${selectedBranchLabel} — تم التحقق من القيمة.`,
      true,
      5
    );

    /*
     * إذا الشركة معتمدة أصلًا،
     * انتهى التحقق.
     */
    if (
      companyIsConfirmed()
    ) {
      return afterCompanyConfirmed();
    }

    /*
     * الفرع تم اختياره أولًا.
     * الآن نبدأ الشركة.
     */
    await setRuntime(
      "company",
      `تم اختيار ${selectedBranchLabel}. جاري اختيار شركة الصرافة.`,
      {
        selectedBranch:
          selectedBranchLabel,

        errorCode:
          "",

        errorDetails:
          null
      }
    );

    // Do not restart a company request already in flight when the branch appears.
    if (!companyFlowStarted) companyFlow().catch(() => {});

    return true;
  }

  async function trySelectBranch() {
    if (
      isCardBooking() ||
      branchSelected ||
      branchSelectionInProgress ||
      awaitingAutoConfirm ||
      !settings.enabled
    ) {
      return false;
    }

    if (!canAttemptBranch()) {
      return false;
    }

    /*
     * MutationObserver و change قد يعملان في اللحظة نفسها.
     * هذا القفل يمنع عشرات محاولات اختيار الفرع المتوازية.
     */
    branchSelectionInProgress = true;

    const select = findBranchSelect();

    if (
      !select ||
      select.disabled
    ) {
      branchSelectionInProgress = false;
      return false;
    }

    const match =
      findTargetOption(select);

    if (!match) {
      branchSelectionInProgress = false;
      return false;
    }

    const {
      option,
      targetName
    } = match;

    log(
      "BRANCH",
      "Target option found",
      {
        target: targetName,
        optionText:
          String(
            option.textContent || ""
          )
      }
    );

    const nativeSetter =
      Object.getOwnPropertyDescriptor(
        HTMLSelectElement.prototype,
        "value"
      )?.set;

    if (nativeSetter) {
      nativeSetter.call(
        select,
        option.value
      );
    } else {
      select.value = option.value;
    }

    select.dispatchEvent(
      new Event("input", {
        bubbles: true
      })
    );

    select.dispatchEvent(
      new Event("change", {
        bubbles: true
      })
    );

    if (
      verifySelectedBranch(
        select,
        targetName
      )
    ) {
      branchSelectionInProgress = false;
      return handleBranchSuccess(
        select,
        targetName
      );
    }

    await Promise.resolve();

    let latest = findBranchSelect();

    if (
      verifySelectedBranch(
        latest,
        targetName
      )
    ) {
      branchSelectionInProgress = false;
      return handleBranchSuccess(
        latest,
        targetName
      );
    }

    await nextFrame();

    latest = findBranchSelect();

    if (
      verifySelectedBranch(
        latest,
        targetName
      )
    ) {
      branchSelectionInProgress = false;
      return handleBranchSuccess(
        latest,
        targetName
      );
    }

    await sleep(25);

    latest = findBranchSelect();

    if (
      verifySelectedBranch(
        latest,
        targetName
      )
    ) {
      branchSelectionInProgress = false;
      return handleBranchSuccess(
        latest,
        targetName
      );
    }

    log(
      "BRANCH",
      "Platform did not keep selected branch value."
    );

    branchSelectionInProgress = false;
    return false;
  }

  function attachBranchSelect() {
    const select =
      findBranchSelect();

    if (
      !select ||
      observedBranchSelect ===
        select
    ) {
      return;
    }

    branchObserver?.disconnect();

    observedBranchSelect =
      select;

    branchObserver =
      new MutationObserver(() => {
        // MutationObserver batches updates already; do not debounce ready options.
        evaluateBranchFirst().catch(() => {});
      });

    branchObserver.observe(
      select,
      {
        childList:
          true,

        subtree:
          true,

        attributes:
          true,

        attributeFilter: [
          "disabled",
          "value"
        ]
      }
    );

    select.addEventListener(
      "change",
      () => {
        evaluateBranchFirst()
          .catch(() => {});

        trySelectBranch()
          .catch(() => {});
      },
      true
    );

    log(
      "BRANCH",
      "#bank_branch observer attached"
    );

    evaluateBranchFirst()
      .catch(() => {});
  }

  function installBranchObserver() {
    attachBranchSelect();

    pageObserver?.disconnect();

    pageObserver =
      new MutationObserver(() => {
        attachBranchSelect();

        evaluateBranchFirst()
          .catch(() => {});

        trySelectBranch()
          .catch(() => {});
      });

    pageObserver.observe(
      document.documentElement,
      {
        childList:
          true,

        subtree:
          true,

        attributes:
          true,

        attributeFilter: [
          "disabled",
          "hidden"
        ]
      }
    );
  }

  function scheduleBranchDiagnosis(
    delay = 3500
  ) {
    clearTimeout(
      branchErrorTimer
    );

    branchErrorTimer =
      setTimeout(
        async () => {
          if (
            branchSelected ||
            awaitingAutoConfirm ||
            !settings.enabled
          ) {
            return;
          }

          const select =
            findBranchSelect();

          if (
            select &&
            findTargetOption(select)
          ) {
            await trySelectBranch();
            return;
          }

          await reportError(
            "BRANCH_NOT_AVAILABLE",
            "الفرع المطلوب غير متوفر حاليًا.",
            {
              targets:
                targetNames(),

              selectFound:
                Boolean(select),

              disabled:
                Boolean(
                  select?.disabled
                ),

              optionCount:
                select
                  ? branchOptions(
                      select
                    ).length
                  : 0
            },
            true
          );
        },
        delay
      );
  }

  function actionText(element) {
    if (!element) return "";

    return element
      .getAttributeNames()
      .map(name =>
        `${name}=${element.getAttribute(name) || ""}`
      )
      .join(" ");
  }

  function isCompanyElement(element) {
    return /selectContract/i
      .test(
        actionText(element)
      );
  }

  function isElementActionable(
    element
  ) {
    if (
      !element ||
      !element.isConnected
    ) {
      return false;
    }

    if (
      element.disabled ||
      element.getAttribute(
        "aria-disabled"
      ) === "true"
    ) {
      return false;
    }

    const style =
      getComputedStyle(
        element
      );

    if (
      style.display === "none" ||
      style.visibility === "hidden" ||
      style.pointerEvents === "none"
    ) {
      return false;
    }

    const rect =
      element
        .getBoundingClientRect();

    return (
      rect.width > 0 &&
      rect.height > 0
    );
  }

function actionContractId(element) {
    const match =
      actionText(element)
        .match(
          /selectContract\s*\(\s*(\d+)\s*\)/i
        );

    return match
      ? Number(match[1])
      : null;
  }

  function findCompanyTrigger() {
    const items = [
      ...document.querySelectorAll(
        'button,a,li,div,span,[role="button"]'
      )
    ];

    /*
     * الأولوية لعنصر لديه
     * openContractsSelect.
     */
    const direct =
      items.find(element =>
        isElementActionable(
          element
        ) &&
        /openContractsSelect/i
          .test(
            actionText(
              element
            )
          )
      );

    if (direct) {
      return direct;
    }

    const phrase =
      normalize(
        "اختيار شركة الصرافة"
      );

    const matches =
      items.filter(element => {
        if (
          !isElementActionable(
            element
          )
        ) {
          return false;
        }

        const text =
          normalize(
            element.textContent ||
            ""
          );

        return (
          text.includes(
            phrase
          ) &&
          text.length < 180
        );
      });

    /*
     * اختر أصغر عنصر نصيًا
     * لتجنب الضغط على container كبير.
     */
    matches.sort(
      (a, b) =>
        String(
          a.textContent || ""
        ).length -
        String(
          b.textContent || ""
        ).length
    );

    return matches[0] || null;
  }

  function companyItems() {
    const raw = [
      ...document.querySelectorAll(
        'button,a,li,div,span,[role="button"]'
      )
    ].filter(element =>
      isCompanyElement(
        element
      ) &&
      isElementActionable(
        element
      )
    );

    /*
     * إذا كان الأب والابن كلاهما
     * يحملان selectContract،
     * نفضّل العنصر الداخلي الأكثر تحديدًا.
     */
    return raw.filter(
      element =>
        !raw.some(
          other =>
            other !== element &&
            element.contains(
              other
            )
        )
    );
  }

  function findLivewireComponent() {
    return [
      ...document.querySelectorAll(
        '[wire\\:id][wire\\:snapshot]'
      )
    ].find(root => {
      const snapshot =
        root.getAttribute(
          "wire:snapshot"
        ) || "";

      return (
        snapshot.includes("contracts") ||
        snapshot.includes("selectedContract") ||
        snapshot.includes("selectContract")
      );
    }) || null;
  }

  function contractsFromSnapshot() {
    const root =
      findLivewireComponent();

    if (!root) {
      return {
        root: null,
        contracts: []
      };
    }

    try {
      const snapshot =
        JSON.parse(
          root.getAttribute(
            "wire:snapshot"
          ) || "{}"
        );

      const contracts = [];
      const seen = new Set();

      function walk(value) {
        if (
          !value ||
          typeof value !== "object"
        ) {
          return;
        }

        if (!Array.isArray(value)) {
          const id =
            value.contract_id ??
            value.contractId;

          const label =
            value.company_name ??
            value.companyName ??
            value.label ??
            value.name;

          if (
            id != null &&
            label
          ) {
            const key =
              String(id);

            if (!seen.has(key)) {
              seen.add(key);

              contracts.push({
                contractId: id,
                label:
                  String(label)
              });
            }
          }
        }

        for (
          const child of
          Object.values(value)
        ) {
          walk(child);
        }
      }

      walk(snapshot);

      return {
        root,
        contracts
      };

    } catch (error) {
      log(
        "LIVEWIRE",
        "Snapshot parse failed",
        {
          error:
            String(
              error?.message ||
              error
            )
        }
      );

      return {
        root,
        contracts: []
      };
    }
  }

  async function callLivewire(
    method,
    contractId = null
  ) {
    const { root } =
      contractsFromSnapshot();

    const componentId =
      root?.getAttribute(
        "wire:id"
      );

    if (!componentId) {
      log(
        "LIVEWIRE",
        "Component not found"
      );

      return false;
    }

    const response =
      await chrome.runtime
        .sendMessage({
          type: "LIVEWIRE_ACTION",
          method,
          componentId,
          contractId
        });

    log(
      "LIVEWIRE",
      `${method} result`,
      {
        ok:
          Boolean(
            response?.ok
          ),

        error:
          response?.result
            ?.error ||
          ""
      }
    );

    return Boolean(
      response?.ok
    );
  }

  async function waitForCompanyConfirmed(
    timeoutMs
  ) {
    const started = performance.now();
    const token = companyFlowToken;

    while (
      performance.now() - started < timeoutMs
    ) {
      if (!settings.enabled || !running || token !== companyFlowToken) return false;
      if (
        companyIsConfirmed()
      ) {
        logCompanyFields(
          "confirmed"
        );

        return true;
      }

      await sleep(10);
    }

    logCompanyFields(
      "timeout"
    );

    return false;
  }

  async function openCompanyList() {
    if (companyIsConfirmed() || companyItems().length) return true;
    // Share the pending opening: a second click can close a loading dropdown.
    if (companyListOpening) return companyListOpening;
    companyListOpening = (async () => {
      const trigger = findCompanyTrigger();
      if (trigger) {
        trigger.click();
        log("COMPANY", "Opening company list once; waiting for options");
      } else {
        await callLivewire("openContractsSelect");
      }
      const started = performance.now();
      const token = companyFlowToken;
      while (settings.enabled && token === companyFlowToken &&
             performance.now() - started < companyResponseTimeout()) {
        if (companyIsConfirmed() || companyItems().length) return true;
        await sleep(15);
      }
      return false;
    })();
    try { return await companyListOpening; }
    finally { companyListOpening = null; }
  }

  async function collectCompanyCandidates(
    timeoutMs = 900
  ) {
    const started =
      performance.now();

    let previousSignature =
      "";

    let stableCount =
      0;

    while (
      performance.now() -
      started <
      timeoutMs
    ) {
      const elements =
        companyItems();

      if (
        elements.length
      ) {
        const seen =
          new Set();

        const candidates =
          [];

        for (
          const element of
          elements
        ) {
          const label =
            String(
              element.textContent ||
              ""
            )
              .trim()
              .replace(
                /\s+/g,
                " "
              );

          if (!label) {
            continue;
          }

          const key =
            COMPANY_LIB
              ?.normalizeCompanyName
              ? COMPANY_LIB
                  .normalizeCompanyName(
                    label
                  )
              : normalize(label);

          if (
            !key ||
            seen.has(key)
          ) {
            continue;
          }

          seen.add(key);

          candidates.push({
            source:
              "dom",

            element,

            contractId:
              actionContractId(
                element
              ),

            label
          });
        }

        // First available and an exact requested company need no list-stability delay.
        // Random selection still waits for the list to settle.
        if (candidates.length &&
            ((settings.companyMode === "first_available" && !companyChoiceForRetry) ||
             (settings.companyMode === "specific" && chooseCompanyCandidate(candidates)))) {
          return candidates;
        }

        const signature =
          candidates
            .map(item =>
              COMPANY_LIB
                ?.normalizeCompanyName
                ? COMPANY_LIB
                    .normalizeCompanyName(
                      item.label
                    )
                : normalize(
                    item.label
                  )
            )
            .join("|");

        if (
          signature &&
          signature ===
            previousSignature
        ) {
          stableCount += 1;

        } else {
          stableCount = 0;
        }

        previousSignature =
          signature;

        /*
         * فحصان متتاليان بفاصل 50ms
         * يكفيان عادة لتجنب DOM المؤقت.
         */
        if (
          candidates.length &&
          stableCount >= 1
        ) {
          return candidates;
        }
      }

      await sleep(15);
    }

    /*
     * Snapshot fallback فقط
     * إذا لم تظهر عناصر DOM.
     */
    const snapshot =
      contractsFromSnapshot();

    if (
      snapshot.contracts.length
    ) {
      return snapshot.contracts.map(
        contract => ({
          source:
            "snapshot",

          element:
            null,

          contractId:
            contract.contractId,

          label:
            contract.label
        })
      );
    }

    return [];
  }

  function chooseCompanyCandidate(
    candidates
  ) {
    if (
      settings.companyMode ===
      "specific"
    ) {
      return candidates.find(
        candidate =>
          COMPANY_LIB
            ?.namesEqual
            ? COMPANY_LIB
                .namesEqual(
                  candidate.label,
                  settings.companyName
                )
            : normalize(
                candidate.label
              ) ===
              normalize(
                settings.companyName
              )
      ) || null;
    }

    const actionable = candidates.filter(candidate =>
      !candidate.element || isElementActionable(candidate.element)
    );

    // Prefer the company confirmed for this request on the previous refresh.
    if (companyChoiceForRetry) {
      const previous = actionable.find(candidate =>
        COMPANY_LIB?.namesEqual
          ? COMPANY_LIB.namesEqual(candidate.label, companyChoiceForRetry)
          : normalize(candidate.label) === normalize(companyChoiceForRetry)
      );
      if (previous) return previous;
    }

    // تجاهل العدد المحدد من الشركات، ثم اختر من البقية إن وجدت.
    if (settings.companyMode === "random_from_5") {
      const skip = Math.max(0, Math.min(20, Math.floor(Number(settings.companySkipCount) || 0)));
      const pool = actionable.length > skip ? actionable.slice(skip) : actionable;
      if (!pool.length) return null;
      return pool[Math.floor(Math.random() * pool.length)] || null;
    }

    return actionable[0] || null;
  }

  async function resolveSnapshotCandidateToDom(candidate, timeoutMs = 2600) {
    if (candidate?.element) return candidate;

    /*
     * Snapshot يعطينا البيانات بسرعة، لكنه ليس عنصرًا قابلًا للنقر.
     * بدل القفز مباشرة إلى selectContract (الذي قد يرجع 500)،
     * ننتظر DOM الحقيقي ونطابق نفس الشركة ثم ننقرها.
     */
    await openCompanyList();
    const started = performance.now();

    while (performance.now() - started < timeoutMs) {
      const items = companyItems();
      const match = items.find(element => {
        const label = String(element.textContent || "")
          .trim().replace(/\s+/g, " ");
        const sameName = COMPANY_LIB?.namesEqual
          ? COMPANY_LIB.namesEqual(label, candidate.label)
          : normalize(label) === normalize(candidate.label);
        const id = actionContractId(element);
        return sameName &&
          (candidate.contractId == null || id == null || id === candidate.contractId);
      });

      if (match) {
        return {
          ...candidate,
          source: "dom-resolved",
          element: match,
          contractId: actionContractId(match) ?? candidate.contractId,
          label: String(match.textContent || candidate.label).trim().replace(/\s+/g, " ")
        };
      }
      await sleep(20);
    }

    return candidate;
  }

  async function performCompanyCandidate(
    candidate,
    attemptNumber,
    token
  ) {
    if (
      !settings.enabled || token !==
      companyFlowToken
    ) {
      return false;
    }

    candidate = await resolveSnapshotCandidateToDom(candidate);

    if (!settings.enabled || token !== companyFlowToken) {
      return false;
    }

    log(
      "COMPANY",
      `Attempt ${attemptNumber}/${Math.max(1, Number(settings.companyAttempts) || 2)}`,
      {
        source:
          candidate.source,

        label:
          candidate.label,

        contractId:
          candidate.contractId
      }
    );

    /*
     * الأولوية دائمًا للنقر
     * الحقيقي في DOM.
     */
    if (
      candidate.element &&
      isElementActionable(
        candidate.element
      )
    ) {
      candidate.element.dataset
        .cblAutoCompanyClick =
        "1";

      candidate.element.click();

      log(
        "AUTO_CLICK",
        "Clicking actual company DOM element",
        {
          label:
            candidate.label,

          contractId:
            candidate.contractId
        }
      );

      setTimeout(() => {
        try {
          delete candidate
            .element
            .dataset
            .cblAutoCompanyClick;
        } catch {}
      }, 0);

      /*
       * سجل الموقع الحقيقي أظهر أن
       * الحقول قد تتأخر تحت الضغط.
       * ننتظر ضمن المهلة المحددة، ونخرج فور اعتمادها.
       * لا نكرر الطلب عبر Livewire فوق نقرة DOM معلقة.
       */
      if (
        await waitForCompanyConfirmed(
          companyResponseTimeout()
        )
      ) {
        return true;
      }
      return false;
    }

    if (
      !settings.enabled || token !==
      companyFlowToken
    ) {
      return false;
    }

    /*
     * contractId=null ليس فشلًا.
     *
     * Livewire fallback يستخدم فقط
     * عندما يتوفر Contract ID موثوق.
     */
    if (
      candidate.contractId != null
    ) {
      log(
        "COMPANY",
        "DOM click not adopted. Trying Livewire fallback for same company."
      );

      const ok =
        await callLivewire(
          "selectContract",
          candidate.contractId
        );

      if (
        ok &&
        await waitForCompanyConfirmed(
          companyResponseTimeout()
        )
      ) {
        return true;
      }
    }

    return false;
  }

  async function companyFlow() {
    if (
      companyFlowStarted ||
      awaitingAutoConfirm
    ) {
      return;
    }

    companyFlowStarted =
      true;

    const token =
      ++companyFlowToken;

    /*
     * الشركة معتمدة بالفعل.
     */
    if (
      companyIsConfirmed()
    ) {
      setRuntime(
        "branch",
        "شركة الصرافة معتمدة. إعادة التحقق من الفرع.",
        {nextRefreshAt:null}
      ).catch(() => {});

      await afterCompanyConfirmed();

      return;
    }

    /*
     * الاختيار اليدوي للشركة.
     */
    if (
      settings.companyMode ===
      "disabled"
    ) {
      log(
        "COMPANY",
        "Waiting for manual company selection"
      );

      pageNotify(
        "company",
        "اختيار الشركة يدوي",
        "اختر شركة الصرافة من الموقع. ستكتشف الإضافة اعتمادها تلقائيًا.",
        false,
        8
      );

      await setRuntime(
        "company",
        "اختر شركة الصرافة يدويًا من الموقع."
      );

      while (
        token ===
          companyFlowToken &&
        settings.enabled &&
        !companyIsConfirmed()
      ) {
        await sleep(15);
      }

      if (
        token ===
          companyFlowToken &&
        companyIsConfirmed()
      ) {
        await afterCompanyConfirmed(
          "اختيار يدوي"
        );
      }

      return;
    }

    /*
     * الشركة المحددة يجب أن يكون
     * لها اسم.
     */
    if (
      settings.companyMode ===
        "specific" &&
      !String(
        settings.companyName ||
        ""
      ).trim()
    ) {
      await reportError(
        "COMPANY_NAME_EMPTY",
        "لم يتم تحديد شركة الصرافة المطلوبة.",
        {},
        false
      );

      return;
    }

    setRuntime(
      "company",

      settings.companyMode ===
        "specific"
        ? `البحث عن شركة: ${settings.companyName}`
        : settings.companyMode === "random_from_5"
          ? "اختيار شركة عشوائيًا من الخامسة إلى الأخيرة."
          : "اختيار أول شركة صرافة متاحة.",
      {nextRefreshAt:null,errorCode:"",errorDetails:null}
    ).catch(() => {});

    const maximumAttempts =
      Math.max(
        1,
        Math.min(
          3,
          Number(
            settings.companyAttempts
          ) || 2
        )
      );

    for (
      let attempt = 1;
      attempt <=
        maximumAttempts;
      attempt++
    ) {
      if (
        token !==
          companyFlowToken ||
        companyIsConfirmed()
      ) {
        break;
      }

      companyAttemptsUsed =
        attempt;

      await openCompanyList();

      let candidates =
        await collectCompanyCandidates(
          900
        );


      log(
        "COMPANY",
        "Candidates detected",
        {
          count:
            candidates.length,

          labels:
            candidates
              .slice(0, 25)
              .map(item =>
                item.label
              )
        }
      );

      if (
        token !==
        companyFlowToken
      ) {
        return;
      }

      const candidate =
        chooseCompanyCandidate(
          candidates
        );

      if (!candidate) {
        if (await retryEditPageIfEnabled("لم تظهر شركة صرافة قابلة للاختيار بعد.")) return;
        await reportError(
          "COMPANY_NOT_FOUND",

          settings.companyMode ===
            "specific"
            ? "الشركة المحددة غير موجودة في القائمة الحالية."
            : "لم يتم العثور على شركة صرافة قابلة للاختيار.",

          {
            detected:
              candidates.length,

            attemptsUsed:
              companyAttemptsUsed,

            companyName:
              settings.companyMode ===
                "specific"
                ? settings.companyName
                : ""
          },

          false
        );

        return;
      }

      const success =
        await performCompanyCandidate(
          candidate,
          attempt,
          token
        );

      if (
        token !==
        companyFlowToken
      ) {
        return;
      }

      if (success) {
        companyChoiceForRetry = candidate.label;
        log(
          "COMPANY",
          "Company confirmed successfully",
          {
            label:
              candidate.label
          }
        );

        let displayName =
          candidate.label;

        if (
          COMPANY_LIB
            ?.extractBaseName
        ) {
          displayName =
            COMPANY_LIB
              .extractBaseName(
                candidate.label
              );
        }

        notify(
          "تم اعتماد شركة الصرافة",
          displayName,
          "company"
        );

        setRuntime(
          "branch",
          "تم اعتماد شركة الصرافة. التحقق من الفرع.",
          {
            nextRefreshAt:null,
            selectedCompany:
              candidate.label,

            errorCode:
              "",

            errorDetails:
              null
          }
        ).catch(() => {});

        await afterCompanyConfirmed(candidate.label);

        return;
      }

      /*
       * لا نعيد استخدام عنصر DOM قديم.
       * المحاولة التالية تعيد فتح
       * واكتشاف القائمة من الصفر.
       */
      if (
        attempt <
        maximumAttempts
      ) {
        await sleep(
          attempt === 1
            ? 350
            : 650
        );
      }
    }

    if (
      !companyIsConfirmed() &&
      token ===
        companyFlowToken
    ) {
      if (await retryEditPageIfEnabled("لم تثبت المنصة اختيار شركة الصرافة بعد.")) return;
      await reportError(
        "COMPANY_SELECTION_FAILED",
        "تعذر اعتماد شركة الصرافة.",
        {
          attemptsUsed:
            companyAttemptsUsed,

          reason:
            "تم استنفاد عدد المحاولات المحدد."
        },
        false
      );
    }
  }

  function companyElementFromClick(
    target
  ) {
    let node =
      target;

    while (
      node &&
      node !== document.body
    ) {
      if (
        isCompanyElement(node)
      ) {
        return node;
      }

      node =
        node.parentElement;
    }

    return null;
  }

  function attachPassiveDiagnostics() {
    if (
      diagnosticsListenerAttached
    ) {
      return;
    }

    diagnosticsListenerAttached =
      true;

    document.addEventListener(
      "click",
      event => {
        if (
          !settings.diagnosticsEnabled
        ) {
          return;
        }

        const companyElement =
          companyElementFromClick(
            event.target
          );

        if (!companyElement) {
          return;
        }

        const automatic =
          companyElement.dataset
            .cblAutoCompanyClick ===
          "1";

        log(
          automatic
            ? "AUTO_CLICK"
            : "MANUAL_CLICK",

          automatic
            ? "Automatic company click detected"
            : "Manual company click detected",

          {
            label:
              String(
                companyElement
                  .textContent ||
                ""
              )
                .trim()
                .replace(
                  /\s+/g,
                  " "
                ),

            contractId:
              actionContractId(
                companyElement
              )
          }
        );

        [50, 300, 1000]
          .forEach(delay => {
            setTimeout(
              () => {
                logCompanyFields(
                  `+${delay}ms`
                );
              },
              delay
            );
          });
      },
      true
    );
  }

  async function handleWaitingPage() {
    async function openIfFound() {
      const link =
        findEditLink();

      if (!link) {
        return false;
      }

      clearTimeout(
        refreshTimer
      );

      refreshTimer = null;

      pageObserver?.disconnect();
      pageObserver = null;

      log(
        "PAGE",
        "Exchange company option detected"
      );

      notify(
        "ظهر خيار شركة الصرافة",
        "سيتم فتح صفحة إكمال الحجز الآن.",
        "option"
      );
      link.click();

      return true;
    }

    if (
      await openIfFound()
    ) {
      return;
    }

    pageObserver =
      new MutationObserver(() => {
        openIfFound()
          .catch(() => {});
      });

    pageObserver.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true
      }
    );

    refreshTimer =
      setTimeout(() => {
        if (
          !running ||
          branchSelected ||
          awaitingAutoConfirm
        ) {
          return;
        }

        log(
          "PAGE",
          "Reloading request page"
        );

        location.reload();

      }, settings.refreshSeconds * 1000);

    await setRuntime(
      "running",
      `مراقبة الخيار. تحديث الصفحة بعد ${settings.refreshSeconds} ثوانٍ.`,
      {
        nextRefreshAt:
          Date.now() +
          settings.refreshSeconds *
            1000,

        errorCode: "",
        errorDetails: null
      }
    );
  }

  async function handleEditPage() {
    installBookingSuccessWatcher();
    log("PAGE", "Completion page detected");

    notify(
      "صفحة إكمال الحجز",
      "تم فتح صفحة إكمال الحجز.",
      "page"
    );

    // The branch list may be empty until the platform accepts a company.
    installBranchObserver();
    await evaluateBranchFirst();
    if (!companyFlowStarted) companyFlow().catch(() => {});
  }

  async function recoverEngine() {
    await loadState();

    if (
      !settings.recoveryEnabled
    ) {
      return;
    }

    if (
      pageShowsRateLimit()
    ) {
      await chrome.runtime.sendMessage({
        type:
          "RATE_LIMIT_DETECTED"
      });

      return;
    }

    if (
      pageShowsExpiredSession()
    ) {
      await reportError(
        "SESSION_EXPIRED",
        "انتهت جلسة الدخول. سجل الدخول من جديد.",
        {},
        false
      );

      return;
    }

    log("RECOVERY", "Resuming company and branch monitoring");

    clearTimeout(
      refreshTimer
    );

    clearTimeout(
      branchErrorTimer
    );

    clearTimeout(
      branchDecisionTimer
    );

    refreshTimer =
      null;

    branchErrorTimer =
      null;

    branchDecisionTimer =
      null;

    pageObserver?.disconnect();
    branchObserver?.disconnect();

    pageObserver =
      null;

    branchObserver =
      null;

    observedBranchSelect =
      null;

    if (
      awaitingAutoConfirm
    ) {
      await setRuntime(
        "confirm",
        "تم التعافي. استعادة مراقبة التأكيد."
      );

      installConfirmObserver();

      return;
    }

    if (
      isEditPage()
    ) {
      branchFallbackMode =
        false;

      branchFirstDecisionDone =
        false;

      branchSelected = false;
      finalizingBooking = false;

      companyFlowStarted =
        false;

      installBranchObserver();

      await evaluateBranchFirst();
      if (!companyFlowStarted) companyFlow().catch(() => {});

      return;
    }

    if (
      isRequestPage()
    ) {
      await handleWaitingPage();

      return;
    }

    await reportError(
      "PAGE_NOT_SUPPORTED",
      "افتح صفحة الطلب أو صفحة إكمال الحجز.",
      {},
      false
    );
  }

  async function pauseForMouseInteraction() {
    if (mousePauseTriggered || !running || !settings.enabled || !settings.pauseOnMouseMove) return;
    mousePauseTriggered = true;
    clearEngine();
    pageNotify("info", "تم التحويل للوضع اليدوي", "تم إيقاف الأوامر الآلية بسبب حركة الماوس. أعد التشغيل من الإضافة للمتابعة.", false, 1.2);
    try {
      await chrome.runtime.sendMessage({ type: "MANUAL_TAKEOVER" });
    } catch {}
  }

  function installMousePause() {
    if (mousePauseListenerAttached) return;
    mousePauseListenerAttached = true;
    let previous = null;
    let observedToken = mouseSessionToken;
    document.addEventListener("mousemove", event => {
      if (observedToken !== mouseSessionToken) {
        observedToken = mouseSessionToken;
        previous = null;
      }
      if (!running || !settings.enabled || !settings.pauseOnMouseMove) {
        previous = null;
        return;
      }
      const point = {x: event.clientX, y: event.clientY};
      if (!previous) { previous = point; return; }
      const distance = Math.hypot(point.x - previous.x, point.y - previous.y);
      previous = point;
      const threshold = {low: 18, medium: 8, high: 3}[settings.mouseSensitivity] || 8;
      if (distance < threshold) return;
      pauseForMouseInteraction().catch(() => {});
    }, { passive: true, capture: true });
  }

  async function startEngine() {
    mouseSessionToken++;
    if (
      !await loadState()
    ) {
      return;
    }

    attachPassiveDiagnostics();
    installConfirmClickMonitor();
    installMousePause();
    mousePauseTriggered = false;

    if (!settings.enabled) {
      return;
    }

    running = true;

    if (pageShowsRateLimit()) {
      await chrome.runtime.sendMessage({
        type: "RATE_LIMIT_DETECTED"
      });

      clearEngine();

      return;
    }

    if (pageShowsExpiredSession()) {
      await reportError(
        "SESSION_EXPIRED",
        "يبدو أن جلسة الدخول انتهت.",
        {},
        false
      );

      clearEngine();

      return;
    }

    if (isEditPage()) {
      await handleEditPage();
      return;
    }

    if (isRequestPage()) {
      await handleWaitingPage();
      return;
    }

    await setRuntime(
      "running",
      "افتح صفحة الطلب المطلوب."
    );
  }

  chrome.runtime.onMessage.addListener(
    (
      message,
      _sender,
      sendResponse
    ) => {
      if (typeof message?.type === "string" && message.type.startsWith("EVIDENCE_")) {
        return false;
      }
      (async () => {
        switch (message?.type) {
          case "START_BOOKING_ASSISTANT": {
            clearEngine();

            companyFlowStarted = false;
            companyAttemptsUsed = 0;

            branchSelected = false;
            selectedBranchLabel = "";

            awaitingAutoConfirm = false;
            confirmClicked = false;
            finalizingBooking = false;

            branchFallbackMode = false;
            branchFirstDecisionDone = false;

            await startEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "STOP_BOOKING_ASSISTANT": {
            clearEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "PAUSE_FOR_RATE_LIMIT": {
            clearEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "RESUME_AFTER_COOLDOWN": {
            location.reload();

            sendResponse({
              ok: true
            });

            break;
          }

          case "RECOVER_BOOKING_ASSISTANT": {
            await recoverEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "DIAG_NETWORK_EVENT": {
            log(
              "NETWORK",
              "Platform request completed",
              message.event
            );

            sendResponse({
              ok: true
            });

            break;
          }

          default:
            sendResponse({
              ok: false,
              ignored: true
            });
        }
      })().catch(error => {
        try {
          sendResponse({
            ok: false,
            error:
              String(
                error?.message ||
                error
              )
          });
        } catch {}
      });

      return true;
    }
  );

  chrome.storage.onChanged.addListener(
    (changes, area) => {
      if (area !== "local") {
        return;
      }

      if (changes.bookingSettings) {
        const oldAutoConfirm = settings.autoConfirm;
        const oldBookingMode = settings.bookingMode;

        settings = {
          ...DEFAULT_SETTINGS,
          ...(changes.bookingSettings.newValue || {})
        };

        if (running && oldBookingMode !== settings.bookingMode) {
          clearEngine();
          chrome.runtime.sendMessage({type:"STOP_SESSION"}).catch(() => {});
          return;
        }

        if (running && !isCardBooking() && companyIsConfirmed() && !currentBranchIsCorrect() &&
            (settings.waitForTargetBranch !== changes.bookingSettings.oldValue?.waitForTargetBranch ||
             settings.branchRefreshSeconds !== changes.bookingSettings.oldValue?.branchRefreshSeconds)) {
          clearTimeout(refreshTimer);
          refreshTimer = null;
          ensureBranchAfterCompany(0).catch(() => {});
        }

        diagnostic.setEnabled(
          settings.diagnosticsEnabled
        );

        /*
         * إذا ألغى المستخدم التأكيد
         * التلقائي بعد اختيار الفرع،
         * توقف فورًا.
         */
        if (
          oldAutoConfirm &&
          !settings.autoConfirm &&
          awaitingAutoConfirm
        ) {
          awaitingAutoConfirm = false;

          stopAfterBranch()
            .catch(() => {});
        }
      }

      if (changes.branchCatalog) {
        catalog =
          Array.isArray(
            changes.branchCatalog.newValue
          )
            ? changes.branchCatalog.newValue
            : catalog;
      }
    }
  );

  startEngine()
    .catch(console.error);

  function installBookingSuccessWatcher() {
    if (window.__CBL_SUCCESS_WATCHER__) return;
    window.__CBL_SUCCESS_WATCHER__ = true;
    let done = false;
    const check = async () => {
      if (done) return;
      const text = normalize(document.body?.innerText || "");
      if (!text.includes(normalize("يرجى التوجه الى الفرع"))) return;
      done = true;
      clearEngine();
      notify("تم تأكيد الحجز بنجاح", "يرجى التوجه إلى الفرع.", "booking_success");
      pageNotify("success", "✓ تم الحجز بنجاح", "يرجى التوجه إلى الفرع.", true, 8);
      await setRuntime("success", "تم تأكيد الحجز — يرجى التوجه إلى الفرع.", {nextRefreshAt:null,errorCode:"",errorDetails:null});
      observer.disconnect();
    };
    const observer = new MutationObserver(() => check().catch(()=>{}));
    observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
    check().catch(()=>{});
  }
})();
