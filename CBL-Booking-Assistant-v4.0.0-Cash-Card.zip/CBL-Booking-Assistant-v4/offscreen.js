"use strict";

const SOUND_IDS = {
  classic: "alertClassic",
  bell: "alertBell",
  double: "alertDouble",
  rise: "alertRise",
  soft: "alertSoft",
  pulse: "alertPulse",
  chime: "alertChime",
  swift: "alertSwift",
  success: "bookingSuccess"
};

chrome.runtime.onMessage.addListener(
  (
    message,
    _sender,
    sendResponse
  ) => {
    if (
      message?.target !== "offscreen" ||
      message?.type !== "PLAY_SOUND"
    ) {
      return false;
    }

    const id =
      message.kind === "warning"
        ? "warningSound"
        : (
            SOUND_IDS[message.tone] ||
            SOUND_IDS.classic
          );

    const audio =
      document.getElementById(id);

    if (!audio) {
      sendResponse({
        ok: false,
        error:
          "ملف الصوت غير موجود."
      });

      return false;
    }

    document.querySelectorAll("audio")
      .forEach(item => {
        item.pause();
        item.currentTime = 0;
      });

    audio.volume = 0.9;

    audio.play()
      .then(
        () => {
          sendResponse({
            ok: true
          });
        },

        error => {
          sendResponse({
            ok: false,
            error:
              String(
                error?.message ||
                error
              )
          });
        }
      );

    return true;
  }
);