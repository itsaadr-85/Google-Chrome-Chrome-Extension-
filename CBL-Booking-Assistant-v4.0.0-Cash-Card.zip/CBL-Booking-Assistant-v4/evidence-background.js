"use strict";

// Isolated trial feature. Booking selection and confirmation code remains unchanged.
(() => {
  const STATE_KEY = "cblEvidenceTrialSession";
  const OPTIONS_KEY = "cblEvidenceTrialOptions";
  const HISTORY_KEY = "cblEvidenceTrialHistory";
  const SITE_ORIGIN = "https://fcms.cbl.gov.ly";
  const PENDING_LIFETIME = 20 * 60 * 1000;
  let queue = Promise.resolve();

  function serial(task) {
    const next = queue.then(task, task);
    queue = next.catch(() => {});
    return next;
  }
  async function state() {
    const data = await chrome.storage.session.get(STATE_KEY);
    return { name: "", accounts: {}, accountsById: {}, selectedIban: "", pending: null,
      lastExport: "", ...(data[STATE_KEY] || {}) };
  }
  async function put(value) {
    await chrome.storage.session.set({ [STATE_KEY]: value });
    return value;
  }
  async function options() {
    const data = await chrome.storage.local.get(OPTIONS_KEY);
    return { autoImage: true, autoText: true, folder: "CBL-Bookings",
      filenamePattern: "{name}_{date}_{time}",
      saveAs: false, notifySaved: true, ...(data[OPTIONS_KEY] || {}) };
  }
  function folderName(value) {
    const name = String(value || "CBL-Bookings").trim()
      .replace(/[\\/:*?"<>|\x00-\x1F]/g, "_")
      .replace(/\.\./g, "_").replace(/^\.+|\.+$/g, "").slice(0, 50);
    return name || "CBL-Bookings";
  }
  function siteUrl(url) {
    try { return new URL(url).origin === SITE_ORIGIN; } catch { return false; }
  }
  function accountId(value) {
    const id = String(value || "").toLowerCase();
    return /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(id) ? id : "";
  }
  function requestAccountId(url) {
    try {
      const path = new URL(url).pathname;
      return accountId(path.match(/\/bank-accounts\/([^/]+)(?:\/|$)/i)?.[1]);
    } catch { return ""; }
  }
  function inputAccount(value) {
    const iban = String(value?.iban || "").replace(/\s/g, "").toUpperCase();
    const accountNumber = String(value?.accountNumber || "").replace(/\s/g, "");
    const bank = String(value?.bank || "").trim().slice(0, 100);
    if (!/^LY\d{23}$/.test(iban) || !/^\d{8,25}$/.test(accountNumber) ||
        !/(مصرف|بنك|bank)/i.test(bank)) return null;
    return { iban, accountNumber, bank };
  }
  function filenameName(value, maxLength = 65) {
    return String(value || "صاحب_الحساب").trim()
      .replace(/[\\/:*?"<>|\x00-\x1F]/g, "_")
      .replace(/\s+/g, "_").replace(/^\.+|\.+$/g, "")
      .slice(0, maxLength) || "صاحب_الحساب";
  }
  function baseName(name, time, pattern) {
    const [date,clock] = time.split("_");
    const rendered = String(pattern || "{name}_{date}_{time}")
      .replaceAll("{name}",filenameName(name))
      .replaceAll("{date}",date)
      .replaceAll("{time}",clock);
    return filenameName(rendered,100);
  }
  function stamp() {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Tripoli", year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23"
    }).formatToParts(new Date());
    const p = key => parts.find(part => part.type === key)?.value || "00";
    return `${p("year")}-${p("month")}-${p("day")}_${p("hour")}${p("minute")}${p("second")}`;
  }
  async function saveText(name, account, time, trial = false) {
    if (!name || !account) throw new Error("افتح الصفحة الرئيسية لقراءة الاسم، ثم اعتمد الحساب من صفحة تفاصيله.");
    const content = [
      "بيانات الحساب المرتبط بالحجز", "",
      `اسم صاحب الحساب: ${name}`,
      `المصرف: ${account.bank}`,
      `رقم الحساب المصرفي الدولي (IBAN): ${account.iban}`,
      `رقم الحساب: ${account.accountNumber}`,
      `وقت الحفظ (طرابلس): ${time}`,
      trial ? "الحالة: ملف تجربة من الحساب الذي اعتمده المستخدم" :
        "الحالة: حُفظ بعد ظهور رسالة نجاح الحجز"
    ].join("\r\n");
    const choice = await options();
    return chrome.downloads.download({
      url: "data:text/plain;charset=utf-8," + encodeURIComponent("\uFEFF" + content),
      filename: `${folderName(choice.folder)}/${baseName(name,time,choice.filenamePattern)}${trial ? "_تجربة" : ""}_بيانات_الحساب.txt`,
      conflictAction: "uniquify", saveAs: choice.saveAs
    });
  }
  async function saveImage(tabId, name, time, trial = false) {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active || !siteUrl(tab.url)) {
      throw new Error("صفحة الحجز ليست علامة التبويب النشطة؛ افتحها لالتقاط صورة الإثبات.");
    }
    const image = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    const choice = await options();
    return chrome.downloads.download({
      url: image,
      filename: `${folderName(choice.folder)}/${baseName(name,time,choice.filenamePattern)}${trial ? "_تجربة" : ""}_صورة.png`,
      conflictAction: "uniquify", saveAs: choice.saveAs
    });
  }
  function selectedAccount(current, ibans = [], requestId = "") {
    const disclosed = [...new Set(ibans.filter(iban => /^LY\d{23}$/.test(iban)))];
    if (disclosed.length > 1) return null;
    const matchedIban = requestId && current.accountsById?.[requestId];
    if (matchedIban) {
      if (disclosed.length && disclosed[0] !== matchedIban) return null;
      return current.accounts[matchedIban] || null;
    }
    if (requestId) {
      return disclosed.length ? current.accounts[disclosed[0]] || null : null;
    }
    if (disclosed.length === 1) {
      if (current.selectedIban && current.selectedIban !== disclosed[0]) return null;
      return current.accounts[disclosed[0]] || null;
    }
    return current.accounts[current.selectedIban] || null;
  }

  async function exportOnSuccess(tabId, visibleIban) {
    const accepted = await serial(async () => {
      const current = await state();
      if (!current.pending || current.pending.tabId !== tabId ||
          Date.now() - current.pending.at > PENDING_LIFETIME || current.pending.consumed) {
        return null;
      }
      current.pending.consumed = true; // Reject duplicate MutationObserver events.
      await put(current);
      return current;
    });
    if (!accepted) return { ok: false, error: "لا توجد محاولة تأكيد حديثة لهذه الصفحة." };

    const choice = await options();
    const time = stamp();
    const name = accepted.name;
    const requestIban = accepted.pending.requestIban;
    const tab = await chrome.tabs.get(tabId);
    const account = selectedAccount(accepted, [requestIban, visibleIban], requestAccountId(tab.url));
    const messages = [];
    if (choice.autoImage) {
      try { await saveImage(tabId, name, time); messages.push("بدأ تنزيل صورة النجاح"); }
      catch (error) { messages.push(`تعذرت الصورة: ${error.message}`); }
    }
    if (choice.autoText) {
      if (account && name) {
        try { await saveText(name, account, time); messages.push("بدأ تنزيل ملف TXT"); }
        catch (error) { messages.push(`تعذر الملف النصي: ${error.message}`); }
      } else {
        messages.push("لم يُحفظ ملف TXT: الاسم أو الحساب المرتبط بالطلب غير مؤكد");
      }
    }
    await serial(async () => {
      const latest = await state();
      latest.lastExport = messages.join(" — ") || "خيارات الحفظ التلقائي معطلة";
      latest.pending = null;
      await put(latest);
    });
    const stored = await chrome.storage.local.get([HISTORY_KEY, "cblTrialUiOptions"]);
    if (stored.cblTrialUiOptions?.historyEnabled !== false) {
      const history = Array.isArray(stored[HISTORY_KEY]) ? stored[HISTORY_KEY] : [];
      history.unshift({ at: time, name: name || "", bank: account?.bank || "",
        image: messages.some(item => item.includes("صورة النجاح")),
        text: messages.some(item => item.includes("ملف TXT")) });
      await chrome.storage.local.set({ [HISTORY_KEY]: history.slice(0, 20) });
    }
    if (choice.notifySaved && chrome.notifications?.create) {
      await chrome.notifications.create(`cbl-evidence-${Date.now()}`, {
        type: "basic", iconUrl: chrome.runtime.getURL("icons/icon128.png"),
        title: "حفظ إثبات الحجز", message: messages.join(" — ") || "اكتمل الحجز.", priority: 1
      }).catch(() => {});
    }
    // A confirmed page message is the only event that marks a booking successful.
    const booking = await chrome.storage.local.get(["bookingSettings", "bookingRuntime"]);
    if (!booking.bookingRuntime?.ownerTabId || booking.bookingRuntime.ownerTabId === tabId) {
      await chrome.storage.local.set({
        bookingSettings: {...booking.bookingSettings, enabled:false},
        bookingRuntime: {...booking.bookingRuntime, phase:"success",
          message:"تم تأكيد الحجز — يرجى التوجه إلى الفرع.",
          ownerTabId:null, nextRefreshAt:null, updatedAt:Date.now()}
      });
      await chrome.action.setBadgeBackgroundColor({color:"#15803d"});
      await chrome.action.setBadgeText({text:"✓"});
    }
    return { ok: true, message: messages.join(" — ") };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (typeof message?.type !== "string" || !message.type.startsWith("EVIDENCE_")) return false;
    (async () => {
      const pageEvent = ["EVIDENCE_PROFILE_FOUND", "EVIDENCE_ACCOUNT_FOUND",
        "EVIDENCE_ARM", "EVIDENCE_PENDING_STATUS", "EVIDENCE_SUCCESS"].includes(message.type);
      if (pageEvent && (!sender.tab || !siteUrl(sender.tab.url))) {
        throw new Error("الصفحة ليست من منصة الحجز.");
      }
      switch (message.type) {
        case "EVIDENCE_PROFILE_FOUND": {
          const name = String(message.name || "").trim().slice(0, 100);
          if (!name || /\d/.test(name)) throw new Error("اسم غير صالح.");
          await serial(async () => { const s = await state(); s.name = name; await put(s); });
          return { ok: true };
        }
        case "EVIDENCE_ACCOUNT_FOUND": {
          const account = inputAccount(message.account);
          if (!account) throw new Error("بيانات الحساب غير مكتملة.");
          await serial(async () => {
            const s = await state(); s.accounts[account.iban] = account;
            const id = accountId(message.accountId);
            if (id) s.accountsById[id] = account.iban;
            await put(s);
          });
          return { ok: true };
        }
        case "EVIDENCE_SELECT_ACCOUNT": {
          const tab = await chrome.tabs.get(message.tabId);
          if (!siteUrl(tab.url) || !tab.active) throw new Error("افتح تفاصيل الحساب في علامة التبويب النشطة.");
          const path = new URL(tab.url).pathname;
          if (path.includes("/purchase-requests/")) throw new Error("افتح تفاصيل الحساب من حساباتي الشخصية أولًا.");
          const account = inputAccount(message.account);
          if (!account) throw new Error("لم تظهر حقول الحساب كاملة في هذه الصفحة.");
          const id = requestAccountId(tab.url);
          if (!id || id !== accountId(message.accountId)) throw new Error("تعذر ربط الحساب بصفحة تفاصيله.");
          await serial(async () => {
            const s = await state();
            s.accounts[account.iban] = account;
            if (id) s.accountsById[id] = account.iban;
            if (message.name && !s.name) s.name = String(message.name).trim().slice(0, 100);
            s.selectedIban = account.iban;
            await put(s);
          });
          return { ok: true, bank: account.bank, lastFour: account.iban.slice(-4) };
        }
        case "EVIDENCE_ARM": {
          await serial(async () => {
            const s = await state();
            s.pending = { tabId: sender.tab.id, at: Date.now(), consumed: false,
              requestIban: /^LY\d{23}$/.test(message.requestIban) ? message.requestIban : "" };
            await put(s);
          });
          return { ok: true };
        }
        case "EVIDENCE_PENDING_STATUS": {
          const s = await state();
          return { ok: true, pending: !!s.pending && !s.pending.consumed &&
            s.pending.tabId === sender.tab.id && Date.now() - s.pending.at < PENDING_LIFETIME };
        }
        case "EVIDENCE_SUCCESS":
          return exportOnSuccess(sender.tab.id, String(message.visibleIban || ""));
        case "EVIDENCE_GET_STATUS": {
          const s = await state();
          const choice = await options();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          const account = selectedAccount(s, [], id);
          return { ok: true, options: choice, name: s.name,
            bank: account?.bank || "", lastFour: account?.iban.slice(-4) || "",
            lastExport: s.lastExport };
        }
        case "EVIDENCE_GET_ACCOUNT": {
          const s = await state();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          return { ok: true, name: s.name,
            account: selectedAccount(s, [], id),
            requestAccountUnknown: !!id && !s.accountsById?.[id] };
        }
        case "EVIDENCE_GET_HISTORY": {
          const stored = await chrome.storage.local.get(HISTORY_KEY);
          return { ok: true, history: stored[HISTORY_KEY] || [] };
        }
        case "EVIDENCE_SET_OPTIONS": {
          const choice = { autoImage: !!message.autoImage, autoText: !!message.autoText,
            folder: folderName(message.folder),
            filenamePattern: String(message.filenamePattern || "{name}_{date}_{time}").slice(0,100),
            saveAs: !!message.saveAs,
            notifySaved: !!message.notifySaved };
          await chrome.storage.local.set({ [OPTIONS_KEY]: choice });
          return { ok: true, options: choice };
        }
        case "EVIDENCE_EXPORT_TEXT": {
          const s = await state();
          const tab = Number.isInteger(message.tabId) ? await chrome.tabs.get(message.tabId) : null;
          const id = tab && siteUrl(tab.url) ? requestAccountId(tab.url) : "";
          await saveText(s.name, selectedAccount(s, [], id), stamp(), true);
          return { ok: true, message: "بدأ تنزيل ملف TXT التجريبي." };
        }
        case "EVIDENCE_TEST_IMAGE": {
          const s = await state();
          await saveImage(message.tabId, s.name, stamp(), true);
          return { ok: true, message: "بدأ تنزيل صورة الصفحة التجريبية." };
        }
        default: return { ok: false, error: "رسالة غير معروفة." };
      }
    })().then(sendResponse).catch(error => sendResponse({
      ok: false, error: String(error?.message || error)
    }));
    return true;
  });
})();
