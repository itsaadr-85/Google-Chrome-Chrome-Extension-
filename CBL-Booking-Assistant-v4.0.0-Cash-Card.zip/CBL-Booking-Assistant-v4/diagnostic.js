"use strict";

(() => {

  const STORAGE_KEY = "cblDiagnosticLog";

  const MAX_ENTRIES = 500;

  const MAX_BYTES = 250 * 1024;


  function sanitize(
    value,
    depth = 0
  ) {

    if (
      value == null
    ) {
      return value;
    }


    if (
      depth > 6
    ) {
      return "[MAX_DEPTH]";
    }


    if (
      typeof value ===
      "string"
    ) {

      return value
        .replace(
          /([?&](?:signature|token|csrf|cf-turnstile-response)=)[^&\s]+/gi,
          "$1[REDACTED]"
        )
        .replace(
          /(cookie|authorization|x-csrf-token)\s*[:=]\s*[^\s,;]+/gi,
          "$1=[REDACTED]"
        )
        .replace(
          /(password|passwd)\s*[:=]\s*[^\s,;]+/gi,
          "$1=[REDACTED]"
        )
        .slice(
          0,
          1200
        );
    }


    if (
      Array.isArray(
        value
      )
    ) {

      return value
        .slice(
          0,
          40
        )
        .map(
          item =>
            sanitize(
              item,
              depth + 1
            )
        );
    }


    if (
      typeof value ===
      "object"
    ) {

      const result = {};

      const entries = Object.entries(
          value
        )
        .slice(
          0,
          60
        );


      for (
        const [key, item]
        of entries
      ) {

        if (
          /cookie|password|passwd|csrf|turnstile|signature|authorization|session|auth|secret/i
            .test(
              key
            )
        ) {

          result[key] = "[REDACTED]";

        } else {

          result[key] = sanitize(
              item,
              depth + 1
            );
        }
      }


      return result;
    }


    if (
      typeof value ===
      "number" ||
      typeof value ===
      "boolean"
    ) {
      return value;
    }


    return String(value)
      .slice(
        0,
        500
      );
  }


  function byteLength(
    value
  ) {

    try {

      return new TextEncoder()
        .encode(
          JSON.stringify(
            value
          )
        )
        .byteLength;

    } catch {

      return JSON.stringify(
        value
      ).length;
    }
  }


  function trimEntries(
    entries
  ) {

    let output = Array.isArray(
        entries
      )
        ? entries.slice(
            -MAX_ENTRIES
          )
        : [];


    while (
      output.length > 1 &&
      byteLength(
        output
      ) >
      MAX_BYTES
    ) {

      const removeCount = Math.max(
          1,
          Math.ceil(
            output.length *
            0.08
          )
        );


      output.splice(
        0,
        removeCount
      );
    }


    return output;
  }


  class DiagnosticLogger {

    constructor(
      enabled = false
    ) {

      this.enabled = Boolean(
          enabled
        );

      this.entries = [];

      this.flushTimer = null;
    }


    setEnabled(
      value
    ) {

      this.enabled = Boolean(
          value
        );
    }


    async load() {

      try {

        const stored = await chrome.storage.local
            .get(
              STORAGE_KEY
            );


        this.entries = trimEntries(
            stored[
              STORAGE_KEY
            ]
          );

      } catch {

        this.entries = [];
      }
    }


    log(
      category,
      message,
      data = null
    ) {

      if (
        !this.enabled
      ) {
        return;
      }


      this.entries.push({

        time:
          new Date()
            .toISOString(),

        ts:
          Date.now(),

        category:
          sanitize(
            String(
              category ||
              "INFO"
            )
          ),

        message:
          sanitize(
            String(
              message ||
              ""
            )
          ),

        data:
          sanitize(
            data
          )
      });


      this.entries = trimEntries(
          this.entries
        );


      clearTimeout(
        this.flushTimer
      );


      this.flushTimer = setTimeout(
          () => {

            this.flush()
              .catch(
                () => {}
              );

          },
          100
        );
    }


    async flush() {

      if (
        !this.enabled
      ) {
        return;
      }


      this.entries = trimEntries(
          this.entries
        );


      await chrome.storage.local
        .set({

          [STORAGE_KEY]:
            this.entries
        });
    }


    async clear() {

      clearTimeout(
        this.flushTimer
      );


      this.entries = [];


      await chrome.storage.local
        .set({

          [STORAGE_KEY]:
            []
        });
    }
  }


  globalThis.CBLDiagnostic = Object.freeze({

      DiagnosticLogger,

      STORAGE_KEY,

      MAX_ENTRIES,

      MAX_BYTES
    });

})();
