"use strict";
(() => {
  const $ = selector => document.querySelector(selector);
  const T = CBLTrial;
  let settings = {}, ui = {}, evidence = {}, catalog = [];
  const status = text => { $("#settingsStatus").textContent = text; };
  const send = async message => {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || "تعذر الحفظ.");
    return response;
  };
  const parse = element => {
    if (element.type === "checkbox") return element.checked;
    if (element.type === "number" || element.type === "range") return Number(element.value);
    return element.value;
  };
  async function protect(work) {
    try { await work(); status("تم حفظ الإعداد."); }
    catch(error) { status(String(error?.message || error)); }
  }
  function render() {
    ui = {...T.defaults,...ui,show:{...T.defaults.show,...(ui.show || {})}};
    T.applyTheme(ui);
    for (const button of document.querySelectorAll("[data-theme-choice]"))
      button.setAttribute("aria-pressed",String(ui.theme === button.dataset.themeChoice));
    for (const element of document.querySelectorAll("[data-setting]")) {
      const value = settings[element.dataset.setting];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const row of document.querySelectorAll("[data-cash-only]")) row.hidden = settings.bookingMode === "card";
    const branchInterval = document.querySelector('[data-setting="branchRefreshSeconds"]');
    if (branchInterval) branchInterval.disabled = settings.waitForTargetBranch === false;
    for (const element of document.querySelectorAll("[data-ui]")) {
      const value = ui[element.dataset.ui];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const element of document.querySelectorAll("[data-evidence]")) {
      const value = evidence[element.dataset.evidence];
      if (element.type === "checkbox") element.checked = value === true;
      else if (value != null) element.value = value;
    }
    for (const element of document.querySelectorAll("[data-show]"))
      element.checked = ui.show?.[element.dataset.show] !== false;
    renderOrder();
  }
  function renderOrder() {
    const names={company:"استراتيجية الشركة",branch:"الفرع المطلوب",refresh:"تحديث الصفحة",live:"LIVE",phase:"المرحلة الحالية"};
    const list=$("#cardOrderList");list.replaceChildren();
    const order=Array.isArray(ui.cardOrder) ? ui.cardOrder : T.defaults.cardOrder;
    for (const [index,key] of order.entries()) {
      if (!names[key]) continue;
      const row=document.createElement("div");row.className="order-item";
      const label=document.createElement("span");label.textContent=names[key];row.append(label);
      for (const [symbol,shift] of [["↑",-1],["↓",1]]) {
        const button=document.createElement("button");button.type="button";button.textContent=symbol;
        button.setAttribute("aria-label",`${shift<0?"رفع":"خفض"} ${names[key]}`);
        button.disabled=index+shift<0 || index+shift>=order.length;
        button.addEventListener("click",()=>protect(async()=>{
          const next=[...order];[next[index],next[index+shift]]=[next[index+shift],next[index]];
          ui=await T.saveUi({cardOrder:next});render();
        }));
        row.append(button);
      }
      list.append(row);
    }
  }
  function branches() {
    const select = $("#settingsBranch");
    select.replaceChildren();
    for (const item of [...catalog].sort((a,b)=>Number(a.order)-Number(b.order))) {
      const option=document.createElement("option");option.value=item.id;option.textContent=item.name;
      select.append(option);
    }
  }
  for (const button of document.querySelectorAll("[data-theme-choice]")) button.addEventListener("click",() => protect(async () => {
    ui = await T.saveUi({theme:button.dataset.themeChoice});render();
  }));
  for (const element of document.querySelectorAll("[data-setting]")) element.addEventListener("change",() => protect(async () => {
    const key=element.dataset.setting;
    let value=parse(element);
    if (["refreshSeconds","branchRefreshSeconds"].includes(key)) value=T.number(value,2,.5,30);
    if (key==="notificationDuration") value=T.number(value,5,.1,30);
    if (key==="notificationOpacity") value=T.number(value,88,20,100);
    if (key==="companySkipCount") value=Math.floor(T.number(value,5,0,20));
    if (key==="companyResponseSeconds") value=Math.floor(T.number(value,8,3,30));
    if (key==="companyAttempts") value=Math.floor(T.number(value,2,1,3));
    settings=await T.saveSettings({[key]:value});render();
  }));
  for (const element of document.querySelectorAll("[data-ui]")) element.addEventListener("change",() => protect(async () => {
    const key=element.dataset.ui;
    ui=await T.saveUi(key==="timerAnchor" ? {[key]:parse(element),timerMoved:false} : {[key]:parse(element)});
    render();
  }));
  for (const element of document.querySelectorAll("[data-show]")) element.addEventListener("change",() => protect(async () => {
    ui=await T.saveUi({show:{[element.dataset.show]:element.checked}});render();
  }));
  async function saveEvidence() {
    const value = {};
    for (const element of document.querySelectorAll("[data-evidence]")) value[element.dataset.evidence]=parse(element);
    evidence=(await send({type:"EVIDENCE_SET_OPTIONS",...value})).options;render();
  }
  for (const element of document.querySelectorAll("[data-evidence]"))
    element.addEventListener("change",() => protect(saveEvidence));
  $("#resetTimer").addEventListener("click",() => protect(async () => {
    ui=await T.saveUi({timerAnchor:"center",timerX:.5,timerY:.5,
      timerWidth:145,timerHeight:145,timerSize:120,timerMoved:false});render();
  }));
  $("#resetLayout").addEventListener("click",() => protect(async () => {
    ui=await T.saveUi({show:{...T.defaults.show},layout:"standard",cardOrder:[...T.defaults.cardOrder]});render();
  }));
  $("#soundPreview").addEventListener("click",() => protect(async () => {
    await send({type:"PREVIEW_SOUND",tone:settings.soundTone || "bell"});
  }));
  $("#openShortcuts").addEventListener("click",() =>
    chrome.tabs.create({url:"chrome://extensions/shortcuts"}).catch(error => status(String(error))));
  $("#openOriginalSettings").addEventListener("click",() =>
    chrome.tabs.create({url:chrome.runtime.getURL("settings.html")}).catch(error => status(String(error))));
  async function load() {
    const [state,uiOptions,ev]=await Promise.all([T.state(),T.ui(),send({type:"EVIDENCE_GET_STATUS"})]);
    settings=state.settings;catalog=state.catalog;ui=uiOptions;evidence=ev.options;
    branches();render();
  }
  load().catch(error=>status(String(error?.message || error)));
})();
