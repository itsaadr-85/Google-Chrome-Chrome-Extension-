"use strict";
(() => {
  const $ = selector => document.querySelector(selector);
  const T = CBLTrial;
  const BranchPriority = CBLBranchPriority;
  let settings = {}, runtime = {}, catalog = [], ui = {}, evidence = {}, actionPending = false;
  let browserBounds=null;
  function fitPopup() {
    const preferred=ui.popupWidth || T.layoutWidths[ui.layout] || 360;
    const width=ui.autoFitPopup !== false && browserBounds?.width ? Math.min(preferred,Math.max(240,Math.min(browserBounds.width*.65,browserBounds.width-24))) : preferred;
    const height=ui.autoFitPopup !== false && browserBounds?.height ? Math.max(180,Math.min(600,browserBounds.height-100)) : 600;
    document.documentElement.style.setProperty("--popup-width",`${Math.floor(width)}px`);
    document.documentElement.style.setProperty("--popup-max-height",`${Math.floor(height)}px`);
  }
  async function readBrowserBounds() {
    try { browserBounds=await chrome.windows?.getCurrent?.();fitPopup(); } catch {}
  }
  chrome.windows?.onBoundsChanged?.addListener(window=>{
    if (browserBounds?.id === window.id) {browserBounds=window;fitPopup();}
  });
  const activePhases = new Set(["running","opening","company","branch","branch_wait","confirm"]);
  const circularNames = Object.keys(T.circularPresets);
  const nextCircularPreset = () => circularNames[(circularNames.indexOf(ui.theme) + 1) % circularNames.length];
  const sessionActive = () => !!settings.enabled || ["confirm_pending","cooldown"].includes(runtime.phase);
  const message = value => { $("#notice").textContent = value; $("#notice").hidden = !value; if(value) $(".session-status").hidden=false; };
  const send = async body => {
    const result = await chrome.runtime.sendMessage(body);
    if (!result?.ok) throw new Error(result?.error || "تعذر تنفيذ الطلب.");
    return result;
  };

  function render() {
    ui = {...T.defaults,...ui,show:{...T.defaults.show,...(ui.show || {})}};
    branches();
    T.applyTheme(ui);
    fitPopup();
    const card = settings.bookingMode === "card";
    for (const button of document.querySelectorAll("[data-booking-mode]"))
      button.setAttribute("aria-pressed", String(button.dataset.bookingMode === (card ? "card" : "cash")));
    $("#autoConfirm").checked = settings.autoConfirm !== false;
    $("#diagnosticsEnabled").checked = settings.diagnosticsEnabled === true;
    const running = !!settings.enabled && activePhases.has(runtime.phase);
    const pending = runtime.phase === "confirm_pending";
    const active = sessionActive();
    const circular = ui.interfaceStyle === "circular";
    for (const button of document.querySelectorAll("[data-booking-mode]")) button.disabled = actionPending || pending;
    const mode = runtime.phase === "manual" ? "manual" : active ? "auto" : "stop";
    $("#modeBadge").textContent = mode === "manual" ? "تحكم يدوي" : active ? "المراقبة نشطة" : "متوقف";
    $("#modeBadge").className = `mode-badge ${mode}`;
    $("#powerButton").classList.toggle("running",active);
    $("#powerButton").disabled = actionPending;
    $("#stopButton").disabled = actionPending || (!settings.enabled && (!runtime.phase || runtime.phase === "idle"));
    $("#powerLabel").textContent = actionPending ? "جارٍ التنفيذ" : active ? "إيقاف" : "تشغيل";
    const powerAction = active ? "إيقاف المراقبة" : "بدء تشغيل المراقبة";
    $("#powerButton").setAttribute("aria-label",powerAction);
    $("#powerButton").setAttribute("aria-pressed",String(active));
    $("#powerButton").title = powerAction;
    const phaseNames = {success:"نجاح ✓",confirm_pending:"بانتظار النتيجة",branch_selected:"الاختيار مكتمل",
      manual:"يدوي",cooldown:"انتظار الاستئناف",error:"مشكلة",opening:"فتح القائمة",company:"اختيار الشركة",
      branch:"اختيار الفرع",branch_wait:"انتظار الفرع",confirm:"التحقق والتأكيد"};
    $("#phaseBadge").textContent = phaseNames[runtime.phase] || (running ? "يعمل" : "جاهز");
    $(".session-status").dataset.state = runtime.errorCode || runtime.phase === "error" ? "error" : runtime.phase || "idle";
    const nextTheme = ["ios-light","light","sand","pearl","glacier"].includes(ui.theme) ? "ios-dark" : "ios-light";
    const themeLabel = circular ? `المظهر التالي: ${T.circularPresets[nextCircularPreset()]}` :
      nextTheme === "ios-dark" ? "التبديل إلى المظهر الداكن" : "التبديل إلى المظهر الفاتح";
    $("#themeToggle").title = themeLabel;
    $("#themeToggle").setAttribute("aria-label",themeLabel);
    $("#themeToggle use").setAttribute("href",circular ? "#ui-refresh" : "#ui-appearance");
    $("#appearanceLabel").textContent = circular ? (T.circularPresets[ui.theme]?.split(" ")[0] || "دائري") : T.interfaces[ui.interfaceStyle] || "دائري";
    $("#appearanceOpen").title = "اختيار شكل الواجهة وحجمها";
    $("#popupSize").value = ui.layout;
    $("#popupWidth").value=ui.popupWidth || T.layoutWidths[ui.layout];
    $("#popupWidthValue").textContent=`${ui.popupWidth || T.layoutWidths[ui.layout]} بكسل`;
    $("#popupDensity").value=ui.density;
    $("#autoFitPopup").checked=ui.autoFitPopup !== false;
    $("#restoreAppearance").disabled=!ui.previousAppearance;
    for (const element of document.querySelectorAll("[data-popup-show]")) element.checked=ui.show[element.dataset.popupShow] !== false;
    const muted=T.alertsMuted(settings);
    $("#muteAlerts").setAttribute("aria-pressed",String(muted));
    $("#muteAlerts").title=$("#muteAlerts").ariaLabel=muted ? "استعادة التنبيهات والأصوات" : "كتم جميع التنبيهات والأصوات";
    $("#muteAlerts use").setAttribute("href",muted ? "#ui-bell-off" : "#ui-bell");
    for (const button of document.querySelectorAll("[data-interface-choice]"))
      button.setAttribute("aria-pressed",String(button.dataset.interfaceChoice === ui.interfaceStyle));
    for (const button of document.querySelectorAll("[data-circular-preset]"))
      button.setAttribute("aria-pressed",String(button.dataset.circularPreset === ui.theme));
    $("#phaseText").textContent = runtime.message || "جاهز للتشغيل";
    $("#companyMode").value = settings.companyMode || "first_available";
    $("#branchSelect").value = BranchPriority.normalize(settings).selectedBranchId;
    $("#companyMode").title = $("#companyMode").selectedOptions[0]?.textContent || "طريقة اختيار الشركة";
    $("#branchSelect").title = $("#branchSelect").selectedOptions[0]?.textContent || "الفرع المطلوب";
    const priority=BranchPriority.normalize(settings);
    const names=priority.orderedIds.map(id=>catalog.find(item=>item.id===id)?.name || id);
    const summary=names.length > 1 ? `أولوية الفروع: ${names.join(" ← ")}` : names[0] || "الفرع المطلوب";
    $("[data-card=branch]").title=summary;
    $("#branchSelect").setAttribute("aria-description",summary);
    $("#refreshSeconds").value = settings.refreshSeconds ?? 5;
    $("#liveEnabled").checked = !!ui.timerEnabled;
    const importantPhase=["error","cooldown","confirm_pending","success"].includes(runtime.phase) || !!runtime.errorCode;
    for (const element of document.querySelectorAll("[data-visible]")) element.hidden=ui.show[element.dataset.visible] === false;
    $(".session-status").hidden=ui.show.phase === false && !importantPhase && $("#notice").hidden;
    for (const row of document.querySelectorAll("[data-card]")) {
      row.hidden = (ui.show?.[row.dataset.card] === false && !(row.dataset.card === "phase" && importantPhase)) || (card && row.dataset.card === "branch");
      row.style.order = String((ui.cardOrder || T.defaults.cardOrder).indexOf(row.dataset.card) + 1);
    }
    for (const button of document.querySelectorAll("[data-panel]")) button.hidden = ui.show?.[button.dataset.panel] === false;
    tick();
  }
  function tick() {
    const element = $("#liveValue");
    if (!ui.timerEnabled) { element.textContent = "متوقف"; return; }
    const upward = ui.timerDirection === "up";
    const start = Number(runtime.startedAt);
    const next = Number(runtime.nextRefreshAt);
    const seconds = upward ? (start ? Math.max(0,(Date.now()-start)/1000) : 0) :
      (next ? Math.max(0,(next-Date.now())/1000) : 0);
    element.textContent = (upward || next) ? `${seconds.toFixed(ui.timerDecimals ? 1 : 0)}s` : "—";
  }
  function branches() {
    const select = $("#branchSelect");
    const selectedBranchId=BranchPriority.normalize(settings).selectedBranchId;
    select.replaceChildren();
    const seen=new Set();
    const items = catalog.filter(item => item?.id && !seen.has(item.id) && seen.add(item.id))
      .filter(item => !item.hidden || item.id === selectedBranchId)
      .sort((a,b) => (b.favorite === true) - (a.favorite === true) || Number(a.order)-Number(b.order));
    for (const item of items) {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.name;
      select.append(option);
    }
    if (!items.some(item=>item.id===selectedBranchId)) {
      const option=document.createElement("option");option.value=selectedBranchId;
      option.textContent=`فرع محفوظ غير متاح في القائمة (${selectedBranchId})`;select.append(option);
    }
  }
  async function start() {
    if (sessionActive()) return;
    if (settings.companyMode === "specific" && !String(settings.companyName || "").trim()) {
      throw new Error("اختر الشركة المحددة في الإعدادات أولًا.");
    }
    const tab = await T.platformTab();
    const result = await send({type:"START_SESSION",tabId:tab.id,settings});
    settings = result.settings; runtime = result.runtime;
    try { await T.deliver(tab.id,{type:"START_BOOKING_ASSISTANT"}); }
    catch { await send({type:"STOP_SESSION"}); throw new Error("تعذر الاتصال بصفحة المنصة. أعد تحميل الصفحة وحاول مجددًا."); }
    render();
  }
  async function stop() {
    await send({type:"STOP_SESSION"});
    settings.enabled = false; runtime.phase = "idle"; runtime.message = "تم الإيقاف يدويًا.";
    render();
  }
  async function updateSetting(key,value) {
    const patch={[key]:value};
    if (key === "selectedBranchId") {
      const priority=BranchPriority.normalize({...settings,selectedBranchId:value});
      patch.selectedBranchId=priority.selectedBranchId;
      patch.alternateBranchIds=priority.alternateBranchIds;
    }
    settings = {...settings,...await T.saveSettings(patch)};
    render();
  }
  async function updateUi(patch) {
    ui = await T.saveUi(patch); render();
  }
  async function run(task) { try { await task(); } catch(error) { message(String(error?.message || error)); } }
  async function sessionAction(task) {
    if (actionPending) return;
    actionPending = true; message(""); render();
    try { await task(); } catch(error) { message(String(error?.message || error)); }
    finally { actionPending = false; render(); }
  }

  $("#powerButton").addEventListener("click",() => sessionAction(
    sessionActive() ? stop : start));
  $("#stopButton").addEventListener("click",() => sessionAction(stop));
  $("#themeToggle").addEventListener("click",() => run(() => updateUi({theme:ui.interfaceStyle === "circular" ? nextCircularPreset() :
    ["ios-light","light","sand","pearl","glacier"].includes(ui.theme) ? "ios-dark" : "ios-light"})));
  function closeAppearance(returnFocus=false) {
    $("#appearanceMenu").hidden = true;
    $("#appearanceOpen").setAttribute("aria-expanded","false");
    $("#customizeOpen").setAttribute("aria-expanded","false");
    if (returnFocus) $("#appearanceOpen").focus();
  }
  function toggleAppearance() {
    const menu = $("#appearanceMenu");
    menu.hidden = !menu.hidden;
    $("#appearanceOpen").setAttribute("aria-expanded",String(!menu.hidden));
    $("#customizeOpen").setAttribute("aria-expanded",String(!menu.hidden));
    if (!menu.hidden) (menu.querySelector('.circular-preset-options [aria-pressed="true"]') ||
      menu.querySelector('[aria-pressed="true"]') || menu.querySelector("[data-circular-preset]"))?.focus();
  }
  $("#appearanceOpen").addEventListener("click",toggleAppearance);
  $("#customizeOpen").addEventListener("click",toggleAppearance);
  $("#appearanceClose").addEventListener("click",()=>closeAppearance(true));
  document.addEventListener("keydown",event=>{
    if (event.key === "Escape" && !$("#appearanceMenu").hidden) {event.preventDefault();closeAppearance(true);}
  });
  document.addEventListener("click",event=>{
    if (!$("#appearanceMenu").hidden && !event.target.closest("#appearanceMenu,#appearanceOpen,#customizeOpen")) closeAppearance();
  });
  for (const button of document.querySelectorAll("[data-interface-choice]")) button.addEventListener("click",()=>run(async()=>{
    await updateUi({interfaceStyle:button.dataset.interfaceChoice});closeAppearance(true);
  }));
  for (const button of document.querySelectorAll("[data-circular-preset]")) button.addEventListener("click",()=>run(async()=>{
    await updateUi({theme:button.dataset.circularPreset});closeAppearance(true);
  }));
  $("#popupSize").addEventListener("change",event=>run(()=>updateUi({layout:event.target.value,popupWidth:0})));
  $("#popupWidth").addEventListener("input",event=>{$("#popupWidthValue").textContent=`${event.target.value} بكسل`;});
  $("#popupWidth").addEventListener("change",event=>run(()=>updateUi({popupWidth:Number(event.target.value)})));
  $("#presetWidth").addEventListener("click",()=>run(()=>updateUi({popupWidth:0})));
  $("#popupDensity").addEventListener("change",event=>run(()=>updateUi({density:event.target.value})));
  $("#autoFitPopup").addEventListener("change",event=>run(()=>updateUi({autoFitPopup:event.target.checked})));
  for (const element of document.querySelectorAll("[data-popup-show]")) element.addEventListener("change",()=>run(()=>updateUi({show:{[element.dataset.popupShow]:element.checked}})));
  $("#popupEssential").addEventListener("click",()=>run(()=>updateUi({show:T.visibilityProfiles.essential})));
  $("#popupShowAll").addEventListener("click",()=>run(()=>updateUi({show:T.visibilityProfiles.all})));
  $("#restoreAppearance").addEventListener("click",()=>run(async()=>{ui=await T.restoreAppearance();render();}));
  $("#muteAlerts").addEventListener("click",()=>run(async()=>{const result=await T.setAlertsMuted(!T.alertsMuted(settings));settings=result.settings;runtime=result.runtime;render();}));
  for (const button of document.querySelectorAll("[data-booking-mode]"))
    button.addEventListener("click", () => run(() => updateSetting("bookingMode",button.dataset.bookingMode)));
  $("#diagnosticsEnabled").addEventListener("change",event=>run(()=>updateSetting("diagnosticsEnabled",event.target.checked)));
  $("#exportDiagnostic").addEventListener("click",()=>run(async()=>{await send({type:"DIAGNOSTIC_EXPORT"});message("اختر مكان حفظ سجل التشخيص، ثم أرفق ملف JSON عند طلب المراجعة.");}));
  $("#autoConfirm").addEventListener("change", event => run(() => updateSetting("autoConfirm",event.target.checked)));
  $("#companyMode").addEventListener("change",event => run(() => updateSetting("companyMode",event.target.value)));
  $("#branchSelect").addEventListener("change",event => run(() => updateSetting("selectedBranchId",event.target.value)));
  $("#refreshSeconds").addEventListener("change",event => run(() =>
    updateSetting("refreshSeconds",T.number(event.target.value,5,.5,30))));
  $("#liveEnabled").addEventListener("change",event => run(() => updateUi({timerEnabled:event.target.checked})));
  $("#settingsOpen").addEventListener("click",() => chrome.runtime.openOptionsPage());
  $("#settingsQuick").addEventListener("click",() => chrome.runtime.openOptionsPage());
  $("#drawerClose").addEventListener("click",() => { $("#drawer").hidden = true; });

  async function showEvidence() {
    const tab = await T.platformTab();
    evidence = await send({type:"EVIDENCE_GET_STATUS",tabId:tab.id});
    $("#drawerTitle").textContent = "التصوير والإثبات";
    $("#drawerBody").innerHTML = `<p id="evidenceSummary"></p><div class="drawer-actions"><button id="chooseAccount">اعتماد الحساب المفتوح</button><button id="textTest">تجربة TXT</button><button id="imageTest">تجربة صورة</button></div><p class="drawer-status" id="evidenceMessage"></p>`;
    const summary = [evidence.name ? `الاسم: ${evidence.name}` : "لم يُقرأ الاسم بعد",
      evidence.bank ? `${evidence.bank} ••••${evidence.lastFour}` : "لم يُعتمد حساب بعد",
      evidence.lastExport || ""].filter(Boolean);
    $("#evidenceSummary").textContent = summary.join(" | ");
    const report = text => { $("#evidenceMessage").textContent = text; };
    $("#chooseAccount").onclick = () => run(async () => {
      const tab = await T.platformTab();
      const data = await T.deliver(tab.id,{type:"EVIDENCE_READ_PAGE"});
      if (!data?.account) throw new Error("افتح تفاصيل حساب واحد ثم اضغط اعتماد.");
      const result = await send({type:"EVIDENCE_SELECT_ACCOUNT",tabId:tab.id,
        account:data.account,accountId:data.accountId,name:data.name});
      report(`تم اعتماد ${result.bank} ••••${result.lastFour}`);
    });
    $("#textTest").onclick = () => run(async () => {
      const tab = await T.platformTab();
      report((await send({type:"EVIDENCE_EXPORT_TEXT",tabId:tab.id})).message);
    });
    $("#imageTest").onclick = () => run(async () => {
      const tab = await T.platformTab(); report((await send({type:"EVIDENCE_TEST_IMAGE",tabId:tab.id})).message);
    });
  }
  async function showBeneficiary() {
    if (ui.beneficiaryEnabled === false) { $("#drawerTitle").textContent="بيانات المستفيد"; $("#drawerBody").textContent="خاصية النسخ متوقفة من الإعدادات."; return; }
    const tab = await T.platformTab();
    const page = await T.deliver(tab.id,{type:"EVIDENCE_READ_PAGE"});
    if (page?.account) {
      await send({type:"EVIDENCE_SELECT_ACCOUNT",tabId:tab.id,
        account:page.account,accountId:page.accountId,name:page.name});
    }
    const data = await send({type:"EVIDENCE_GET_ACCOUNT",tabId:tab.id});
    $("#drawerTitle").textContent = "بيانات المستفيد";
    $("#drawerBody").innerHTML = `<p id="beneficiarySummary"></p><div class="drawer-actions"><button data-copy="name">نسخ الاسم</button><button data-copy="iban">نسخ IBAN</button><button data-copy="accountNumber">نسخ رقم الحساب</button><button data-copy="all">نسخ الكل</button></div><p class="drawer-status" id="copyStatus"></p>`;
    $("#beneficiarySummary").textContent = data.account ?
      `${data.name || "الاسم غير متوفر"} — ${data.account.bank} — IBAN ••••${data.account.iban.slice(-4)}` :
      data.requestAccountUnknown ? "هذا الطلب مرتبط بحساب لم تُقرأ تفاصيله بعد. افتح تفاصيل الحساب المطلوب من حساباتي الشخصية ثم عد للنسخ." :
      "افتح تفاصيل الحساب المطلوب من حساباتي الشخصية ثم عد للنسخ.";
    for (const button of $("#drawerBody").querySelectorAll("[data-copy]")) {
      button.onclick = async () => {
        try {
        await navigator.clipboard.writeText(CBLBeneficiaryCopy.value(data,button.dataset.copy));
        $("#copyStatus").textContent = "تم النسخ إلى الحافظة.";
        } catch(error) { $("#copyStatus").textContent = String(error?.message || error); }
      };
    }
  }
  async function showHistory() {
    if (ui.historyEnabled === false) { $("#drawerTitle").textContent="سجل الحجوزات"; $("#drawerBody").textContent="السجل متوقف من الإعدادات."; return; }
    const data = await send({type:"EVIDENCE_GET_HISTORY"});
    $("#drawerTitle").textContent = "آخر الحجوزات الناجحة";
    $("#drawerBody").replaceChildren();
    const list = document.createElement("ol");
    for (const item of data.history.slice(0,20)) {
      const li = document.createElement("li");
      li.textContent = `${item.at} — ${item.bank || "حساب غير معروف"} — صورة ${item.image ? "✓" : "—"} / TXT ${item.text ? "✓" : "—"}`;
      list.append(li);
    }
    if (!list.children.length) { const p=document.createElement("p"); p.textContent="لا توجد عمليات محفوظة بعد."; $("#drawerBody").append(p); }
    else $("#drawerBody").append(list);
  }
  for (const button of document.querySelectorAll("[data-panel]")) button.addEventListener("click",() => run(async () => {
    $("#drawer").hidden = false;
    if (button.dataset.panel === "evidence") await showEvidence();
    if (button.dataset.panel === "beneficiary") await showBeneficiary();
    if (button.dataset.panel === "history") await showHistory();
  }));
  chrome.storage.onChanged.addListener((changes,area) => {
    if (area !== "local") return;
    if (changes.bookingSettings || changes.bookingRuntime) message("");
    if (changes.bookingSettings) settings = {...settings,...changes.bookingSettings.newValue};
    if (changes.branchCatalog) catalog = changes.branchCatalog.newValue || [];
    if (changes.bookingRuntime) runtime = {...runtime,...changes.bookingRuntime.newValue};
    if (changes[CBLTrial.KEY]) ui = T.normalizeUi(changes[CBLTrial.KEY].newValue);
    render();
  });
  async function load() {
    const [state,uiOptions,ev] = await Promise.all([T.state(),T.ui(),send({type:"EVIDENCE_GET_STATUS"})]);
    settings=state.settings;runtime=state.runtime;catalog=state.catalog;ui=uiOptions;evidence=ev;
    render();
  }
  readBrowserBounds();
  load().catch(error => message(String(error?.message || error)));
  setInterval(tick,100);
})();
