"use strict";
(() => {
  if (window.top !== window || window.__CBL_LIVE_TIMER_TRIAL__) return;
  window.__CBL_LIVE_TIMER_TRIAL__ = true;
  const defaults = {timerEnabled:true,timerDirection:"down",timerDecimals:true,
    timerStyle:"ring",timerAnchor:"center",timerSize:120,timerOpacity:85,
    timerShape:"rounded",timerFont:"rounded",timerAutoFit:true,
    timerX:.5,timerY:.5,timerWidth:145,timerHeight:145,timerMoved:false,performanceMode:true};
  let ui={...defaults}, settings={}, runtime={}, dragging=false;
  let host=null, value=null, readout=null, segments=null, label=null, circle=null;
  let renderedText="",renderedFont="";
  const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
  const KEY="cblTrialUiOptions";
  const MIN_WIDTH=72,MIN_HEIGHT=52,MAX_WIDTH=320,MAX_HEIGHT=300;
  const numeric=(v,fallback)=>Number.isFinite(Number(v)) ? Number(v) : fallback;

  function dimensions() {
    let width=clamp(numeric(ui.timerWidth,145),MIN_WIDTH,MAX_WIDTH);
    let height=clamp(numeric(ui.timerHeight,145),MIN_HEIGHT,MAX_HEIGHT);
    if (ui.timerAutoFit!==false) {
      width=Math.min(width,Math.max(1,innerWidth-8));
      height=Math.min(height,Math.max(1,innerHeight-8));
    }
    return {width,height};
  }
  function fitText() {
    if (!host || !value) return;
    const width=host.offsetWidth,height=host.offsetHeight;
    const shape=host.dataset.shape,side=Math.min(width,height);
    const availableWidth=Math.max(1,shape==="star" ? side*.48 :
      shape==="circle" ? side*.72 : width-(shape==="digits" ? 14 : 22));
    const compact=height<90 || (shape==="circle" || shape==="star") && side<110;
    host.dataset.compact=compact ? "on" : "off";
    let fontSize=clamp(numeric(ui.timerSize,120),40,200)/120*32;
    const availableHeight=Math.max(1,shape==="star" ? side*.32 :
      shape==="digits" ? height-(compact ? 36 : 12) : compact ? height-16 : height-57);
    fontSize=Math.min(fontSize,availableHeight);
    value.style.fontSize=`${fontSize}px`;
    if (value.scrollWidth>availableWidth) {
      fontSize*=availableWidth/value.scrollWidth;
      value.style.fontSize=`${fontSize}px`;
    }
    const renderedHeight=value.getBoundingClientRect().height;
    if (renderedHeight>availableHeight) {
      value.style.fontSize=`${fontSize*availableHeight/renderedHeight}px`;
    }
  }
  function displayTime(text) {
    const font=host.dataset.font;
    if (text!==renderedText || font!==renderedFont) {
      readout.textContent=text;
      value.setAttribute("aria-label",text);
      segments.replaceChildren();
      if (font==="digital") {
        for (const character of text) {
          const digit=document.createElement("span");
          if (/\d/.test(character)) {
            digit.className="digit";digit.dataset.digit=character;
            for (const segment of "abcdefg") {
              const bar=document.createElement("i");bar.className=segment;digit.append(bar);
            }
          } else if (character===".") digit.className="digit-dot";
          else {digit.className="digit-unit";digit.textContent=character;}
          segments.append(digit);
        }
      }
      renderedText=text;renderedFont=font;
      fitText();
    }
  }

  function anchor() {
    const placements={center:[.5,.5],top:[.5,.16],bottom:[.5,.84],right:[.84,.5],left:[.16,.5]};
    return ui.timerMoved ? [ui.timerX,ui.timerY] :
      (placements[ui.timerAnchor] || placements.center);
  }
  function position() {
    if (!host) return;
    const [x,y]=anchor();
    const w=host.offsetWidth || ui.timerWidth;
    const h=host.offsetHeight || ui.timerHeight;
    host.style.left=`${clamp(x*innerWidth-w/2,4,Math.max(4,innerWidth-w-4))}px`;
    host.style.top=`${clamp(y*innerHeight-h/2,4,Math.max(4,innerHeight-h-4))}px`;
  }
  function appearance() {
    if (!host) return;
    host.hidden = !ui.timerEnabled || !settings.enabled ||
      !["running","opening","company","branch","branch_wait","confirm"].includes(runtime.phase);
    const {width,height}=dimensions();
    host.style.width=`${width}px`;
    host.style.height=`${height}px`;
    host.style.setProperty("--timer-shape-size",`${Math.min(width,height)}px`);
    host.style.opacity=String(clamp((Number(ui.timerOpacity)||85)/100,.3,1));
    host.dataset.style=["ring","digital","pill"].includes(ui.timerStyle) ? ui.timerStyle : "ring";
    host.dataset.shape=["rounded","circle","star","digits"].includes(ui.timerShape) ? ui.timerShape : "rounded";
    host.dataset.font=["rounded","mono","digital","classic"].includes(ui.timerFont) ? ui.timerFont : "rounded";
    host.dataset.theme=ui.circularVersion===1 ? String(ui.theme || "obsidian") : "obsidian";
    host.dataset.design=ui.circularVersion!==1 ? "circular" : ui.interfaceStyle ||
      (["obsidian","pearl","royal","glacier"].includes(host.dataset.theme) ? "circular" :
        ["ios-dark","ios-light"].includes(host.dataset.theme) ? "ios" : "classic");
    host.dataset.performance=ui.performanceMode ? "on" : "off";
    position();tick();fitText();
  }
  function tick() {
    if (!host || host.hidden) return;
    const up=ui.timerDirection==="up";
    const start=Number(runtime.startedAt), next=Number(runtime.nextRefreshAt);
    const seconds=up ? (start?Math.max(0,(Date.now()-start)/1000):0) :
      (next?Math.max(0,(next-Date.now())/1000):0);
    displayTime((!up && !next) ? "—" : `${seconds.toFixed(ui.timerDecimals?1:0)}s`);
    label.textContent = up ? "منذ البدء" : next ? "للتحديث" : "بانتظار المرحلة";
    const interval=Math.max(.5,Number(runtime.phase==="branch_wait" ? settings.branchRefreshSeconds : settings.refreshSeconds)||5);
    const fraction=up?Math.min(1,(seconds%interval)/interval):Math.min(1,seconds/interval);
    circle.style.background=`conic-gradient(var(--timer-accent,#28e4ed) ${fraction*100}%,var(--timer-track,rgba(255,255,255,.13)) 0)`;
  }
  async function savePosition(saveSize=false) {
    if (!host) return;
    const rect=host.getBoundingClientRect();
    const next={...ui,timerMoved:true,
      timerX:clamp((rect.left+rect.width/2)/innerWidth,0,1),
      timerY:clamp((rect.top+rect.height/2)/innerHeight,0,1)};
    if (saveSize) {
      next.timerWidth=clamp(Math.round(rect.width),MIN_WIDTH,MAX_WIDTH);
      next.timerHeight=clamp(Math.round(rect.height),MIN_HEIGHT,MAX_HEIGHT);
    }
    ui=next;
    await chrome.storage.local.set({[KEY]:next});
  }
  function mount() {
    if (host || !document.body) return;
    host=document.createElement("div");
    host.id="cbl-live-timer-trial";
    host.style.cssText="position:fixed;z-index:2147483646;pointer-events:none;overflow:hidden;max-width:320px;max-height:300px;box-sizing:border-box;";
    const root=host.attachShadow({mode:"closed"});
    root.innerHTML=`<style>
      :host{--timer-accent:#28e4ed;--timer-track:rgba(255,255,255,.13)}
      *{box-sizing:border-box} .frame{height:100%;width:100%;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;color:#ecfdff;font-family:Arial,Tahoma,sans-serif;background:rgba(3,22,43,.88);border:1px solid #28d6ed;border-radius:24px;box-shadow:0 0 19px rgba(0,213,239,.38)}
      .ring{position:absolute;inset:7px;border-radius:50%;background:conic-gradient(var(--timer-accent) 30%,var(--timer-track) 0);padding:7px}
      .ring::after{content:"";display:block;width:100%;height:100%;border-radius:50%;background:#051b31}
      .inner{position:relative;z-index:1;text-align:center;white-space:nowrap}
      .time{font-weight:800;direction:ltr;line-height:1.1;letter-spacing:.5px}
      .label{font-size:10px;color:#a9daef;margin-top:4px}.live{display:inline-block;padding:2px 6px;border:1px solid #1dd6a0;border-radius:10px;color:#5cf5d0;font-size:9px;margin-top:5px}
      .handle{pointer-events:auto;position:absolute;top:5px;left:6px;z-index:3;cursor:grab;touch-action:none;color:#8feaff;font-size:16px;line-height:1;user-select:none}
      .handle:active{cursor:grabbing}
      .resize-handle{position:absolute;right:5px;bottom:5px;z-index:3;width:15px;height:15px;pointer-events:auto;cursor:nwse-resize;touch-action:none;color:#8feaff;line-height:15px;font-size:14px;user-select:none}
      :host([data-style="digital"]) .ring,:host([data-style="pill"]) .ring{display:none}
      :host([data-style="digital"]) .frame{border-radius:12px}
      :host([data-style="pill"]) .frame{border-radius:80px}
      :host([data-theme="ios-dark"]){--timer-accent:#34dfa4;--timer-track:rgba(125,172,155,.18)}
      :host([data-theme="ios-light"]){--timer-accent:#07875f;--timer-track:rgba(65,124,94,.12)}
      :host([data-theme="ios-dark"]) .frame,:host([data-theme="ios-light"]) .frame{padding:8px;border-radius:26px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,Tahoma,sans-serif}
      :host([data-theme="ios-dark"]) .frame{color:#f4faf9;background:linear-gradient(155deg,rgba(24,58,54,.98),rgba(7,23,25,.98));border:1px solid rgba(94,164,145,.3);box-shadow:0 6px 20px rgba(0,0,0,.19),inset 0 1px rgba(255,255,255,.035)}
      :host([data-theme="ios-light"]) .frame{color:#182b28;background:linear-gradient(155deg,rgba(255,255,255,.98),rgba(244,248,246,.98));border:1px solid #d9e2df;box-shadow:0 5px 20px rgba(37,68,50,.11),inset 0 1px #fff}
      :host([data-theme="ios-dark"]) .ring,:host([data-theme="ios-light"]) .ring{inset:9px;padding:4px}
      :host([data-theme="ios-dark"]) .ring::after{background:#102a29}
      :host([data-theme="ios-light"]) .ring::after{background:#fbfdfc}
      :host([data-theme="ios-dark"]) .time,:host([data-theme="ios-light"]) .time{font-weight:720;letter-spacing:-.8px;font-variant-numeric:tabular-nums}
      :host([data-theme="ios-dark"]) .label,:host([data-theme="ios-light"]) .label{margin-top:5px;line-height:1.35;font-size:10px}
      :host([data-theme="ios-dark"]) .label{color:#9db6b7}
      :host([data-theme="ios-light"]) .label{color:#687d77}
      :host([data-theme="ios-dark"]) .live,:host([data-theme="ios-light"]) .live{margin-top:5px;padding:2px 7px;border:0;border-radius:6px;font-size:8px;font-weight:650;letter-spacing:.5px}
      :host([data-theme="ios-dark"]) .live{color:#34dfa4;background:rgba(36,214,151,.12)}
      :host([data-theme="ios-light"]) .live{color:#07875f;background:#e3f6ed}
      :host([data-theme="ios-dark"]) .handle,:host([data-theme="ios-light"]) .handle{top:6px;left:6px;width:20px;height:20px;line-height:20px;text-align:center;font-size:14px;border-radius:6px}
      :host([data-theme="ios-dark"]) .handle,:host([data-theme="ios-dark"]) .resize-handle{color:#9db6b7}
      :host([data-theme="ios-light"]) .handle,:host([data-theme="ios-light"]) .resize-handle{color:#687d77}
      :host([data-theme="ios-dark"][data-style="digital"]) .frame,:host([data-theme="ios-light"][data-style="digital"]) .frame{border-radius:19px}
      :host([data-theme="ios-dark"][data-style="pill"]) .frame,:host([data-theme="ios-light"][data-style="pill"]) .frame{border-radius:60px}
      :host([data-design="dashboard"]) .frame{border-radius:11px;border-width:2px}
      :host([data-design="dashboard"]) .live{border-radius:4px;font-weight:800;letter-spacing:1px}
      :host([data-design="minimal"]) .frame{border-radius:16px;box-shadow:none;background:none}
      :host([data-design="minimal"][data-theme="ios-light"]) .frame{background:#fff}
      :host([data-design="minimal"][data-theme="ios-dark"]) .frame{background:#071719}
      :host([data-design="minimal"]) .time{font-weight:600;letter-spacing:0}
      :host([data-design="classic"]) .frame{border-radius:8px}
      :host([data-theme="obsidian"]){--timer-accent:#51ead6;--timer-track:#304858;--timer-base:#101d2b;--timer-panel:#182b3b;--timer-text:#f2f8ff;--timer-muted:#8daab8;--timer-border:#304858;--timer-soft-shadow:rgba(49,213,192,.14)}
      :host([data-theme="pearl"]){--timer-accent:#6559e7;--timer-track:#e3e5ef;--timer-base:#fff;--timer-panel:#f1f3fa;--timer-text:#252845;--timer-muted:#7b8197;--timer-border:#e3e5ef;--timer-soft-shadow:rgba(101,89,231,.14)}
      :host([data-theme="royal"]){--timer-accent:#edc779;--timer-track:#31364b;--timer-base:#101322;--timer-panel:#1d2234;--timer-text:#fbf9f2;--timer-muted:#a3a9bd;--timer-border:#31364b;--timer-soft-shadow:rgba(237,199,121,.12)}
      :host([data-theme="glacier"]){--timer-accent:#1294c3;--timer-track:#d3e2eb;--timer-base:#e8f1f6;--timer-panel:#fff;--timer-text:#17354a;--timer-muted:#7d97a4;--timer-border:#d3e2eb;--timer-soft-shadow:rgba(18,148,195,.14)}
      :host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .frame{color:var(--timer-text);background:var(--timer-base);border-color:var(--timer-border);box-shadow:0 4px 16px var(--timer-soft-shadow)}
      :host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .ring::after{background:var(--timer-panel)}
      :host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .label,:host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .handle,:host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .resize-handle{color:var(--timer-muted)}
      :host(:is([data-theme="obsidian"],[data-theme="pearl"],[data-theme="royal"],[data-theme="glacier"])) .live{color:var(--timer-accent);background:var(--timer-panel);border-color:var(--timer-border)}
      :host([data-design="circular"]) .frame{padding:8px;border-radius:25px;border-width:1px;box-shadow:0 4px 16px var(--timer-soft-shadow,rgba(49,213,192,.14))}
      :host([data-design="circular"]) .ring{inset:9px;padding:4px}
      :host([data-design="circular"]) .time{font-weight:750;letter-spacing:-.3px;font-variant-numeric:tabular-nums}
      :host([data-design="circular"]) .label{line-height:1.35;margin-top:5px}
      :host([data-design="circular"]) .live{border-radius:12px;font-weight:650;letter-spacing:.4px;padding:2px 7px}
      :host([data-design="circular"][data-theme="pearl"]) .frame{background:linear-gradient(145deg,#fff,#f1f3fa);box-shadow:4px 5px 13px #b9c0df55,-3px -3px 12px #fff}
      :host([data-design="circular"][data-theme="royal"]) .frame{background:linear-gradient(145deg,#25263a,#101322);border-color:rgba(237,199,121,.32);box-shadow:inset 2px 2px 7px #05060d,inset -1px -1px 5px #59516a44}
      :host([data-design="circular"][data-theme="glacier"]) .frame{background:linear-gradient(145deg,#f5fbfe,#e8f1f6);box-shadow:4px 5px 12px #92b9cc66,-3px -3px 11px #fff}
      :host([data-design="circular"][data-style="digital"]) .frame{border-radius:16px}
      :host([data-design="circular"][data-performance="on"]) .frame{box-shadow:none}
      :host([data-style="pill"]) .frame{border-radius:60px}
      :host([data-performance="on"]) .frame{box-shadow:none}
      /* Shapes and fonts are independent of the theme and content style. */
      *{pointer-events:none}
      .handle,.resize-handle{pointer-events:auto;width:18px;height:18px;line-height:18px;text-align:center}
      .handle{top:5px;left:5px}
      .resize-handle{right:5px;bottom:5px}
      .resize-handle{display:flex;align-items:center;justify-content:center}
      .resize-handle svg{width:12px;height:12px;display:block}
      :host([data-shape]) .frame{border-radius:24px!important}
      :host(:is([data-shape="circle"],[data-shape="star"])) .frame{position:absolute;width:var(--timer-shape-size);height:var(--timer-shape-size);left:50%;top:50%;transform:translate(-50%,-50%);border-radius:50%!important;padding:0}
      :host([data-shape="star"]) .frame{clip-path:polygon(50% 0,62% 34%,98% 35%,70% 57%,79% 92%,50% 72%,21% 92%,30% 57%,2% 35%,38% 34%);border-radius:0!important;border:0;box-shadow:none}
      :host([data-shape="star"]) .ring,:host([data-shape="star"]) .ring::after{clip-path:polygon(50% 0,62% 34%,98% 35%,70% 57%,79% 92%,50% 72%,21% 92%,30% 57%,2% 35%,38% 34%);border-radius:0}
      :host([data-shape="star"]) .ring{inset:4px;padding:5px}
      :host([data-shape="star"]) .inner{transform:translateY(-3%)}
      :host([data-shape="star"]) .label{font-size:8px;margin-top:2px}
      :host([data-shape="star"]) .live{font-size:7px;margin-top:2px;padding:1px 4px}
      :host([data-shape="digits"]) .frame{background:none!important;border:0!important;border-radius:0!important;box-shadow:none!important;padding:0!important;overflow:visible}
      :host([data-shape="digits"]) .ring,:host([data-shape="digits"]) .label,:host([data-shape="digits"]) .live{display:none}
      :host([data-shape="digits"]) .time{color:var(--timer-accent,#28e4ed);text-shadow:0 1px 3px var(--timer-base,rgba(0,0,0,.4));filter:drop-shadow(0 1px 1px var(--timer-base,#101d2b))}
      :host([data-shape="digits"]) .handle,:host([data-shape="digits"]) .resize-handle{background:var(--timer-panel,#152c3a);color:var(--timer-accent,#28e4ed);border:1px solid var(--timer-border,#304858);border-radius:5px;font-size:13px}
      :host([data-shape="digits"][data-compact="on"]) .handle,:host([data-shape="digits"][data-compact="on"]) .resize-handle{width:14px;height:14px;line-height:12px;font-size:10px;border-radius:4px}
      :host([data-shape="digits"][data-compact="on"]) .handle{top:3px;left:3px}
      :host([data-shape="digits"][data-compact="on"]) .resize-handle{bottom:3px;right:3px}
      :host([data-shape="digits"][data-compact="on"]) .resize-handle svg{width:10px;height:10px}
      :host([data-font="rounded"]) .time{font-family:"Arial Rounded MT Bold","Trebuchet MS",Arial,Tahoma,sans-serif;font-weight:800;letter-spacing:0}
      :host([data-font="mono"]) .time{font-family:Consolas,"SFMono-Regular","Courier New",monospace;font-weight:700;letter-spacing:-.3px}
      :host([data-font="classic"]) .time{font-family:Georgia,"Times New Roman",serif;font-weight:700;letter-spacing:0}
      :host([data-font="digital"]) .time{font-family:Consolas,"Courier New",monospace;font-weight:500;letter-spacing:0;line-height:1}
      .time{position:relative;width:max-content;margin:auto;font-variant-numeric:tabular-nums}
      .segments{display:none}
      :host([data-font="digital"]) .readout{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
      :host([data-font="digital"]) .segments{display:inline-flex;align-items:center;gap:.06em;line-height:1}
      .digit{display:inline-block;position:relative;width:.5em;height:.88em}
      .digit i{position:absolute;display:block;background:currentColor;opacity:.1}
      .digit .a,.digit .d,.digit .g{width:76%;height:10%;left:12%;clip-path:polygon(10% 0,90% 0,100% 50%,90% 100%,10% 100%,0 50%)}
      .digit .a{top:0}.digit .g{top:45%}.digit .d{bottom:0}
      .digit .b,.digit .c,.digit .e,.digit .f{width:16%;height:42%;clip-path:polygon(50% 0,100% 12%,100% 88%,50% 100%,0 88%,0 12%)}
      .digit .b{right:0;top:5%}.digit .c{right:0;bottom:5%}.digit .e{left:0;bottom:5%}.digit .f{left:0;top:5%}
      .digit:is([data-digit="0"],[data-digit="2"],[data-digit="3"],[data-digit="5"],[data-digit="6"],[data-digit="7"],[data-digit="8"],[data-digit="9"]) .a,
      .digit:is([data-digit="0"],[data-digit="1"],[data-digit="2"],[data-digit="3"],[data-digit="4"],[data-digit="7"],[data-digit="8"],[data-digit="9"]) .b,
      .digit:is([data-digit="0"],[data-digit="1"],[data-digit="3"],[data-digit="4"],[data-digit="5"],[data-digit="6"],[data-digit="7"],[data-digit="8"],[data-digit="9"]) .c,
      .digit:is([data-digit="0"],[data-digit="2"],[data-digit="3"],[data-digit="5"],[data-digit="6"],[data-digit="8"],[data-digit="9"]) .d,
      .digit:is([data-digit="0"],[data-digit="2"],[data-digit="6"],[data-digit="8"]) .e,
      .digit:is([data-digit="0"],[data-digit="4"],[data-digit="5"],[data-digit="6"],[data-digit="8"],[data-digit="9"]) .f,
      .digit:is([data-digit="2"],[data-digit="3"],[data-digit="4"],[data-digit="5"],[data-digit="6"],[data-digit="8"],[data-digit="9"]) .g{opacity:1}
      .digit-dot{width:.1em;height:.1em;background:currentColor;align-self:flex-end;margin-bottom:.02em;border-radius:2px}
      .digit-unit{font-size:.7em;line-height:1.2}
      :host([data-compact="on"]) .label,:host([data-compact="on"]) .live{display:none}
      :host([data-compact="on"]) .ring{inset:5px;padding:3px}
    </style><div class="frame"><div class="ring"></div><div class="inner"><div class="time" role="timer" aria-live="off"><span class="readout">—</span><span class="segments" aria-hidden="true"></span></div><div class="label">للتحديث</div><span class="live">LIVE</span></div></div><div class="handle" aria-label="اسحب العداد" title="اسحب العداد">✥</div><div class="resize-handle" aria-label="تغيير حجم العداد" title="تغيير حجم العداد"><svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M4 4l8 8M5 12h7V5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`;
    value=root.querySelector(".time");readout=root.querySelector(".readout");segments=root.querySelector(".segments");
    label=root.querySelector(".label");circle=root.querySelector(".ring");
    root.querySelector(".handle").addEventListener("pointerdown",event=>{
      dragging=true;
      const original={x:event.clientX,y:event.clientY,left:host.offsetLeft,top:host.offsetTop};
      const move=e=>{
        host.style.left=`${clamp(original.left+e.clientX-original.x,4,Math.max(4,innerWidth-host.offsetWidth-4))}px`;
        host.style.top=`${clamp(original.top+e.clientY-original.y,4,Math.max(4,innerHeight-host.offsetHeight-4))}px`;
      };
      const end=()=>{dragging=false;window.removeEventListener("pointermove",move);window.removeEventListener("pointerup",end);window.removeEventListener("pointercancel",end);savePosition().catch(()=>{});};
      window.addEventListener("pointermove",move);window.addEventListener("pointerup",end,{once:true});
      window.addEventListener("pointercancel",end,{once:true});
      event.target.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    root.querySelector(".resize-handle").addEventListener("pointerdown",event=>{
      dragging=true;
      const original={x:event.clientX,y:event.clientY,width:host.offsetWidth,height:host.offsetHeight};
      const move=e=>{
        const maxWidth=ui.timerAutoFit!==false ? Math.min(MAX_WIDTH,Math.max(1,innerWidth-8)) : MAX_WIDTH;
        const maxHeight=ui.timerAutoFit!==false ? Math.min(MAX_HEIGHT,Math.max(1,innerHeight-8)) : MAX_HEIGHT;
        const width=clamp(original.width+e.clientX-original.x,Math.min(MIN_WIDTH,maxWidth),maxWidth);
        const height=clamp(original.height+e.clientY-original.y,Math.min(MIN_HEIGHT,maxHeight),maxHeight);
        host.style.width=`${width}px`;host.style.height=`${height}px`;
        host.style.setProperty("--timer-shape-size",`${Math.min(width,height)}px`);
        fitText();position();
      };
      const end=()=>{dragging=false;window.removeEventListener("pointermove",move);window.removeEventListener("pointerup",end);window.removeEventListener("pointercancel",end);savePosition(true).catch(()=>{});};
      window.addEventListener("pointermove",move);window.addEventListener("pointerup",end,{once:true});
      window.addEventListener("pointercancel",end,{once:true});
      event.target.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    document.body.append(host);
    appearance();
  }
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area!=="local") return;
    if (changes[KEY]) ui={...defaults,...changes[KEY].newValue};
    if (changes.bookingSettings) settings=changes.bookingSettings.newValue || {};
    if (changes.bookingRuntime) runtime=changes.bookingRuntime.newValue || {};
    if (!dragging) appearance();
  });
  window.addEventListener("resize",()=>{if (!dragging) appearance();},{passive:true});
  chrome.storage.local.get([KEY,"bookingSettings","bookingRuntime"]).then(stored=>{
    ui={...defaults,...(stored[KEY] || {})};settings=stored.bookingSettings || {};
    runtime=stored.bookingRuntime || {};
    mount();setInterval(tick,ui.timerDecimals?100:250);
  }).catch(()=>{});
})();
