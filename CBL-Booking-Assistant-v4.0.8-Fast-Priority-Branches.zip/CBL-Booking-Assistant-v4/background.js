"use strict";

importScripts("branch-data.js");
importScripts("branch-priority.js");
importScripts("event-audio.js");
importScripts("diagnostics-background.js");
importScripts("evidence-background.js");

const PLATFORM_PATTERN = "https://fcms.cbl.gov.ly/*";
const COOLDOWN_ALARM = "cbl-v3-cooldown";

const COMPANY_MODES = new Set(["first_available", "random_from_5", "specific", "disabled"]);
const SOUND_TONES = new Set(CBLBookAudio.toneNames);

const DEFAULT_SETTINGS = Object.freeze({
  enabled: false,
  bookingMode: "cash",
  companyResponseSeconds: 8,
  refreshSeconds: 5,
  selectedBranchId: "pair-tobruk-musaid",
  alternateBranchIds: [],

  companyMode: "first_available",
  companyName: "",
  companyAttempts: 2,
  companySkipCount: 5,

  diagnosticsEnabled: false,
  recoveryEnabled: true,

  notifications: true,
  sound: true,
  soundTone: "bell",
  eventSounds: CBLBookAudio.defaults,

  autoConfirm: true,
  autoResumeAfterRateLimit: true,

  pageNotifications: true,
  notificationPosition: "top-center",
  notificationDuration: 5,
  notificationCountdown: true,
  notificationPageBorder: true,
  pauseOnMouseMove: false,
  mouseSensitivity: "medium",
  performanceMode: true,
  waitForTargetBranch: true,
  branchRefreshSeconds: 2,
  notificationOpacity: 88,
  glassTheme: "midnight"
});

const DEFAULT_RUNTIME = Object.freeze({
  phase: "idle",
  message: "جاهز للتشغيل.",
  ownerTabId: null,
  ownerRequestPath: "",

  startedAt: null,
  nextRefreshAt: null,

  cooldownUntil: null,
  rateLimitCount: 0,

  selectedBranch: "",
  selectedCompany: "",

  errorCode: "",
  errorDetails: null,

  updatedAt: 0
});

let creatingOffscreen = null;
let sessionGeneration = 0;
let lifecycleOwnerTabId = null;
let lifecycleQueue = Promise.resolve();
let notificationSequence = 0;
// Alert cancellation is separate from booking ownership and request generation.
let alertEpoch = 0;
const cancelledTabs = new Set();
const closedTabIds = new Set();
const currentNotificationIds = new Set();
function runLifecycleTask(task) {
  const next = lifecycleQueue.then(task,task);
  lifecycleQueue = next.catch(console.error);
  return next;
}
function diagnosticRecord(category,message,data=null,tabId=null) {
  globalThis.CBLDiagnostics?.record(category,message,data,tabId)?.catch(() => {});
}
function platformUrl(url) {
  try { const u=new URL(url); return u.origin === "https://fcms.cbl.gov.ly" && !/^\/(?:login|logout)(?:\/|$)/i.test(u.pathname); }
  catch { return false; }
}
function bookingRequestPath(url) {
  try { return new URL(url).pathname.match(/^(.*\/purchase-requests\/[^/]+)(?:\/|$)/)?.[1] || ""; }
  catch { return ""; }
}
async function isPlatformTab(tabId) {
  if (!Number.isInteger(tabId) || cancelledTabs.has(tabId) || closedTabIds.has(tabId)) return false;
  try { const tab=await chrome.tabs.get(tabId); return !cancelledTabs.has(tabId) && platformUrl(tab.pendingUrl || tab.url); }
  catch { return false; }
}
async function isSessionTab(tabId,runtime) {
  if (!await isPlatformTab(tabId)) return false;
  if (!runtime.ownerRequestPath) return true;
  try { const tab=await chrome.tabs.get(tabId); const path=new URL(tab.pendingUrl || tab.url).pathname;
    return path === runtime.ownerRequestPath || path.startsWith(runtime.ownerRequestPath+"/"); }
  catch { return false; }
}
async function clearSessionEffects() {
  if (creatingOffscreen) { try { await creatingOffscreen; } catch {} }
  try { await chrome.runtime.sendMessage({target:"offscreen",type:"STOP_SOUND"}); } catch {}
  try { if (await chrome.offscreen?.hasDocument?.()) await chrome.offscreen.closeDocument(); } catch {}
  try {
    const notices=await chrome.notifications.getAll();
    for (const id of Object.keys(notices)) if (id.startsWith("cbl-")) await chrome.notifications.clear(id);
  } catch {}
  for (const id of currentNotificationIds) { try { await chrome.notifications.clear(id); } catch {} }
  currentNotificationIds.clear();
}
function alertsMuted(settings) {
  return settings.notifications === false && settings.sound === false && settings.pageNotifications === false;
}
async function setAlertsMuted(muted) {
  const {settings,runtime}=await getState();
  const wasMuted=alertsMuted(settings);
  let nextSettings={...settings};
  const values={};
  if (muted) {
    if (!wasMuted) values.cblAlertRestore={notifications:settings.notifications !== false,sound:settings.sound !== false,pageNotifications:settings.pageNotifications !== false};
    Object.assign(nextSettings,{notifications:false,sound:false,pageNotifications:false});
  } else {
    const stored=await chrome.storage.local.get("cblAlertRestore");
    const saved=stored.cblAlertRestore;
    const keys=["notifications","sound","pageNotifications"];
    const valid=saved && keys.every(key=>typeof saved[key] === "boolean") && keys.some(key=>saved[key]);
    if (wasMuted) for (const key of keys) nextSettings[key]=valid ? saved[key] : DEFAULT_SETTINGS[key];
    values.cblAlertRestore=null;
  }
  if (muted !== wasMuted) alertEpoch++;
  nextSettings=normalizeSettings(nextSettings);
  // One write keeps channel preferences and their restore snapshot consistent.
  // Runtime, session ownership, booking settings and alarms remain active.
  await chrome.storage.local.set({...values,bookingSettings:nextSettings});
  if (muted) await clearSessionEffects();
  diagnosticRecord("ALERTS",muted ? "Alerts muted" : "Alerts restored",{muted});
  return {ok:true,settings:nextSettings,runtime,muted:alertsMuted(nextSettings)};
}
async function alertAllowed(channel,epoch) {
  if (epoch !== alertEpoch) return false;
  const {settings}=await getState();
  return epoch === alertEpoch && !alertsMuted(settings) && (channel === "preview" || settings[channel] !== false);
}
async function notificationContextValid(context) {
  if (!context || context.generation !== sessionGeneration) return false;
  return await isSessionTab(context.tabId,{ownerRequestPath:context.requestPath || ""}) && context.generation === sessionGeneration;
}
async function reconcileSession() {
  const {settings,runtime}=await getState();
  lifecycleOwnerTabId=runtime.ownerTabId;
  const needsOwner=settings.enabled || Number.isInteger(runtime.ownerTabId) ||
    ["running","opening","company","branch","branch_wait","confirm","confirm_pending","cooldown"].includes(runtime.phase);
  if (needsOwner && !await isSessionTab(runtime.ownerTabId,runtime)) {
    await stopSession("انتهت المراقبة بعد إغلاق صفحة الحجز أو مغادرتها.","idle",{silent:true});
  } else {
    if (!Number.isInteger(runtime.ownerTabId)) await clearSessionEffects();
    await updateBadge(runtime.phase);
  }
}
async function endClosedSession(tabId,reason) {
  const {runtime}=await getState();
  await globalThis.CBLEvidence?.cancelTab?.(tabId);
  if (runtime.ownerTabId === tabId) await stopSession(reason,"idle",{silent:true});
}


// Metadata only: never read request bodies, cookies or authentication values.
const platformRequests = new Map();
const networkStartedAt = new Map();
const requestRestoreDeleted = new Set();
const requestRestoreClosedTabs = new Set();
let requestStateRestored = false;
let requestSaveQueue = Promise.resolve();
const requestStateInitialization = (async () => {
  const stored = await chrome.storage.session?.get("cblPendingPlatformRequests");
  for (const entry of stored?.cblPendingPlatformRequests || []) {
    if (!Array.isArray(entry) || entry.length !== 2) continue;
    const [requestId,tabId] = entry;
    if (typeof requestId !== "string" || !Number.isInteger(tabId) || tabId < 0) continue;
    if (!requestRestoreDeleted.has(requestId) && !requestRestoreClosedTabs.has(tabId) && !platformRequests.has(requestId)) {
      platformRequests.set(requestId,tabId);
    }
  }
})().catch(console.error).finally(() => {
  requestStateRestored = true;
  requestRestoreDeleted.clear();
  requestRestoreClosedTabs.clear();
});
function savePlatformRequests() {
  requestSaveQueue = requestSaveQueue.then(async () => {
    await requestStateInitialization;
    await chrome.storage.session?.set({cblPendingPlatformRequests:[...platformRequests.entries()]});
  }).catch(console.error);
  return requestSaveQueue;
}

function platformRequestCount(tabId) {
  return [...platformRequests.values()].filter(id => id === tabId).length;
}
function isPlatformLivewireRequest(details) {
  try {
    const url = new URL(details.url);
    return url.protocol === "https:" && details.tabId >= 0 && details.method === "POST" &&
      url.hostname === "fcms.cbl.gov.ly" && /\/livewire(?:\/|$)/i.test(url.pathname);
  } catch { return false; }
}
function sendPlatformRequestState(tabId, status = null) {
  const send = () => broadcast(tabId, {type:"PLATFORM_REQUEST_STATE",pending:platformRequestCount(tabId),status}).catch(() => {});
  if (requestStateRestored) send();
  else requestStateInitialization.then(send);
}
function completePlatformRequest(details) {
  if (!platformRequests.has(details.requestId)) {
    if (!requestStateRestored && isPlatformLivewireRequest(details)) {
      requestRestoreDeleted.add(details.requestId);
      sendPlatformRequestState(details.tabId,details.statusCode ?? null);
      savePlatformRequests();
    }
    return;
  }
  const tabId = platformRequests.get(details.requestId);
  platformRequests.delete(details.requestId);
  if (!requestStateRestored) requestRestoreDeleted.add(details.requestId);
  sendPlatformRequestState(tabId, details.statusCode ?? null);
  savePlatformRequests();
}

function normalizeSettings(input = {}) {
  return {
    ...DEFAULT_SETTINGS,
    ...input,
    selectedBranchId: CBLBranchPriority.normalize(input).selectedBranchId,
    alternateBranchIds: CBLBranchPriority.normalize(input).alternateBranchIds,

    refreshSeconds: Number.isFinite(Number(input.refreshSeconds))
      ? Math.round(Math.max(0.5, Math.min(30, Number(input.refreshSeconds))) * 10) / 10
      : 5,

    branchRefreshSeconds: Number.isFinite(Number(input.branchRefreshSeconds))
      ? Math.round(Math.max(0.5, Math.min(30, Number(input.branchRefreshSeconds))) * 10) / 10
      : 2,

    bookingMode: input.bookingMode === "card" ? "card" : "cash",
    companyResponseSeconds: Math.max(3, Math.min(30, Number(input.companyResponseSeconds) || 8)),

    companyMode: COMPANY_MODES.has(input.companyMode)
      ? input.companyMode
      : "first_available",

    companyAttempts: Math.max(1, Math.min(3, Number(input.companyAttempts) || 1)),
    companySkipCount: Math.max(0, Math.min(20,
      Math.floor(input.companySkipCount == null ? 5 : Number(input.companySkipCount) || 0))),
    mouseSensitivity: ["low", "medium", "high"].includes(input.mouseSensitivity)
      ? input.mouseSensitivity : "medium",

    eventSounds: CBLBookAudio.normalizeEventSounds(input.eventSounds),
    soundTone: SOUND_TONES.has(input.soundTone)
      ? input.soundTone
      : "bell"
  };
}

async function ensureCatalog() {
  const stored = await chrome.storage.local.get("branchCatalog");

  if (Array.isArray(stored.branchCatalog) && stored.branchCatalog.length) {
    return stored.branchCatalog;
  }

  const catalog = CBL_BRANCH_LIBRARY.createDefaultCatalog();

  await chrome.storage.local.set({
    branchCatalog: catalog
  });

  return catalog;
}

async function getState() {
  const stored = await chrome.storage.local.get([
    "bookingSettings",
    "bookingRuntime"
  ]);

  return {
    settings: normalizeSettings(stored.bookingSettings || {}),

    runtime: {
      ...DEFAULT_RUNTIME,
      ...(stored.bookingRuntime || {})
    },

    catalog: await ensureCatalog()
  };
}

async function saveState(settings, runtime) {
  await chrome.storage.local.set({
    bookingSettings: normalizeSettings(settings),

    bookingRuntime: {
      ...DEFAULT_RUNTIME,
      ...runtime,
      updatedAt: Date.now()
    }
  });
}

async function initializeState() {
  await ensureCatalog();

  const { settings, runtime } = await getState();
  const migration = await chrome.storage.local.get("cblBranchFlowV362Migrated");
  // This requested trial enables confirmation once; the setting remains editable.
  if (!migration.cblBranchFlowV362Migrated) {
    await saveState(settings, runtime);
    await chrome.storage.local.set({cblBranchFlowV362Migrated:true});
  } else {
    await saveState(settings, runtime);
  }
}

async function updateBadge(phase) {
  const map = {
    running: ["●", "#15803d"],
    opening: ["↗", "#2563eb"],
    company: ["C", "#7c3aed"],
    branch: ["B", "#0f766e"],
    branch_wait: ["B", "#b45309"],
    confirm: ["✓", "#7c3aed"],
    confirm_pending: ["…", "#7c3aed"],
    branch_selected: ["B", "#0f766e"],
    success: ["✓", "#15803d"],
    cooldown: ["Ⅱ", "#b45309"],
    error: ["!", "#b91c1c"],
    manual: ["M", "#2563eb"]
  };

  const [text, color] = map[phase] || ["", "#64748b"];

  const iconState=phase === "success" ? "success" : phase === "error" ? "error" :
    ["cooldown","confirm_pending"].includes(phase) ? "paused" :
    ["running","opening","company","branch","branch_wait","confirm"].includes(phase) ? "running" : "idle";
  await chrome.action.setIcon?.({path:{16:`icons/state-${iconState}16.png`,32:`icons/state-${iconState}32.png`,48:`icons/state-${iconState}48.png`,128:`icons/state-${iconState}128.png`}});
  const labels={idle:"متوقف",running:"قيد التشغيل",paused:phase === "confirm_pending" ? "بانتظار نتيجة المنصة" : "متوقف مؤقتًا",success:"نجاح الحجز",error:"توجد مشكلة"};
  await chrome.action.setTitle?.({title:`CBL Assistant — ${labels[iconState]}`});
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
}

async function ensureOffscreen() {
  if (!chrome.offscreen) return false;

  if (
    typeof chrome.offscreen.hasDocument === "function" &&
    await chrome.offscreen.hasDocument()
  ) {
    return true;
  }

  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "تشغيل تنبيهات مساعد الحجز."
    }).finally(() => {
      creatingOffscreen = null;
    });
  }

  await creatingOffscreen;

  return true;
}

async function playSound(kind = "alert", toneOverride = "", context = null, epoch = alertEpoch, volume = 90) {
  try {
    const channel=kind === "preview" ? "preview" : "sound";
    if (!await alertAllowed(channel,epoch)) return false;
    if (context && !await notificationContextValid(context)) return;
    if (!await ensureOffscreen()) return;
    const {settings}=await getState();
    if (!await alertAllowed(channel,epoch) || (context && !await notificationContextValid(context))) { await clearSessionEffects(); return false; }
    let tone=SOUND_TONES.has(toneOverride) ? toneOverride : settings.soundTone;
    if (kind === "stop") tone="double";
    if (kind === "booking_success" && !toneOverride) tone="success";
    await chrome.runtime.sendMessage({target:"offscreen",type:"PLAY_SOUND",kind,tone,volume:Math.max(0,Math.min(100,Number.isFinite(Number(volume)) ? Number(volume) : 90))});
    if (!await alertAllowed(channel,epoch) || (context && !await notificationContextValid(context))) { await clearSessionEffects(); return false; }
    return true;
  } catch {}
}

async function playBookingEvent(event,context,key=event,epoch=alertEpoch) {
  if (!CBLBookAudio.events.includes(event) || !await notificationContextValid(context) || !await alertAllowed("sound",epoch)) return false;
  const {settings,runtime}=await getState();
  if (event === "branch_available" && settings.bookingMode === "card") return false;
  const config=CBLBookAudio.eventConfig(settings,event);
  if (!config || !CBLBookAudio.claim(event,event,context.generation)) return false;
  // Claim the event before asynchronous audio work. The key is bounded to the
  // session event so generic notices and DOM reports cannot double-play it.
  return playSound(event === "booking_success" ? "booking_success" : "event",config.tone,context,epoch,config.volume);
}
async function notify(title,message,kind="alert",context=null) {
  const epoch=alertEpoch;
  const {settings,runtime}=await getState();
  context ||= {tabId:runtime.ownerTabId,generation:sessionGeneration};
  context.requestPath ??= runtime.ownerRequestPath || "";
  if (!await notificationContextValid(context) || epoch !== alertEpoch || alertsMuted(settings)) return false;
  const id=`cbl-${Date.now()}-${++notificationSequence}`;
  if (settings.notifications && await alertAllowed("notifications",epoch)) {
    try {
      currentNotificationIds.add(id);
      await chrome.notifications.create(id,{type:"basic",iconUrl:chrome.runtime.getURL("icons/icon128.png"),title,message,priority:2});
      if (!await notificationContextValid(context) || !await alertAllowed("notifications",epoch)) { await chrome.notifications.clear(id); currentNotificationIds.delete(id); return false; }
    } catch {}
  }
  if (settings.sound && await notificationContextValid(context)) {
    let event=CBLBookAudio.eventFromKind(kind);
    if (kind === "branch" && settings.bookingMode === "card") event="company_selected";
    if (event) await playBookingEvent(event,context,event,epoch);
    else await playSound(kind,"",context,epoch);
  }
  return true;
}

// Evidence completion uses the same liveness gate as booking notifications.
globalThis.CBLPageEffects = {
  isPlatformTab,notify,context:tabId=>({tabId,generation:sessionGeneration}),
  complete:(tabId,context,task)=>runLifecycleTask(async()=>{
    if (!await notificationContextValid(context)) return false;
    const {runtime}=await getState();
    if (Number.isInteger(runtime.ownerTabId) && runtime.ownerTabId !== tabId) return false;
    const result=await task();
    if (!result || !await notificationContextValid(context)) return false;
    lifecycleOwnerTabId=tabId;
    await updateBadge((await getState()).runtime.phase);
    return result;
  })
};

async function broadcast(tabId, message) {
  if (!Number.isInteger(tabId)) return false;

  try {
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch {
    return false;
  }
}

async function stopSession(
  reason = "تم إيقاف الإضافة.",
  phase = "idle",
  options = {}
) {
  const {
    notifyUser = false,
    kind = "stop",
    branch = "",
    broadcastStop = true,
    silent = false,
    preserveOwner = false
  } = options;

  const { settings, runtime } = await getState();
  const tabId = runtime.ownerTabId;
  if (!preserveOwner) sessionGeneration++;
  lifecycleOwnerTabId = preserveOwner ? tabId : null;
  const notificationContext={tabId,generation:sessionGeneration,requestPath:runtime.ownerRequestPath};
  diagnosticRecord("LIFECYCLE","Session stopped",{reason,phase,silent},tabId);
  if (!preserveOwner) await globalThis.CBLEvidence?.cancelTab?.(tabId);
  if (silent) await clearSessionEffects();

  await chrome.alarms.clear(COOLDOWN_ALARM);

  await saveState(
    {
      ...settings,
      enabled: false
    },
    {
      ...runtime,
      phase,
      message: reason,
      ownerTabId: preserveOwner ? tabId : null,
      ownerRequestPath: preserveOwner ? runtime.ownerRequestPath : "",
      nextRefreshAt: null,
      cooldownUntil: null,
      selectedBranch: branch || runtime.selectedBranch,
      errorCode: "",
      errorDetails: null
    }
  );

  await updateBadge(phase);
  await globalThis.CBLDiagnostics?.flush?.();

  if (broadcastStop) {
    await broadcast(tabId, {
      type: "STOP_BOOKING_ASSISTANT",
      reason
    });
  }

  if (notifyUser && !silent) {
    await notify(
      phase === "success"
        ? "اكتملت مهمة مساعد الحجز"
        : "تم إيقاف مساعد الحجز",
      reason,
      kind,
      notificationContext
    );
  }
}

function defaultCooldown(attempt) {
  const values = [
    15 * 60 * 1000,
    30 * 60 * 1000,
    60 * 60 * 1000
  ];

  return values[Math.min(Math.max(attempt - 1, 0), values.length - 1)];
}

function retryAfterMilliseconds(headers) {
  if (!Array.isArray(headers)) return null;

  const header = headers.find(item =>
    String(item.name || "").toLowerCase() === "retry-after"
  );

  if (!header?.value) return null;

  const value = String(header.value).trim();
  const seconds = Number(value);

  if (Number.isFinite(seconds) && seconds >= 0) {
    return seconds * 1000;
  }

  const date = Date.parse(value);

  return Number.isFinite(date)
    ? Math.max(0, date - Date.now())
    : null;
}

async function handleRateLimit(tabId, retryAfterMs = null) {
  const { settings, runtime } = await getState();

  if (!settings.enabled || runtime.ownerTabId !== tabId || !await isSessionTab(tabId,runtime)) return;

  if (
    Number.isInteger(runtime.ownerTabId) &&
    Number.isInteger(tabId) &&
    runtime.ownerTabId !== tabId
  ) {
    return;
  }

  const count = Number(runtime.rateLimitCount || 0) + 1;

  if (!settings.autoResumeAfterRateLimit || count > 3) {
    await stopSession(
      "تكرر HTTP 429. تم إيقاف الإضافة لحماية الجلسة.",
      "error",
      {
        notifyUser: true,
        kind: "warning"
      }
    );

    return;
  }

  const duration = Number.isFinite(retryAfterMs)
    ? Math.max(1000, retryAfterMs)
    : defaultCooldown(count);

  const until = Date.now() + duration;

  await saveState(settings, {
    ...runtime,
    phase: "cooldown",
    message: "HTTP 429 — انتظار آمن قبل الاستئناف.",
    cooldownUntil: until,
    nextRefreshAt: null,
    rateLimitCount: count,

    errorCode: "HTTP_429",

    errorDetails: {
      recoverable: false,
      reason: "يجب انتظار مهلة حماية المنصة."
    }
  });

  await chrome.alarms.create(COOLDOWN_ALARM, {
    when: until
  });

  await updateBadge("cooldown");

  await broadcast(runtime.ownerTabId, {
    type: "PAUSE_FOR_RATE_LIMIT",
    cooldownUntil: until
  });

  await notify(
    "توقف آمن",
    "تم اكتشاف HTTP 429 وسيتم انتظار المهلة.",
    "warning"
  );
}

async function resumeAfterCooldown() {
  const { settings, runtime } = await getState();

  if (!settings.enabled || runtime.phase !== "cooldown") return;
  if (!await isSessionTab(runtime.ownerTabId,runtime)) {
    await stopSession("انتهت المراقبة بعد مغادرة صفحة الحجز.","idle",{silent:true});
    return;
  }

  await saveState(settings, {
    ...runtime,
    phase: "running",
    message: "انتهت مهلة التوقف. استئناف المراقبة.",
    cooldownUntil: null,
    nextRefreshAt: Date.now() + settings.refreshSeconds * 1000,
    errorCode: "",
    errorDetails: null
  });

  await updateBadge("running");

  await broadcast(runtime.ownerTabId, {
    type: "RESUME_AFTER_COOLDOWN"
  });
}

async function runLivewireAction(
  tabId,
  { method, componentId, contractId }
) {
  if (
    !Number.isInteger(tabId) ||
    !["openContractsSelect", "selectContract"].includes(method)
  ) {
    return {
      ok: false,
      error: "Invalid Livewire action"
    };
  }

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",

    func: async (componentIdArg, methodArg, contractIdArg) => {
      try {
        const livewire = window.Livewire;
        const component = livewire?.find?.(componentIdArg);

        if (!component) {
          return {
            ok: false,
            error: "Livewire component not found"
          };
        }

        const wire = component.$wire || component;

        let result;

        if (typeof wire?.[methodArg] === "function") {
          result = methodArg === "selectContract"
            ? wire[methodArg](Number(contractIdArg))
            : wire[methodArg]();

        } else if (typeof component.call === "function") {
          result = methodArg === "selectContract"
            ? component.call(methodArg, Number(contractIdArg))
            : component.call(methodArg);

        } else if (typeof wire?.call === "function") {
          result = methodArg === "selectContract"
            ? wire.call(methodArg, Number(contractIdArg))
            : wire.call(methodArg);

        } else {
          return {
            ok: false,
            error: "Livewire method unavailable"
          };
        }

        await Promise.resolve(result);

        return { ok: true };

      } catch (error) {
        return {
          ok: false,
          error: String(error?.message || error)
        };
      }
    },

    args: [
      componentId,
      method,
      contractId
    ]
  });

  return results?.[0]?.result || {
    ok: false,
    error: "No Livewire result"
  };
}

chrome.runtime.onInstalled.addListener(() => {
  stateInitialization.catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  sessionGeneration++;
  return stateInitialization.then(()=>runLifecycleTask(()=>stopSession("ابدأ جلسة جديدة بعد فتح المتصفح.","idle",{silent:true}))).catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") {
    return false;
  }

  // The evidence module owns its messages and replies separately.
  if (typeof message?.type === "string" && message.type.startsWith("EVIDENCE_")) {
    return false;
  }

  const messageGeneration=sessionGeneration;
  (async () => {
    await stateInitialization;
    await requestStateInitialization;
    const mutating = new Set(["START_SESSION","STOP_SESSION","SET_ALERTS_MUTED","MANUAL_TAKEOVER","COMPLETE_BRANCH_AND_STOP","CONFIRM_SUBMITTED_WAIT_RESULT","MANUAL_BRANCH_REQUIRED_STOP","PLATFORM_ACCESS_ERROR","SET_RUNTIME","RATE_LIMIT_DETECTED"]);
    const dispatch = async () => {
    const ownerMessages=new Set(["NOTIFY","BOOKING_SOUND","SET_RUNTIME","MANUAL_TAKEOVER","COMPLETE_BRANCH_AND_STOP","CONFIRM_SUBMITTED_WAIT_RESULT","MANUAL_BRANCH_REQUIRED_STOP","PLATFORM_ACCESS_ERROR","LIVEWIRE_ACTION"]);
    if (ownerMessages.has(message?.type)) {
      const {settings,runtime}=await getState();
      const valid=sender.tab?.id === runtime.ownerTabId && await isSessionTab(runtime.ownerTabId,runtime);
      if (!valid || messageGeneration !== sessionGeneration || (!settings.enabled && runtime.phase !== "confirm_pending")) {
        sendResponse(message.type === "PLATFORM_ACCESS_ERROR" ? {ok:false} : {ok:true,ignored:true}); return;
      }
      if (runtime.phase === "confirm_pending" && message.type === "SET_RUNTIME" && !["success","error"].includes(message.patch?.phase)) {sendResponse({ok:true,ignored:true});return;}
    }
    switch (message?.type) {
      case "GET_STATE": {
        sendResponse({
          ok: true,
          platformRequestsPending: platformRequestCount(sender.tab?.id),
          ...(await getState()),
          tabId: sender.tab?.id ?? null
        });
        break;
      }

      case "SET_ALERTS_MUTED": {
        if (typeof message.muted !== "boolean") {sendResponse({ok:false,error:"اختر حالة كتم التنبيهات."});break;}
        sendResponse(await setAlertsMuted(message.muted));
        break;
      }

      case "START_SESSION": {
        const tabId = Number.isInteger(message.tabId)
          ? message.tabId
          : sender.tab?.id;

        let tab;
        try {tab=await chrome.tabs.get(tabId);} catch {}
        if (!tab || closedTabIds.has(tabId) || !platformUrl(tab.url)) {sendResponse({ok:false,error:"افتح صفحة المنصة أولًا."});break;}
        const previous=(await getState()).runtime;
        sessionGeneration++;
        if (Number.isInteger(previous.ownerTabId)) {
          await globalThis.CBLEvidence?.cancelTab?.(previous.ownerTabId);
          if (previous.ownerTabId !== tabId) await broadcast(previous.ownerTabId,{type:"STOP_BOOKING_ASSISTANT"});
        }
        await clearSessionEffects();
        if (closedTabIds.has(tabId)) {sendResponse({ok:false,error:"أُغلقت صفحة الحجز."});break;}
        cancelledTabs.delete(tabId);
        lifecycleOwnerTabId=tabId;
        const settings = normalizeSettings({
          ...message.settings,
          enabled: true
        });

        const runtime = {
          ...DEFAULT_RUNTIME,
          phase: "running",
          message: "بدأت مراقبة الطلب.",
          ownerTabId: tabId,
          ownerRequestPath: bookingRequestPath(tab.url),
          startedAt: Date.now(),
          nextRefreshAt: Date.now() + settings.refreshSeconds * 1000
        };

        await chrome.alarms.clear(COOLDOWN_ALARM);
        await saveState(settings, runtime);
        await updateBadge("running");
        diagnosticRecord("SESSION","Booking monitoring started",{mode:settings.bookingMode,companyMode:settings.companyMode,autoConfirm:settings.autoConfirm},tabId);

        sendResponse({
          ok: true,
          settings,
          runtime
        });

        break;
      }

      case "STOP_SESSION": {
        await stopSession(
          "تم إيقاف المراقبة يدويًا.",
          "idle"
        );

        sendResponse({ ok: true });
        break;
      }

      case "MANUAL_TAKEOVER": {
        await stopSession("تم الإيقاف بسبب حركة الماوس.", "manual", {broadcastStop:false});
        sendResponse({ok:true});
        break;
      }

      case "COMPLETE_BRANCH_AND_STOP": {
        const branch = String(message.branch || "").trim();

        await stopSession(
          branch ? `تم اختيار الفرع: ${branch}. أكمل تأكيد الحجز يدويًا.` : "تم اعتماد شركة الصرافة. أكمل تأكيد حجز البطاقة يدويًا.",
          "branch_selected",
          {
            notifyUser: true,
            kind: "stop",
            branch
          }
        );

        sendResponse({ ok: true });
        break;
      }

      case "CONFIRM_SUBMITTED_WAIT_RESULT": {
        const branch = String(message.branch || "").trim();

        if ((await getState()).runtime.phase === "success") {
          sendResponse({ok:true});
          break;
        }

        await stopSession(
          "تم الضغط على تأكيد الحجز مرة واحدة؛ بانتظار نتيجة المنصة.",
          "confirm_pending",
          {
            notifyUser: false,
            branch,
            broadcastStop: false,
            preserveOwner: true
          }
        );

        sendResponse({ ok: true });
        break;
      }

      case "MANUAL_BRANCH_REQUIRED_STOP": {
        const reason =
          String(
            message.reason ||
            "تم اعتماد شركة الصرافة. اختر فرعًا آخر يدويًا."
          );

        await stopSession(
          reason,
          "idle",
          {
            notifyUser: true,
            kind: "warning",
            broadcastStop: false
          }
        );

        sendResponse({
          ok: true
        });

        break;
      }


      case "GET_PLATFORM_REQUEST_STATE": {
        sendResponse({ok:true,pending:platformRequestCount(sender.tab?.id)});
        break;
      }

      case "PLATFORM_ACCESS_ERROR": {
        const status = Number(message.status);
        if (![401,403,419].includes(status)) { sendResponse({ok:false}); break; }
        const {runtime} = await getState();
        if (Number.isInteger(runtime.ownerTabId) && sender.tab?.id !== runtime.ownerTabId) {
          sendResponse({ok:false}); break;
        }
        await stopSession(status === 403 ? "رفضت المنصة الوصول (403 — صلاحيات غير كافية). تحقق من حالة الطلب وصلاحية الحساب في المنصة." : "انتهت جلسة المنصة أو رفضت التحقق من الجلسة. سجل الدخول من جديد.", "error", {notifyUser:true,kind:"warning"});
        sendResponse({ok:true});
        break;
      }

      case "SET_RUNTIME": {
        const { settings, runtime } = await getState();

        const nextRuntime = {
          ...runtime,
          ...(message.patch || {})
        };

        await saveState(settings, nextRuntime);
        await updateBadge(nextRuntime.phase);
        diagnosticRecord("STATE","Booking state changed",{previousPhase:runtime.phase,phase:nextRuntime.phase,message:nextRuntime.message,errorCode:nextRuntime.errorCode},sender.tab?.id);

        sendResponse({ ok: true });
        break;
      }

      case "BOOKING_SOUND": {
        const played=await playBookingEvent(message.event,{tabId:sender.tab?.id,generation:messageGeneration,requestPath:(await getState()).runtime.ownerRequestPath || ""},message.key);
        sendResponse({ok:true,played:!!played});
        break;
      }
      case "NOTIFY": {
        await notify(
          message.title || "مساعد الحجز",
          message.message || "يوجد تحديث.",
          message.kind || "alert",
          {tabId:sender.tab?.id,generation:messageGeneration}
        );

        sendResponse({ ok: true });
        break;
      }

      case "DIAGNOSTIC_EVENTS": {
        const {runtime}=await getState();
        if (sender.tab?.id !== runtime.ownerTabId || !await isSessionTab(runtime.ownerTabId,runtime)) {
          sendResponse({ok:true,ignored:true});break;
        }
        await CBLDiagnostics.recordBatch(message.events,sender.tab.id);
        sendResponse({ok:true});break;
      }
      case "DIAGNOSTIC_STATUS": { sendResponse({ok:true,...(await CBLDiagnostics.status())}); break; }
      case "DIAGNOSTIC_CLEAR": { await CBLDiagnostics.clear();sendResponse({ok:true});break; }
      case "DIAGNOSTIC_EXPORT": {
        const {runtime}=await getState();
        if (await isSessionTab(runtime.ownerTabId,runtime)) await broadcast(runtime.ownerTabId,{type:"DIAGNOSTIC_FLUSH"});
        const report=await CBLDiagnostics.exportReport();
        const id=await chrome.downloads.download({url:"data:application/json;charset=utf-8,"+encodeURIComponent(JSON.stringify(report)),filename:`CBL-Diagnostics/CBL-report-${new Date().toISOString().replace(/[:.]/g,"-")}.json`,saveAs:true,conflictAction:"uniquify"});
        sendResponse({ok:true,downloadId:id});break;
      }

      case "PREVIEW_SOUND": {
        if (alertsMuted((await getState()).settings)) {sendResponse({ok:true,muted:true});break;}
        const played=await playSound(
          "preview",
          SOUND_TONES.has(message.tone)
            ? message.tone
            : "bell",null,alertEpoch,message.volume
        );

        sendResponse({ ok: true,played:!!played });
        break;
      }

      case "LIVEWIRE_ACTION": {
        const result = await runLivewireAction(
          sender.tab?.id,
          {
            method: String(message.method || ""),
            componentId: String(message.componentId || ""),
            contractId: message.contractId
          }
        );

        sendResponse({
          ok: result.ok,
          result
        });

        break;
      }

      case "RATE_LIMIT_DETECTED": {
        await handleRateLimit(sender.tab?.id);
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({
          ok: false,
          ignored: true
        });
    }
    };
    if (mutating.has(message?.type)) return runLifecycleTask(dispatch);
    return dispatch();
  })().catch(error => {
    console.error("CBL background error", error);
    diagnosticRecord("BACKGROUND_ERROR",String(error?.message || error),{messageType:message?.type},sender.tab?.id);

    try {
      sendResponse({
        ok: false,
        error: String(error?.message || error)
      });
    } catch {}
  });

  return true;
});

chrome.commands.onCommand.addListener(command => {
  if (command !== "stop-booking-assistant") {
    return;
  }

  stateInitialization.then(()=>runLifecycleTask(()=>stopSession(
    "تم الإيقاف الفوري بواسطة Ctrl+Shift+X.",
    "idle",
    {
      notifyUser: true,
      kind: "stop"
    }
  ))).catch(console.error);
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === COOLDOWN_ALARM) {
    stateInitialization.then(()=>runLifecycleTask(resumeAfterCooldown)).catch(console.error);
  }
});

chrome.webRequest.onBeforeRequest.addListener(details => {
  if (!isPlatformLivewireRequest(details)) return;
  platformRequests.set(details.requestId, details.tabId);
  networkStartedAt.set(details.requestId,Number(details.timeStamp) || Date.now());
  diagnosticRecord("NETWORK_START","Platform request started",{method:details.method,path:new URL(details.url).pathname,requestId:details.requestId},details.tabId);
  requestRestoreDeleted.delete(details.requestId);
  sendPlatformRequestState(details.tabId);
  savePlatformRequests();
}, {urls:[PLATFORM_PATTERN]});

chrome.webRequest.onErrorOccurred.addListener(details => {
  completePlatformRequest(details);
  const start=networkStartedAt.get(details.requestId);
  networkStartedAt.delete(details.requestId);
  diagnosticRecord("NETWORK_ERROR","Platform request failed",{error:details.error,method:details.method,path:new URL(details.url).pathname,durationMs:start == null ? null : Math.max(0,(Number(details.timeStamp)||Date.now())-start)},details.tabId);
}, {urls:[PLATFORM_PATTERN]});

chrome.tabs.onRemoved.addListener(tabId => {
  cancelledTabs.add(tabId);
  closedTabIds.add(tabId);
  if (lifecycleOwnerTabId === tabId) sessionGeneration++;
  if (!requestStateRestored) requestRestoreClosedTabs.add(tabId);
  for (const [requestId,id] of platformRequests) if (id === tabId) {
    platformRequests.delete(requestId);
    if (!requestStateRestored) requestRestoreDeleted.add(requestId);
  }
  savePlatformRequests();
  return stateInitialization.then(()=>runLifecycleTask(()=>endClosedSession(tabId,"انتهت المراقبة بعد إغلاق صفحة الحجز."))).catch(console.error);
});

chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab) => {
  const nextUrl=changeInfo.url || (changeInfo.status === "loading" ? tab.pendingUrl : "");
  if (!nextUrl) return;
  if (!platformUrl(nextUrl)) {
    cancelledTabs.add(tabId);
    if (lifecycleOwnerTabId === tabId) sessionGeneration++;
    globalThis.CBLEvidence?.cancelTab?.(tabId)?.catch(() => {});
  }
  return stateInitialization.then(async () => {
    const {runtime}=await getState();
    if (runtime.ownerTabId !== tabId) return;
    const url=nextUrl;
    const sameRequest=!runtime.ownerRequestPath || bookingRequestPath(url) === runtime.ownerRequestPath;
    if (platformUrl(url) && sameRequest) return;
    cancelledTabs.add(tabId);
    sessionGeneration++;
    return runLifecycleTask(()=>endClosedSession(tabId,"انتهت المراقبة بعد مغادرة صفحة الحجز."));
  }).catch(console.error);
});

chrome.windows?.onRemoved?.addListener(() => {
  return stateInitialization.then(async () => {
    if ((await chrome.windows.getAll()).length) return;
    sessionGeneration++;
    return runLifecycleTask(()=>stopSession("انتهت المراقبة بعد إغلاق المتصفح.","idle",{silent:true}));
  }).catch(console.error);
});

chrome.webRequest.onCompleted.addListener(
  async details => {
    if (details.tabId < 0) return;
    completePlatformRequest(details);
    const start=networkStartedAt.get(details.requestId);
    networkStartedAt.delete(details.requestId);
    diagnosticRecord("NETWORK_END","Platform request completed",{status:details.statusCode,method:details.method,path:new URL(details.url).pathname,requestId:details.requestId,durationMs:start == null ? null : Math.max(0,(Number(details.timeStamp)||Date.now())-start)},details.tabId);
    await stateInitialization;

    if (details.statusCode === 429) {
      await runLifecycleTask(()=>handleRateLimit(details.tabId,retryAfterMilliseconds(details.responseHeaders)));
    }

    const { settings } = await getState();

    if (!settings.diagnosticsEnabled) return;

    let pathname = "";

    try {
      pathname = new URL(details.url).pathname;
    } catch {}

    if (
      !pathname.includes("livewire") &&
      details.statusCode < 400
    ) {
      return;
    }

    await broadcast(details.tabId, {
      type: "DIAG_NETWORK_EVENT",
      event: {
        status: details.statusCode,
        method: details.method,
        path: pathname
      }
    });
  },
  {
    urls: [PLATFORM_PATTERN]
  },
  ["responseHeaders"]
);

const stateInitialization = initializeState().then(reconcileSession).catch(console.error);
