"use strict";

const SOUND_IDS = {
  classic: "alertClassic",
  bell: "alertBell",
  double: "alertDouble",
  rise: "alertRise",
  soft: "alertSoft",
  pulse: "alertPulse",
  chime: "alertChime",
  swift: "alertSwift",
  success: "bookingSuccess",
  spark: "alertSpark",
  wood: "alertWood",
  beacon: "alertBeacon",
  celebrate: "alertCelebrate"
};

const EXTRA_TONE_FILES = Object.freeze({
  alertSpark: "sounds/alert-spark.wav",
  alertWood: "sounds/alert-wood.wav",
  alertBeacon: "sounds/alert-beacon.wav",
  alertCelebrate: "sounds/alert-celebrate.wav"
});

function audioForTone(id) {
  let audio = document.getElementById(id);
  if (!audio && EXTRA_TONE_FILES[id]) {
    audio = document.createElement("audio");
    audio.id = id;
    audio.preload = "auto";
    audio.src = chrome.runtime.getURL(EXTRA_TONE_FILES[id]);
    document.body.appendChild(audio);
  }
  return audio;
}

chrome.runtime.onMessage.addListener(
  (
    message,
    _sender,
    sendResponse
  ) => {
    if (
      message?.target !== "offscreen" ||
      !["PLAY_SOUND","STOP_SOUND"].includes(message?.type)
    ) {
      return false;
    }

    if (message.type === "STOP_SOUND") {
      document.querySelectorAll("audio").forEach(item=>{item.pause();item.currentTime=0;});
      sendResponse({ok:true});
      return false;
    }

    const id =
      message.kind === "warning"
        ? "warningSound"
        : (
            SOUND_IDS[message.tone] ||
            SOUND_IDS.classic
          );

    const audio =
      audioForTone(id);

    if (!audio) {
      sendResponse({
        ok: false,
        error:
          "ملف الصوت غير موجود."
      });

      return false;
    }

    document.querySelectorAll("audio")
      .forEach(item => {
        item.pause();
        item.currentTime = 0;
      });

    const volume = Number(message.volume);
    audio.volume = message.volume != null && message.volume !== "" && Number.isFinite(volume)
      ? Math.max(0, Math.min(100, volume)) / 100 : 0.9;

    audio.play()
      .then(
        () => {
          sendResponse({
            ok: true
          });
        },

        error => {
          sendResponse({
            ok: false,
            error:
              String(
                error?.message ||
                error
              )
          });
        }
      );

    return true;
  }
);
