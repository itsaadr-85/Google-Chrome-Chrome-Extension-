"use strict";

(() => {
  if (window.top !== window || window.__CBL_ASSISTANT_V340__) {
    return;
  }

  window.__CBL_ASSISTANT_V340__ = true;

  const LIB =
    globalThis.CBL_BRANCH_LIBRARY;

  const COMPANY_LIB =
    globalThis.CBL_COMPANY_LIBRARY;

  const DEFAULT_SETTINGS = {
    enabled: false,
  bookingMode: "cash",
  companyResponseSeconds: 8,
    refreshSeconds: 5,
    selectedBranchId: "pair-tobruk-musaid",
    alternateBranchIds: [],

    companyMode: "first_available",
    companyName: "",
    companyAttempts: 2,
    companySkipCount: 5,

    diagnosticsEnabled: false,
    recoveryEnabled: true,

    notifications: true,
    sound: true,
    soundTone: "bell",

    autoConfirm: true,
    autoResumeAfterRateLimit: true,

    pageNotifications: true,
    notificationPosition: "top-center",
    notificationDuration: 5,
    notificationCountdown: true,
    notificationPageBorder: true,
    pauseOnMouseMove: false,
    mouseSensitivity: "medium",
    performanceMode: true,
    waitForTargetBranch: true,
    branchRefreshSeconds: 2,
    notificationOpacity: 88,
    glassTheme: "midnight"
  };

  let settings = {
    ...DEFAULT_SETTINGS
  };

  let catalog = [];

  let running = false;

  let refreshTimer = null;
  let branchErrorTimer = null;
  let branchDecisionTimer = null;

  let pageObserver = null;
  let branchObserver = null;
  let confirmObserver = null;

  let confirmTimer = null;
  let observedBranchSelect = null;

  let companyFlowStarted = false;
  let companyListOpening = null;
  let platformRequestsPending = 0;
  let platformLastCompletedAt = 0;
  let companyBridgePending = 0;
  let companyPendingObserver = null;
  let companyPendingTimer = null;
  let companyAttemptsUsed = 0;
  let companyFlowToken = 0;
  let companyChoiceForRetry = "";

  let branchSelected = false;
  let branchSelectionInProgress = false;
  let branchCommitPending = false;
  let branchSelectionToken = null;
  let branchListSnapshot = null;
  let branchListReadyTimer = null;
  let confirmSignalHandler = null;
  let branchObserverTimer = null;
  let selectedBranchLabel = "";
  let selectedBranchTargetName = "";
  let branchRefreshDeferred = false;

  let awaitingAutoConfirm = false;
  let confirmClicked = false;
  let finalizingBooking = false;

  let branchFallbackMode = false;
  let branchFirstDecisionDone = false;

  let confirmClickMonitorAttached = false;
  let mousePauseTriggered = false;
  let mousePauseListenerAttached = false;
  let mouseSessionToken = 0;

  let diagnosticsListenerAttached = false;

  const diagnostic =
    new CBLDiagnostic.DiagnosticLogger(false);

  const normalize = value =>
    LIB.normalizeArabic(value);

  const sleep = ms =>
    new Promise(resolve =>
      setTimeout(resolve, ms)
    );

  const nextFrame = () =>
    new Promise(resolve =>
      requestAnimationFrame(resolve)
    );

  function installDiagnosticErrors() {
    window.addEventListener("error",event=>{
      if (settings.diagnosticsEnabled && running) log("PAGE_ERROR",String(event.message || "Resource error"),{file:event.filename || "",line:event.lineno,column:event.colno});
    });
    window.addEventListener("unhandledrejection",event=>{
      if (settings.diagnosticsEnabled && running) log("PAGE_REJECTION",String(event.reason?.message || event.reason || "Unhandled rejection"));
    });
  }
  installDiagnosticErrors();

  async function loadState() {
    const response =
      await chrome.runtime.sendMessage({
        type: "GET_STATE"
      });

    if (!response?.ok) {
      return false;
    }

    settings = {
      ...DEFAULT_SETTINGS,
      ...(response.settings || {})
    };
    companyChoiceForRetry = String(response.runtime?.selectedCompany || "");
    platformRequestsPending = Math.max(0,Number(response.platformRequestsPending) || 0);

    catalog =
      Array.isArray(response.catalog)
        ? response.catalog
        : [];

    diagnostic.setEnabled(
      settings.diagnosticsEnabled
    );

    await diagnostic.load();

    return true;
  }

  function log(category, message, data = null) {
    diagnostic.log(
      category,
      message,
      data
    );
  }

  async function setRuntime(
    phase,
    message,
    extra = {}
  ) {
    try {
      await chrome.runtime.sendMessage({
        type: "SET_RUNTIME",

        patch: {
          phase,
          message,
          ...extra
        }
      });
    } catch {}
  }

  function notify(title, message, kind = "alert") {
    chrome.runtime.sendMessage({
      type: "NOTIFY",
      title,
      message,
      kind
    }).catch(() => {});
  }

  function emitBookingSound(event, key = event) {
    if (!running || !settings.enabled || settings.sound === false || settings.alertsMuted === true ||
        settings.eventSounds?.[event]?.enabled === false) return false;
    const seen = emitBookingSound.seen || (emitBookingSound.seen = new Set());
    const id = `${event}:${String(key || event)}`;
    if (seen.has(id)) return false;
    seen.add(id);
    // Never await sound delivery, storage or offscreen audio on a booking path.
    try {
      chrome.runtime.sendMessage({ type: "BOOKING_SOUND", event, key }).catch(() => {});
    } catch {}
    return true;
  }

  function pageNotify(
    type,
    title,
    message,
    important = false,
    duration = null
  ) {
    if (
      settings.pageNotifications === false ||
      !globalThis.CBLPageNotify
    ) {
      return;
    }

    try {
      CBLPageNotify.show({
        type,
        title,
        message,

        position:
          settings.notificationPosition ||
          "top-center",

        direction:
          settings.uiLanguage === "en"
            ? "ltr"
            : "rtl",

        duration:
          duration ??
          (
            Number(
              settings.notificationDuration
            ) || 5
          ),

        countdown:
          settings.notificationCountdown !==
          false,

        opacity: Number(settings.notificationOpacity) || 88,
        glassTheme: settings.glassTheme || "midnight",

        pageBorder:
          Boolean(
            important &&
            settings.notificationPageBorder !==
              false
          )
      });
    } catch {}
  }

function clearTimers() {
    clearTimeout(refreshTimer);
    clearTimeout(branchErrorTimer);
    clearTimeout(branchDecisionTimer);
    clearTimeout(branchListReadyTimer);
    branchListReadyTimer=null;branchListSnapshot=null;

    refreshTimer = null;
    branchErrorTimer = null;
    branchDecisionTimer = null;

    if (confirmTimer) {
      clearInterval(confirmTimer);
      confirmTimer = null;
    }
  }

  function disconnectObservers() {
    pageObserver?.disconnect();
    branchObserver?.disconnect();
    confirmObserver?.disconnect();

    pageObserver = null;
    branchObserver = null;
    confirmObserver = null;
    if(confirmSignalHandler) {
      document.removeEventListener("input",confirmSignalHandler,true);
      document.removeEventListener("change",confirmSignalHandler,true);
      document.removeEventListener("cbl:booking-state",confirmSignalHandler);
      confirmSignalHandler=null;
    }
    observedBranchSelect = null;
  }

  function clearEngine() {
    running = false;

    clearTimers();
    disconnectObservers();

    companyFlowToken += 1;
    branchCommitPending=false;branchSelectionInProgress=false;branchSelectionToken=null;branchRefreshDeferred=false;
    notifyCompanyStateChange();
    companyListOpening = null;
    clearCompanyPendingWatcher();
  }

  function stopPreConfirmWork() {
    clearTimeout(refreshTimer);
    clearTimeout(branchErrorTimer);
    clearTimeout(branchDecisionTimer);

    refreshTimer = null;
    branchErrorTimer = null;
    branchDecisionTimer = null;

    pageObserver?.disconnect();
    branchObserver?.disconnect();

    pageObserver = null;
    branchObserver = null;

    observedBranchSelect = null;

    companyFlowToken += 1;
    notifyCompanyStateChange();
    clearCompanyPendingWatcher();
  }

  function isEditPage() {
    if (
      document.querySelector(
        "#bank_branch"
      )
    ) {
      return true;
    }

    if (
      document.querySelector(
        "#company, #company_branch, #company_contract"
      )
    ) {
      return true;
    }

    if (
      document.querySelector(
        ".cf-turnstile"
      ) &&
      findConfirmButton()
    ) {
      return true;
    }

    return /\/purchase-requests\/[^/]+\/edit\/?$/
      .test(location.pathname);
  }

  function isRequestPage() {
    if (
      findEditLink()
    ) {
      return true;
    }

    return (
      location.pathname
        .includes(
          "/purchase-requests"
        ) &&
      !isEditPage()
    );
  }

  function pageShowsRateLimit() {
    const text =
      normalize(
        document.body?.textContent || ""
      );

    return [
      "لقد تجاوزت الحد الاقصي لعدد الطلبات",
      "عدد كبير من الطلبات",
      "يرجي الانتظار",
      "too many requests",
      "http 429"
    ].some(item =>
      text.includes(normalize(item))
    );
  }

  function pageShowsExpiredSession() {
    return Boolean(
      document.querySelector(
        'input[type="password"], form[action*="login"]'
      )
    );
  }

  async function reportError(
    code,
    message,
    details = {},
    recoverable = true
  ) {
    log("ERROR", message, {
      code,
      ...details
    });

    await setRuntime(
      "error",
      message,
      {
        errorCode: code,

        errorDetails: {
          ...details,

          recoverable: Boolean(
            recoverable &&
            settings.recoveryEnabled
          )
        }
      }
    );
  }

  function findEditLink() {
    const links = [
      ...document.querySelectorAll(
        'a[href*="/purchase-requests/"][href*="/edit"]'
      )
    ];

    return links.find(link =>
      normalize(link.textContent || "")
        .includes(
          normalize("اختيار شركة الصرافة")
        )
    ) || null;
  }

  function branchPriorityGroups() {
    return CBLBranchPriority.groups(settings,catalog);
  }
  function selectedTarget() {return branchPriorityGroups()[0] || null;}
  function targetNames() {return [...new Set(branchPriorityGroups().flatMap(item=>item.targets))];}
  function findBranchSelect() {return document.querySelector("#bank_branch");}
  function branchOptions(select) {
    return [...(select?.options || [])].filter(option=>String(option.value || "").trim() && String(option.textContent || "").trim());
  }
  function branchOptionEnabled(option) {
    return !option.disabled && !option.hidden && !option.parentElement?.disabled && option.getAttribute?.("aria-disabled") !== "true";
  }
  function branchSelectLoading(select) {
    return !select || select.disabled || select.getAttribute?.("aria-busy") === "true" ||
      select.getAttribute?.("data-loading") === "true" || !!select.closest?.('[aria-busy="true"],[data-loading="true"]');
  }
  function branchListSignature(select) {
    return JSON.stringify(branchOptions(select).map(option=>[option.value,option.textContent,branchOptionEnabled(option)]));
  }
  function branchListReadyForFallback(select) {
    if (!running || !settings.enabled || awaitingAutoConfirm || !companyIsConfirmed() || companyRequestPending() || branchSelectLoading(select)) {
      clearTimeout(branchListReadyTimer);branchListReadyTimer=null;branchListSnapshot=null;
      return false;
    }
    const signature=branchListSignature(select);
    if(branchListSnapshot?.select === select && branchListSnapshot.signature === signature) return branchListSnapshot.ready;
    clearTimeout(branchListReadyTimer);
    branchListSnapshot={select,signature,ready:false};
    // Primary options remain immediate. Only an absent primary needs a short
    // quiet list after the platform request is idle before taking a fallback.
    branchListReadyTimer=setTimeout(()=>{
      branchListReadyTimer=null;
      if(!running || !settings.enabled || awaitingAutoConfirm) return;
      if(findBranchSelect() !== select || branchListSignature(select) !== signature || companyRequestPending() || branchSelectLoading(select) || !companyIsConfirmed()) {
        branchListSnapshot=null;
        evaluateBranchFirst().catch(()=>{});
        return;
      }
      branchListSnapshot.ready=true;
      notifyCompanyStateChange();
      evaluateBranchFirst().catch(()=>{});
    },50);
    return false;
  }
  function findTargetOption(select) {
    const options=branchOptions(select).filter(branchOptionEnabled);
    const groups=branchPriorityGroups();
    for(let priority=0;priority<groups.length;priority++) {
      if(priority>0 && !branchListReadyForFallback(select)) return null;
      for(const targetName of groups[priority].targets) {
        const aliases=LIB.aliasesFor(targetName);
        const option=options.find(option=>aliases.includes(normalize(option.textContent || "")));
        if(option) return {option,targetName,branchId:groups[priority].id,priority};
      }
    }
    return null;
  }
  function verifySelectedBranch(select,targetName) {
    if(!select || select.disabled || !String(select.value || "").trim()) return false;
    const option=select.selectedOptions?.[0];
    return !!option && branchOptionEnabled(option) && LIB.aliasesFor(targetName).includes(normalize(option.textContent || ""));
  }
  function currentBranchIsCorrect() {
    const select=findBranchSelect();
    if(branchSelectLoading(select)) return false;
    if(branchSelected && selectedBranchTargetName) return verifySelectedBranch(select,selectedBranchTargetName);
    const groups=branchPriorityGroups();
    const priority=groups.findIndex(group=>group.targets.some(target=>verifySelectedBranch(select,target)));
    if(priority<0) return false;
    if(priority===0) return true;
    const available=findTargetOption(select);
    return !!available && available.priority===priority;
  }

  function companyFields() {
    const value = id =>
      String(
        document.querySelector(`#${id}`)
          ?.value || ""
      ).trim();

    return {
      company: value("company"),
      companyBranch: value("company_branch"),
      companyContract: value("company_contract")
    };
  }

  function isCardBooking() { return settings.bookingMode === "card"; }

  function companyResponseTimeout() {
    return Math.max(3, Math.min(30, Number(settings.companyResponseSeconds) || 8)) * 1000;
  }

  function bookingSelectionsReady() {
    if (!companyIsConfirmed()) return false;
    if (!isCardBooking()) return !branchCommitPending && currentBranchIsCorrect();
    // A visible cash-only field means the selected mode does not match this page.
    const branch = findBranchSelect();
    return !branch || getComputedStyle(branch).display === "none" ||
      getComputedStyle(branch).visibility === "hidden" || branch.getBoundingClientRect().height === 0;
  }

  function companyIsConfirmed() {
    const fields = companyFields();

    return Boolean(
      fields.company &&
      fields.companyContract &&
      (isCardBooking() || fields.companyBranch)
    );
  }

  function logCompanyFields(prefix = "") {
    if (!settings.diagnosticsEnabled) return;

    const fields = companyFields();

    log(
      "FIELD",
      `${prefix} company fields`,
      {
        company:
          fields.company
            ? "filled"
            : "empty",

        company_branch:
          fields.companyBranch
            ? "filled"
            : "empty",

        company_contract:
          fields.companyContract
            ? "filled"
            : "empty"
      }
    );
  }

  function canAttemptBranch() {
    return (
      settings.enabled &&
      running
    );
  }

  function turnstileSolved() {
    return Boolean(
      String(
        document.querySelector(
          '[name="cf-turnstile-response"]'
        )?.value || ""
      ).trim()
    );
  }

  function findConfirmButton() {
    const phrase = normalize("تأكيد الحجز");
    const candidates = [
      ...document.querySelectorAll(
        'button, input[type="submit"]'
      )
    ].filter(element => {
      const text = normalize(
        element.textContent || element.value || ""
      );
      if (!text.includes(phrase)) return false;
      if (!element.isConnected) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.display !== "none" &&
        style.visibility !== "hidden" &&
        rect.width > 0 && rect.height > 0;
    });

    return candidates.find(element =>
      !element.disabled &&
      element.getAttribute("aria-disabled") !== "true"
    ) || candidates[0] || null;
  }

  function installConfirmClickMonitor() {
    if (
      confirmClickMonitorAttached
    ) {
      return;
    }

    confirmClickMonitorAttached =
      true;

    document.addEventListener(
      "click",
      event => {
        let button = null;

        try {
          button =
            event.target?.closest?.(
              'button,input[type="submit"]'
            );
        } catch {}

        if (!button) {
          return;
        }

        const text =
          normalize(
            button.textContent ||
            button.value ||
            ""
          );

        if (
          !text.includes(
            normalize(
              "تأكيد الحجز"
            )
          )
        ) {
          return;
        }

        const automatic =
          button.dataset
            .cblAutoConfirm ===
          "1";

        if (!automatic && running && settings.enabled && !confirmClicked && !companyRequestPending() &&
            !button.disabled && button.getAttribute("aria-disabled") !== "true" &&
            bookingSelectionsReady() && companyIsConfirmed() && turnstileSolved()) {
          confirmClicked=true;
          awaitingAutoConfirm=false;
          queueMicrotask(()=>{
            emitBookingSound("confirm_submitted");
            chrome.runtime.sendMessage({type:"CONFIRM_SUBMITTED_WAIT_RESULT",branch:selectedBranchLabel}).catch(()=>{});
            clearEngine();
          });
        }

        log(
          "CONFIRM_CLICK",

          automatic
            ? "Automatic confirmation click detected"
            : "Manual confirmation click detected"
        );

        pageNotify(
          "confirm",
          "تم الضغط على تأكيد الحجز",

          automatic
            ? "تم تنفيذ الضغط التلقائي مرة واحدة."
            : "تم اكتشاف الضغط اليدوي على زر التأكيد.",

          true,
          7
        );
      },
      true
    );
  }

async function stopAfterBranch() {
    await diagnostic.flush();

    clearEngine();

    await chrome.runtime.sendMessage({
      type: "COMPLETE_BRANCH_AND_STOP",
      branch: selectedBranchLabel
    });
  }

  async function tryAutoConfirm() {
    if (
      !settings.enabled || !running ||
      !awaitingAutoConfirm ||
      companyRequestPending() ||
      branchCommitPending ||
      confirmClicked ||
      !settings.autoConfirm
    ) {
      return false;
    }

    if (
      !bookingSelectionsReady()
    ) {
      return false;
    }

    if (
      !companyIsConfirmed()
    ) {
      return false;
    }

    /*
     * لا يتم حل أو تجاوز Cloudflare.
     * ننتظر حل المستخدم له يدويًا.
     */
    if (
      !turnstileSolved()
    ) {
      return false;
    }

    const button =
      findConfirmButton();

    if (
      !button ||
      !button.isConnected
    ) {
      return false;
    }

    if (
      button.disabled ||
      button.getAttribute(
        "aria-disabled"
      ) === "true"
    ) {
      return false;
    }

    confirmClicked = true;

    button.dataset
      .cblAutoConfirm =
      "1";

    /*
     * ضغطة واحدة فقط.
     */
    button.click();
    log("CONFIRM","Company, branch and manual Cloudflare verification confirmed.");

    emitBookingSound("confirm_submitted");

    pageNotify(
      "confirm",
      "تم إرسال التأكيد",
      "بانتظار ظهور نتيجة الحجز من المنصة.",
      true,
      5
    );

    try {
      await chrome.runtime.sendMessage({
        type:
          "CONFIRM_SUBMITTED_WAIT_RESULT",

        branch:
          selectedBranchLabel
      });
    } catch {}

    clearEngine();

    return true;
  }

  function installConfirmObserver() {
    if (
      !settings.autoConfirm ||
      !awaitingAutoConfirm
    ) {
      return;
    }

    confirmObserver?.disconnect();
    if(!confirmSignalHandler) {
      confirmSignalHandler=()=>tryAutoConfirm().catch(()=>{});
      document.addEventListener("input",confirmSignalHandler,true);
      document.addEventListener("change",confirmSignalHandler,true);
      document.addEventListener("cbl:booking-state",confirmSignalHandler);
    }

    confirmObserver =
      new MutationObserver(() => {
        tryAutoConfirm().catch(() => {});
      });

    confirmObserver.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true,
        attributes: true
      }
    );

    if (confirmTimer) {
      clearInterval(confirmTimer);
    }

    /*
     * فحص DOM محلي فقط، وليس طلب شبكة.
     */
    confirmTimer =
      setInterval(() => {
        tryAutoConfirm().catch(() => {});
      }, 50);

    tryAutoConfirm().catch(() => {});
  }

  async function stopForManualBranch(
    reason =
      "تم اعتماد شركة الصرافة. اختر فرعًا آخر يدويًا."
  ) {
    branchFallbackMode =
      true;

    awaitingAutoConfirm =
      false;

    pageNotify(
      "warning",
      "اختر فرعًا آخر يدويًا",
      reason,
      true,
      10
    );

    log(
      "STOP",
      "Manual branch selection required",
      {
        reason
      }
    );

    clearEngine();

    try {
      await chrome.runtime.sendMessage({
        type:
          "MANUAL_BRANCH_REQUIRED_STOP",

        reason
      });
    } catch {}

    return true;
  }


  async function finalizeVerifiedBooking() {
    if(!bookingSelectionsReady() || companyRequestPending() || finalizingBooking || !running || !settings.enabled) return false;
    finalizingBooking=true;
    if(!isCardBooking()) emitBookingSound("branch_available");
    stopPreConfirmWork();
    if(settings.autoConfirm) {
      awaitingAutoConfirm=true;
      installConfirmObserver();
      if(confirmClicked) return true;
    }
    pageNotify("branch","تم التحقق من الاختيارات",isCardBooking() ? "تم اعتماد شركة الصرافة لحجز البطاقة." : `الشركة معتمدة والفرع ${selectedBranchLabel || "المطلوب"} صحيح.`,true,6);
    if(!settings.autoConfirm) {await stopAfterBranch();return true;}
    notify(isCardBooking() ? "الشركة جاهزة" : "تم اختيار الفرع",isCardBooking() ? "شركة الصرافة معتمدة — أكمل التحقق يدويًا." : `${selectedBranchLabel} — أكمل التحقق يدويًا.`,"branch");
    pageNotify("confirm","الحجز جاهز للتأكيد","بانتظار اكتمال التحقق وجاهزية زر التأكيد.",true,7);
    setRuntime("confirm",isCardBooking() ? "الشركة معتمدة. بانتظار التحقق لتأكيد البطاقة." : `تم اختيار ${selectedBranchLabel}. بانتظار إكمال التحقق.`,{nextRefreshAt:null,errorCode:"",errorDetails:null});
    return true;
  }

  async function ensureBranchAfterCompany(timeoutMs=900) {
    if(currentBranchIsCorrect() && !branchCommitPending) return finalizeVerifiedBooking();
    if(!branchSelectionInProgress) branchSelected=false;
    const token=companyFlowToken;
    const ready=await waitForBookingState(()=>{
      attachBranchSelect();
      if(branchCommitPending) return false;
      const select=findBranchSelect();
      return currentBranchIsCorrect() || !!(select && !select.disabled && findTargetOption(select));
    },timeoutMs,{token,checkEveryMs:50});
    if(ready && settings.enabled && running && token === companyFlowToken) {
      if(currentBranchIsCorrect()) return finalizeVerifiedBooking();
      if(await trySelectBranch()) return true;
    }
    if(!settings.enabled || !running || awaitingAutoConfirm || token !== companyFlowToken) return false;
    clearTimeout(refreshTimer);
    const seconds=Math.max(.5,Math.min(30,Number(settings.branchRefreshSeconds) || 2));
    if(settings.waitForTargetBranch) {
      pageNotify("warning","انتظار الفروع المطلوبة",`لا يوجد فرع متاح من الأولويات. تحديث بعد ${seconds} ثانية.`,false,Math.min(seconds,3));
      setRuntime("branch_wait",`انتظار أحد الفروع المطلوبة — تحديث بعد ${seconds} ثانية.`,{nextRefreshAt:Date.now()+seconds*1000});
      refreshTimer=setTimeout(()=>{
        if(!settings.enabled || !running || awaitingAutoConfirm) return;
        if(companyRequestPending()) {branchRefreshDeferred=true;return;}
        if(branchCommitPending) return;
        if(currentBranchIsCorrect()) {finalizeVerifiedBooking().catch(()=>{});return;}
        location.reload();
      },seconds*1000);
    } else {
      refreshTimer=null;
      pageNotify("branch","مراقبة الفروع","ستختار الإضافة أول فرع متاح حسب ترتيب الأولويات عند اكتمال القائمة.",false,4);
      setRuntime("branch_wait","شركة الصرافة معتمدة. انتظار أحد الفروع دون تحديث تلقائي.",{nextRefreshAt:null});
    }
    return false;
  }

  async function afterCompanyConfirmed(
    companyLabel = ""
  ) {
    if (
      !companyIsConfirmed()
    ) {
      return false;
    }

    emitBookingSound("company_selected");

    let displayName =
      companyLabel;

    if (
      companyLabel &&
      COMPANY_LIB
        ?.extractBaseName
    ) {
      displayName =
        COMPANY_LIB
          .extractBaseName(
            companyLabel
          );
    }

    pageNotify(
      "company",
      "تم اعتماد شركة الصرافة",

      displayName ||
      "تم تأكيد اختيار الشركة من المنصة.",

      true,
      6
    );

    if (isCardBooking()) {
      selectedBranchLabel = "";
      if (!bookingSelectionsReady()) {
        await reportError("BOOKING_MODE_MISMATCH", "هذه الصفحة تعرض فرع استلام الدولار. اختر وضع دولار كاش ثم أعد التشغيل.", {}, false);
        return false;
      }
      return finalizeVerifiedBooking();
    }
    return ensureBranchAfterCompany();
  }

  async function retryEditPageIfEnabled(message) {
    if (!settings.enabled || !running) return false;
    if (bookingSelectionsReady()) return finalizeVerifiedBooking();
    await refreshPlatformRequestState();
    if (companyRequestPending()) {
      holdCompanyRequest(companyFlowToken);
      return true;
    }
    if (!settings.waitForTargetBranch) return false;
    const seconds = Math.max(0.5, Math.min(30, Number(settings.branchRefreshSeconds) || 2));
    await setRuntime("branch_wait", `${message} تحديث صفحة التأكيد بعد ${seconds} ثانية.`,
      {nextRefreshAt:Date.now()+seconds*1000});
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      if (!settings.enabled || !running || awaitingAutoConfirm || companyRequestPending()) return;
      if (bookingSelectionsReady()) {
        finalizeVerifiedBooking().catch(() => {});
        return;
      }
      location.reload();
    }, seconds*1000);
    return true;
  }


  async function evaluateBranchFirst() {
    if (isCardBooking() || branchSelected || awaitingAutoConfirm || !settings.enabled) return false;
    const select = findBranchSelect();
    if (!select || select.disabled || !findTargetOption(select)) return false;
    branchFirstDecisionDone = true;
    return trySelectBranch();
  }

async function handleBranchSuccess(
    select,
    targetName
  ) {
    if (
      !verifySelectedBranch(
        select,
        targetName
      )
    ) {
      return false;
    }

    branchSelected =
      true;
    selectedBranchTargetName=targetName;

    branchFirstDecisionDone =
      true;

    selectedBranchLabel =
      String(
        select.selectedOptions?.[0]
          ?.textContent ||
        targetName
      )
        .trim()
        .replace(
          /\s+/g,
          " "
        );

    log(
      "BRANCH",
      "Branch selected and verified",
      {
        target:
          targetName,

        selected:
          selectedBranchLabel,

        companyConfirmed:
          companyIsConfirmed()
      }
    );

    pageNotify(
      "branch",
      "تم اختيار الفرع",
      `${selectedBranchLabel} — تم التحقق من القيمة.`,
      true,
      5
    );

    /*
     * إذا الشركة معتمدة أصلًا،
     * انتهى التحقق.
     */
    if (
      companyIsConfirmed()
    ) {
      return afterCompanyConfirmed();
    }

    /*
     * الفرع تم اختياره أولًا.
     * الآن نبدأ الشركة.
     */
    setRuntime(
      "company",
      `تم اختيار ${selectedBranchLabel}. جاري اختيار شركة الصرافة.`,
      {
        selectedBranch:
          selectedBranchLabel,

        errorCode:
          "",

        errorDetails:
          null
      }
    );

    // Do not restart a company request already in flight when the branch appears.
    if (!companyFlowStarted) companyFlow().catch(() => {});

    return true;
  }

  async function trySelectBranch() {
    if(isCardBooking() || branchSelected || branchSelectionInProgress || awaitingAutoConfirm || !canAttemptBranch()) return false;
    const select=findBranchSelect();
    if(branchSelectLoading(select)) return false;
    const match=findTargetOption(select);
    if(!match) return false;
    const {option,targetName,priority,branchId}=match;
    const attempt={};
    branchSelectionInProgress=true;branchCommitPending=true;branchSelectionToken=attempt;
    try {
      const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,"value")?.set;
      if(setter) setter.call(select,option.value);else select.value=option.value;
      select.dispatchEvent(new Event("input",{bubbles:true}));
      select.dispatchEvent(new Event("change",{bubbles:true}));
      // Let the platform's synchronous handlers and queued request work run.
      // Avoid requestAnimationFrame: it may stall in a background tab.
      await new Promise(resolve=>setTimeout(resolve,0));
      const verified=await waitForBookingState(()=>{
        const latest=findBranchSelect();
        return !companyRequestPending() && !branchSelectLoading(latest) && verifySelectedBranch(latest,targetName);
      },companyResponseTimeout(),{token:null,cancelled:()=>branchSelectionToken !== attempt,checkEveryMs:50});
      if(!verified || !running || !settings.enabled || branchSelectionToken !== attempt || awaitingAutoConfirm) return false;
      branchCommitPending=false;branchSelectionInProgress=false;
      selectedBranchLabel=String(findBranchSelect()?.selectedOptions?.[0]?.textContent || targetName).trim();
      log("BRANCH","Priority branch selected and platform state idle",{priority:priority+1,branchId,target:targetName});
      emitBookingSound("branch_available");
      return handleBranchSuccess(findBranchSelect(),targetName);
    } finally {
      if(branchSelectionToken === attempt) {branchCommitPending=false;branchSelectionInProgress=false;branchSelectionToken=null;}
    }
  }

  function attachBranchSelect() {
    const select =
      findBranchSelect();

    if (
      !select ||
      observedBranchSelect ===
        select
    ) {
      return;
    }

    branchObserver?.disconnect();

    observedBranchSelect =
      select;

    branchObserver =
      new MutationObserver(() => {
        // MutationObserver batches updates already; do not debounce ready options.
        evaluateBranchFirst().catch(() => {});
      });

    branchObserver.observe(
      select,
      {
        childList:
          true,

        subtree:
          true,
        characterData:true,
        attributes:
          true,

        attributeFilter: [
          "disabled",
          "value", "hidden", "aria-disabled", "aria-busy", "data-loading"
        ]
      }
    );

    select.addEventListener(
      "change",
      () => {
        evaluateBranchFirst()
          .catch(() => {});

        trySelectBranch()
          .catch(() => {});
      },
      true
    );

    log(
      "BRANCH",
      "#bank_branch observer attached"
    );

    evaluateBranchFirst()
      .catch(() => {});
  }

  function installBranchObserver() {
    attachBranchSelect();

    pageObserver?.disconnect();

    pageObserver =
      new MutationObserver(() => {
        attachBranchSelect();

        evaluateBranchFirst()
          .catch(() => {});

        trySelectBranch()
          .catch(() => {});
      });

    pageObserver.observe(
      document.documentElement,
      {
        childList:
          true,

        subtree:
          true,

        attributes:
          true,

        attributeFilter: [
          "disabled",
          "hidden", "aria-disabled", "aria-busy", "data-loading"
        ]
      }
    );
  }

  function scheduleBranchDiagnosis(
    delay = 3500
  ) {
    clearTimeout(
      branchErrorTimer
    );

    branchErrorTimer =
      setTimeout(
        async () => {
          if (
            branchSelected ||
            awaitingAutoConfirm ||
            !settings.enabled
          ) {
            return;
          }

          const select =
            findBranchSelect();

          if (
            select &&
            findTargetOption(select)
          ) {
            await trySelectBranch();
            return;
          }

          await reportError(
            "BRANCH_NOT_AVAILABLE",
            "الفرع المطلوب غير متوفر حاليًا.",
            {
              targets:
                targetNames(),

              selectFound:
                Boolean(select),

              disabled:
                Boolean(
                  select?.disabled
                ),

              optionCount:
                select
                  ? branchOptions(
                      select
                    ).length
                  : 0
            },
            true
          );
        },
        delay
      );
  }

  function actionText(element) {
    if (!element) return "";
    return element.getAttributeNames()
      .filter(name => /^(?:wire:click(?:\.|$)|x-on:click(?:\.|$)|@click(?:\.|$)|onclick$)/i.test(name))
      .map(name => element.getAttribute(name) || "").join(" ");
  }

  function isCompanyElement(element) {
    return /selectContract\s*\(/i
      .test(
        actionText(element)
      );
  }

  function isElementActionable(
    element
  ) {
    if (
      !element ||
      !element.isConnected
    ) {
      return false;
    }

    if (
      element.disabled ||
      element.getAttribute(
        "aria-disabled"
      ) === "true"
    ) {
      return false;
    }

    const style =
      getComputedStyle(
        element
      );

    if (
      style.display === "none" ||
      style.visibility === "hidden" ||
      style.pointerEvents === "none"
    ) {
      return false;
    }

    const rect =
      element
        .getBoundingClientRect();

    return (
      rect.width > 0 &&
      rect.height > 0
    );
  }

function actionContractId(element) {
    const match =
      actionText(element)
        .match(
          /selectContract\s*\(\s*["']?(\d+)["']?\s*\)/i
        );

    return match
      ? Number(match[1])
      : null;
  }

  function findCompanyTrigger() {
    const items = [
      ...document.querySelectorAll(
        'button,a,li,div,span,[role="button"]'
      )
    ];

    /*
     * الأولوية لعنصر لديه
     * openContractsSelect.
     */
    const direct =
      items.find(element =>
        isElementActionable(
          element
        ) &&
        /openContractsSelect/i
          .test(
            actionText(
              element
            )
          )
      );

    if (direct) {
      return direct;
    }

    const phrase =
      normalize(
        "اختيار شركة الصرافة"
      );

    const matches =
      items.filter(element => {
        if (
          !isElementActionable(
            element
          )
        ) {
          return false;
        }

        const text =
          normalize(
            element.textContent ||
            ""
          );

        return (
          text.includes(
            phrase
          ) &&
          text.length < 180
        );
      });

    /*
     * اختر أصغر عنصر نصيًا
     * لتجنب الضغط على container كبير.
     */
    matches.sort(
      (a, b) =>
        String(
          a.textContent || ""
        ).length -
        String(
          b.textContent || ""
        ).length
    );

    return matches[0] || null;
  }

  function companyItems() {
    const raw = [
      ...document.querySelectorAll(
        'button,a,li,div,span,[role="button"]'
      )
    ].filter(element =>
      isCompanyElement(
        element
      ) &&
      isElementActionable(
        element
      )
    );

    /*
     * إذا كان الأب والابن كلاهما
     * يحملان selectContract،
     * نفضّل العنصر الداخلي الأكثر تحديدًا.
     */
    return raw.filter(
      element =>
        !raw.some(
          other =>
            other !== element &&
            element.contains(
              other
            )
        )
    );
  }

  function findLivewireComponent() {
    return [
      ...document.querySelectorAll(
        '[wire\\:id][wire\\:snapshot]'
      )
    ].find(root => {
      const snapshot =
        root.getAttribute(
          "wire:snapshot"
        ) || "";

      return (
        snapshot.includes("contracts") ||
        snapshot.includes("selectedContract") ||
        snapshot.includes("selectContract")
      );
    }) || null;
  }

  function contractsFromSnapshot() {
    const root =
      findLivewireComponent();

    if (!root) {
      return {
        root: null,
        contracts: []
      };
    }

    try {
      const snapshot =
        JSON.parse(
          root.getAttribute(
            "wire:snapshot"
          ) || "{}"
        );

      const contracts = [];
      const seen = new Set();

      function walk(value) {
        if (
          !value ||
          typeof value !== "object"
        ) {
          return;
        }

        if (!Array.isArray(value)) {
          const id =
            value.contract_id ??
            value.contractId;

          const label =
            value.company_name ??
            value.companyName ??
            value.label ??
            value.name;

          if (
            id != null &&
            label
          ) {
            const key =
              String(id);

            if (!seen.has(key)) {
              seen.add(key);

              contracts.push({
                contractId: id,
                label:
                  String(label)
              });
            }
          }
        }

        for (
          const child of
          Object.values(value)
        ) {
          walk(child);
        }
      }

      walk(snapshot);

      return {
        root,
        contracts
      };

    } catch (error) {
      log(
        "LIVEWIRE",
        "Snapshot parse failed",
        {
          error:
            String(
              error?.message ||
              error
            )
        }
      );

      return {
        root,
        contracts: []
      };
    }
  }

  async function callLivewire(
    method,
    contractId = null
  ) {
    const { root } =
      contractsFromSnapshot();

    const componentId =
      root?.getAttribute(
        "wire:id"
      );

    if (!componentId) {
      log(
        "LIVEWIRE",
        "Component not found"
      );

      return false;
    }

    companyBridgePending++;
    try {
      const response = await chrome.runtime.sendMessage({type:"LIVEWIRE_ACTION",method,componentId,contractId});
      log("LIVEWIRE", `${method} result`, {ok:Boolean(response?.ok),error:response?.result?.error || ""});
      return Boolean(response?.ok);
    } finally { companyBridgePending--; notifyCompanyStateChange(); }
  }

  function companyRequestPending() {
    return platformRequestsPending > 0 || companyBridgePending > 0;
  }

  async function refreshPlatformRequestState() {
    try {
      const response = await chrome.runtime.sendMessage({type:"GET_PLATFORM_REQUEST_STATE"});
      if (response?.ok) platformRequestsPending = Math.max(0,Number(response.pending) || 0);
    } catch {}
    return platformRequestsPending;
  }

  function notifyCompanyStateChange() {
    document.dispatchEvent(new Event("cbl:booking-state"));
  }

  function observeCompanyState(check) {
    let active = true;
    const handle = () => { if (active) check(); };
    const observer = new MutationObserver(handle);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
      attributeFilter: ["value", "disabled", "aria-disabled", "aria-busy", "style", "class", "wire:snapshot", "wire:click", "wire:click.prevent"]
    });
    const events = ["input", "change", "cbl:booking-state"];
    for (const event of events) document.addEventListener(event, handle, true);
    return {
      disconnect() {
        active = false;
        observer.disconnect();
        for (const event of events) document.removeEventListener(event, handle, true);
      }
    };
  }

  async function waitForBookingState(predicate, timeoutMs, {
    token = companyFlowToken,
    cancelWhenConfirming = true,
    checkEveryMs = 0,
    cancelled = () => false
  } = {}) {
    return new Promise(resolve => {
      let observer = null, timer = null, fallback = null, finished = false;
      const finish = result => {
        if (finished) return;
        finished = true;
        observer?.disconnect();
        clearTimeout(timer);
        clearInterval(fallback);
        resolve(result);
      };
      const check = () => {
        if (finished) return;
        if (!settings.enabled || !running || (token !== null && token !== companyFlowToken) ||
            cancelled() || (cancelWhenConfirming && awaitingAutoConfirm)) return finish(false);
        if (predicate()) finish(true);
      };
      // Existing actionable state has no observer, frame or timer delay.
      check();
      if (finished) return;
      observer = observeCompanyState(check);
      if (Number.isFinite(timeoutMs)) timer = setTimeout(() => finish(false), Math.max(0, timeoutMs));
      // Some platform scripts assign hidden-input.value without a DOM event.
      if (checkEveryMs > 0) fallback = setInterval(check, checkEveryMs);
    });
  }

  async function waitForCompanyCondition(predicate, timeoutMs) {
    const started = performance.now();
    let matched = false;
    await waitForBookingState(() => {
      if (predicate()) { matched = true; return true; }
      // A timeout never grants permission to duplicate a request still in flight.
      return performance.now() - started >= timeoutMs && !companyRequestPending() &&
        performance.now() - platformLastCompletedAt >= 150;
    }, Math.max(timeoutMs, 30000), {checkEveryMs: 50});
    return matched;
  }

  function clearCompanyPendingWatcher() {
    companyPendingObserver?.disconnect();
    companyPendingObserver = null;
    clearInterval(companyPendingTimer);
    companyPendingTimer = null;
  }

  function holdCompanyRequest(token, label = "", resumeAttempt = 1) {
    clearCompanyPendingWatcher();
    setRuntime("company", "طلب الشركة ما زال جاريًا في المنصة. انتظار الرد دون تكرار النقر أو تحديث الصفحة.", {nextRefreshAt:null}).catch(() => {});
    const check = () => {
      if (!settings.enabled || !running || token !== companyFlowToken) { clearCompanyPendingWatcher(); return; }
      if (companyIsConfirmed()) {
        clearCompanyPendingWatcher();
        afterCompanyConfirmed(label).catch(() => {});
      } else if (!companyRequestPending()) {
        const remaining = 150 - (performance.now() - platformLastCompletedAt);
        if (remaining <= 0) {
          clearCompanyPendingWatcher();
          companyFlowStarted = false;
          companyFlow(resumeAttempt).catch(() => {});
        }
      }
    };
    companyPendingObserver = observeCompanyState(check);
    companyPendingTimer = setInterval(check, 50);
    check();
    return false;
  }

  async function waitForCompanyConfirmed(timeoutMs) {
    const confirmed = await waitForCompanyCondition(companyIsConfirmed, timeoutMs);
    logCompanyFields(confirmed ? "confirmed" : "timeout");
    return confirmed;
  }

  async function openCompanyList() {
    if (companyIsConfirmed() || companyItems().length) return true;
    if (companyListOpening) return companyListOpening;
    const token = companyFlowToken;
    const opening = (async () => {
      await refreshPlatformRequestState();
      if (!settings.enabled || !running || token !== companyFlowToken) return false;
      if (companyRequestPending()) {
        await waitForCompanyCondition(() => companyIsConfirmed() || companyItems().length || !companyRequestPending(), companyResponseTimeout());
      }
      if (!settings.enabled || !running || token !== companyFlowToken) return false;
      if (companyIsConfirmed() || companyItems().length) return true;
      if (companyRequestPending()) return false;
      const trigger = findCompanyTrigger();
      if (trigger) trigger.click();
      else callLivewire("openContractsSelect").catch(() => {});
      return waitForCompanyCondition(() => companyIsConfirmed() || companyItems().length > 0, companyResponseTimeout());
    })();
    companyListOpening = opening;
    try { return await opening; }
    finally { if (companyListOpening === opening) companyListOpening = null; }
  }

  async function collectCompanyCandidates(timeoutMs = 900) {
    const started = performance.now(), token = companyFlowToken;
    let candidates = [], announced = false;
    const active = () => settings.enabled && running && token === companyFlowToken && !awaitingAutoConfirm;
    const signature = list => list.map(item => COMPANY_LIB?.normalizeCompanyName
      ? COMPANY_LIB.normalizeCompanyName(item.label) : normalize(item.label)).join("|");
    const read = () => {
      const seen = new Set();
      candidates = [];
      for (const element of companyItems()) {
        const label = String(element.textContent || "").trim().replace(/\s+/g, " ");
        const key = COMPANY_LIB?.normalizeCompanyName ? COMPANY_LIB.normalizeCompanyName(label) : normalize(label);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        candidates.push({source: "dom", element, contractId: actionContractId(element), label});
      }
      if (candidates.length && !announced) { announced = true; emitBookingSound("company_options"); }
      return candidates;
    };
    const immediate = () => candidates.length &&
      ((settings.companyMode === "first_available" && !companyChoiceForRetry) ||
       (settings.companyMode === "specific" && chooseCompanyCandidate(candidates)));

    read();
    if (immediate()) return candidates;
    if (settings.companyMode === "specific" ||
        (settings.companyMode === "first_available" && !companyChoiceForRetry)) {
      // A requested row may arrive after the first partial list. Select it as soon as it exists.
      await waitForBookingState(() => { read(); return immediate(); }, timeoutMs, {token, checkEveryMs: 50});
    } else {
      while (active() && performance.now() - started < timeoutMs) {
        if (!candidates.length) {
          await waitForBookingState(() => read().length > 0, timeoutMs - (performance.now() - started), {token, checkEveryMs: 50});
          if (!active() || !candidates.length) break;
        }
        const previousSignature = signature(candidates);
        const changed = await waitForBookingState(() => {
          read();
          return signature(candidates) !== previousSignature;
        }, Math.min(15, timeoutMs - (performance.now() - started)), {token});
        // Preserve random-mode list stability without repeatedly polling the whole page.
        if (!changed && active()) return candidates;
      }
    }
    if (!active()) return [];
    if (candidates.length) return candidates;
    const snapshot = contractsFromSnapshot();
    return snapshot.contracts.map(contract => ({
      source: "snapshot", element: null, contractId: contract.contractId, label: contract.label
    }));
  }

  function chooseCompanyCandidate(
    candidates
  ) {
    if (
      settings.companyMode ===
      "specific"
    ) {
      return candidates.find(
        candidate =>
          COMPANY_LIB
            ?.namesEqual
            ? COMPANY_LIB
                .namesEqual(
                  candidate.label,
                  settings.companyName
                )
            : normalize(
                candidate.label
              ) ===
              normalize(
                settings.companyName
              )
      ) || null;
    }

    const actionable = candidates.filter(candidate =>
      !candidate.element || isElementActionable(candidate.element)
    );

    // Prefer the company confirmed for this request on the previous refresh.
    if (companyChoiceForRetry) {
      const previous = actionable.find(candidate =>
        COMPANY_LIB?.namesEqual
          ? COMPANY_LIB.namesEqual(candidate.label, companyChoiceForRetry)
          : normalize(candidate.label) === normalize(companyChoiceForRetry)
      );
      if (previous) return previous;
    }

    // تجاهل العدد المحدد من الشركات، ثم اختر من البقية إن وجدت.
    if (settings.companyMode === "random_from_5") {
      const skip = Math.max(0, Math.min(20, Math.floor(Number(settings.companySkipCount) || 0)));
      const pool = actionable.length > skip ? actionable.slice(skip) : actionable;
      if (!pool.length) return null;
      return pool[Math.floor(Math.random() * pool.length)] || null;
    }

    return actionable[0] || null;
  }

  async function resolveSnapshotCandidateToDom(candidate, timeoutMs = 2600) {
    if (candidate?.element && isElementActionable(candidate.element)) return candidate;
    const token = companyFlowToken;
    // Snapshot rows still resolve through the actual selectable DOM before any fallback.
    await openCompanyList();
    let match = null;
    await waitForBookingState(() => {
      if (companyIsConfirmed()) return true;
      match = companyItems().find(element => {
        const label = String(element.textContent || "").trim().replace(/\s+/g, " ");
        const sameName = COMPANY_LIB?.namesEqual
          ? COMPANY_LIB.namesEqual(label, candidate.label)
          : normalize(label) === normalize(candidate.label);
        const id = actionContractId(element);
        return sameName && (candidate.contractId == null || id == null || String(id) === String(candidate.contractId));
      });
      return Boolean(match);
    }, timeoutMs, {token, checkEveryMs: 50});
    if (!settings.enabled || !running || token !== companyFlowToken || !match) return {...candidate, element: null};
    return {
      ...candidate,
      source: "dom-resolved",
      element: match,
      contractId: actionContractId(match) ?? candidate.contractId,
      label: String(match.textContent || candidate.label).trim().replace(/\s+/g, " ")
    };
  }

  async function performCompanyCandidate(
    candidate,
    attemptNumber,
    token
  ) {
    if (
      !settings.enabled || token !==
      companyFlowToken
    ) {
      return false;
    }

    await refreshPlatformRequestState();
    if (companyRequestPending()) {
      await waitForCompanyCondition(() => companyIsConfirmed() || !companyRequestPending(),companyResponseTimeout());
    }
    if (!settings.enabled || !running || token !== companyFlowToken || companyRequestPending()) return false;
    if (companyIsConfirmed()) return true;
    candidate = await resolveSnapshotCandidateToDom(candidate);

    if (!settings.enabled || !running || token !== companyFlowToken) return false;
    if (companyIsConfirmed()) return true;
    if (companyRequestPending()) return false;

    log(
      "COMPANY",
      `Attempt ${attemptNumber}/${Math.max(1, Number(settings.companyAttempts) || 2)}`,
      {
        source:
          candidate.source,

        label:
          candidate.label,

        contractId:
          candidate.contractId
      }
    );

    /*
     * الأولوية دائمًا للنقر
     * الحقيقي في DOM.
     */
    if (
      candidate.element &&
      isElementActionable(
        candidate.element
      )
    ) {
      candidate.element.dataset
        .cblAutoCompanyClick =
        "1";

      candidate.element.click();

      log(
        "AUTO_CLICK",
        "Clicking actual company DOM element",
        {
          label:
            candidate.label,

          contractId:
            candidate.contractId
        }
      );

      setTimeout(() => {
        try {
          delete candidate
            .element
            .dataset
            .cblAutoCompanyClick;
        } catch {}
      }, 0);

      /*
       * سجل الموقع الحقيقي أظهر أن
       * الحقول قد تتأخر تحت الضغط.
       * ننتظر ضمن المهلة المحددة، ونخرج فور اعتمادها.
       * لا نكرر الطلب عبر Livewire فوق نقرة DOM معلقة.
       */
      if (
        await waitForCompanyConfirmed(
          companyResponseTimeout()
        )
      ) {
        return true;
      }
      return false;
    }

    if (
      !settings.enabled || token !==
      companyFlowToken
    ) {
      return false;
    }

    /*
     * contractId=null ليس فشلًا.
     *
     * Livewire fallback يستخدم فقط
     * عندما يتوفر Contract ID موثوق.
     */
    if (!settings.enabled || !running || token !== companyFlowToken || companyRequestPending()) return false;
    if (companyIsConfirmed()) return true;
    if (candidate.source === "snapshot" && candidate.contractId != null) {
      log(
        "COMPANY",
        "DOM click not adopted. Trying Livewire fallback for same company."
      );

      callLivewire("selectContract",candidate.contractId).catch(() => {});
      return waitForCompanyConfirmed(companyResponseTimeout());
    }

    return false;
  }

  async function companyFlow(startAttempt = 1) {
    if (
      companyFlowStarted ||
      awaitingAutoConfirm
    ) {
      return;
    }

    companyFlowStarted =
      true;

    const token =
      ++companyFlowToken;

    /*
     * الشركة معتمدة بالفعل.
     */
    if (
      companyIsConfirmed()
    ) {
      setRuntime(
        "branch",
        "شركة الصرافة معتمدة. إعادة التحقق من الفرع.",
        {nextRefreshAt:null}
      ).catch(() => {});

      await afterCompanyConfirmed();

      return;
    }

    /*
     * الاختيار اليدوي للشركة.
     */
    if (
      settings.companyMode ===
      "disabled"
    ) {
      log(
        "COMPANY",
        "Waiting for manual company selection"
      );

      pageNotify(
        "company",
        "اختيار الشركة يدوي",
        "اختر شركة الصرافة من الموقع. ستكتشف الإضافة اعتمادها تلقائيًا.",
        false,
        8
      );

      await setRuntime(
        "company",
        "اختر شركة الصرافة يدويًا من الموقع."
      );

      await waitForCompanyCondition(companyIsConfirmed, Number.POSITIVE_INFINITY);

      if (
        token ===
          companyFlowToken &&
        companyIsConfirmed()
      ) {
        await afterCompanyConfirmed(
          "اختيار يدوي"
        );
      }

      return;
    }

    /*
     * الشركة المحددة يجب أن يكون
     * لها اسم.
     */
    if (
      settings.companyMode ===
        "specific" &&
      !String(
        settings.companyName ||
        ""
      ).trim()
    ) {
      await reportError(
        "COMPANY_NAME_EMPTY",
        "لم يتم تحديد شركة الصرافة المطلوبة.",
        {},
        false
      );

      return;
    }

    setRuntime(
      "company",

      settings.companyMode ===
        "specific"
        ? `البحث عن شركة: ${settings.companyName}`
        : settings.companyMode === "random_from_5"
          ? "اختيار شركة عشوائيًا من الخامسة إلى الأخيرة."
          : "اختيار أول شركة صرافة متاحة.",
      {nextRefreshAt:null,errorCode:"",errorDetails:null}
    ).catch(() => {});

    const maximumAttempts =
      Math.max(
        1,
        Math.min(
          3,
          Number(
            settings.companyAttempts
          ) || 2
        )
      );

    let lastCandidateLabel = "";
    for (
      let attempt = startAttempt;
      attempt <=
        maximumAttempts;
      attempt++
    ) {
      if (!settings.enabled || !running || token !== companyFlowToken) return;
      if (companyIsConfirmed()) {
        await afterCompanyConfirmed(lastCandidateLabel);
        return;
      }

      companyAttemptsUsed =
        attempt;

      await openCompanyList();
      if (!settings.enabled || !running || token !== companyFlowToken) return;
      if (companyIsConfirmed()) { await afterCompanyConfirmed(lastCandidateLabel); return; }
      if (companyRequestPending()) return holdCompanyRequest(token,lastCandidateLabel,attempt);

      let candidates =
        await collectCompanyCandidates(
          900
        );


      log(
        "COMPANY",
        "Candidates detected",
        {
          count:
            candidates.length,

          labels:
            candidates
              .slice(0, 25)
              .map(item =>
                item.label
              )
        }
      );

      if (
        token !==
        companyFlowToken
      ) {
        return;
      }

      const candidate =
        chooseCompanyCandidate(
          candidates
        );

      if (!candidate) {
        if (!settings.enabled || !running || token !== companyFlowToken) return;
        if (companyIsConfirmed()) { await afterCompanyConfirmed(lastCandidateLabel); return; }
        if (companyRequestPending()) return holdCompanyRequest(token,lastCandidateLabel,attempt);
        if (attempt < maximumAttempts) { await sleep(150); continue; }
        if (await retryEditPageIfEnabled("لم تظهر شركة صرافة قابلة للاختيار بعد.")) return;
        await reportError(
          "COMPANY_NOT_FOUND",

          settings.companyMode ===
            "specific"
            ? "الشركة المحددة غير موجودة في القائمة الحالية."
            : "لم يتم العثور على شركة صرافة قابلة للاختيار.",

          {
            detected:
              candidates.length,

            attemptsUsed:
              companyAttemptsUsed,

            companyName:
              settings.companyMode ===
                "specific"
                ? settings.companyName
                : ""
          },

          false
        );

        return;
      }

      lastCandidateLabel = candidate.label;
      const success =
        await performCompanyCandidate(
          candidate,
          attempt,
          token
        );

      if (
        token !==
        companyFlowToken
      ) {
        return;
      }

      if (success || companyIsConfirmed()) {
        companyChoiceForRetry = candidate.label;
        log(
          "COMPANY",
          "Company confirmed successfully",
          {
            label:
              candidate.label
          }
        );

        let displayName =
          candidate.label;

        if (
          COMPANY_LIB
            ?.extractBaseName
        ) {
          displayName =
            COMPANY_LIB
              .extractBaseName(
                candidate.label
              );
        }

        notify(
          "تم اعتماد شركة الصرافة",
          displayName,
          "company"
        );

        setRuntime(
          "branch",
          "تم اعتماد شركة الصرافة. التحقق من الفرع.",
          {
            nextRefreshAt:null,
            selectedCompany:
              candidate.label,

            errorCode:
              "",

            errorDetails:
              null
          }
        ).catch(() => {});

        await afterCompanyConfirmed(candidate.label);

        return;
      }

      if (companyRequestPending()) return holdCompanyRequest(token,lastCandidateLabel,attempt+1);

      /*
       * لا نعيد استخدام عنصر DOM قديم.
       * المحاولة التالية تعيد فتح
       * واكتشاف القائمة من الصفر.
       */
      if (
        attempt <
        maximumAttempts
      ) {
        await sleep(
          attempt === 1
            ? 350
            : 650
        );
      }
    }

    if (!settings.enabled || !running || token !== companyFlowToken) return;
    if (companyIsConfirmed()) { await afterCompanyConfirmed(lastCandidateLabel); return; }
    if (companyRequestPending()) return holdCompanyRequest(token,lastCandidateLabel,maximumAttempts+1);
    if (!companyIsConfirmed()) {
      if (await retryEditPageIfEnabled("لم تثبت المنصة اختيار شركة الصرافة بعد.")) return;
      await reportError(
        "COMPANY_SELECTION_FAILED",
        "تعذر اعتماد شركة الصرافة.",
        {
          attemptsUsed:
            companyAttemptsUsed,

          reason:
            "تم استنفاد عدد المحاولات المحدد."
        },
        false
      );
    }
  }

  function companyElementFromClick(
    target
  ) {
    let node =
      target;

    while (
      node &&
      node !== document.body
    ) {
      if (
        isCompanyElement(node)
      ) {
        return node;
      }

      node =
        node.parentElement;
    }

    return null;
  }

  function attachPassiveDiagnostics() {
    if (
      diagnosticsListenerAttached
    ) {
      return;
    }

    diagnosticsListenerAttached =
      true;

    document.addEventListener(
      "click",
      event => {
        if (
          !settings.diagnosticsEnabled
        ) {
          return;
        }

        const companyElement =
          companyElementFromClick(
            event.target
          );

        if (!companyElement) {
          return;
        }

        const automatic =
          companyElement.dataset
            .cblAutoCompanyClick ===
          "1";

        log(
          automatic
            ? "AUTO_CLICK"
            : "MANUAL_CLICK",

          automatic
            ? "Automatic company click detected"
            : "Manual company click detected",

          {
            label:
              String(
                companyElement
                  .textContent ||
                ""
              )
                .trim()
                .replace(
                  /\s+/g,
                  " "
                ),

            contractId:
              actionContractId(
                companyElement
              )
          }
        );

        [50, 300, 1000]
          .forEach(delay => {
            setTimeout(
              () => {
                logCompanyFields(
                  `+${delay}ms`
                );
              },
              delay
            );
          });
      },
      true
    );
  }

  async function handleWaitingPage() {
    async function openIfFound() {
      const link =
        findEditLink();

      if (!link) {
        return false;
      }

      clearTimeout(
        refreshTimer
      );

      refreshTimer = null;

      pageObserver?.disconnect();
      pageObserver = null;

      log(
        "PAGE",
        "Exchange company option detected"
      );

      notify(
        "ظهر خيار شركة الصرافة",
        "سيتم فتح صفحة إكمال الحجز الآن.",
        "option"
      );
      link.click();

      emitBookingSound("company_options");

      return true;
    }

    if (
      await openIfFound()
    ) {
      return;
    }

    pageObserver =
      new MutationObserver(() => {
        openIfFound()
          .catch(() => {});
      });

    pageObserver.observe(
      document.documentElement,
      {
        childList: true,
        subtree: true
      }
    );

    refreshTimer =
      setTimeout(() => {
        if (
          !running ||
          branchSelected ||
          awaitingAutoConfirm
        ) {
          return;
        }

        log(
          "PAGE",
          "Reloading request page"
        );

        location.reload();

      }, settings.refreshSeconds * 1000);

    await setRuntime(
      "running",
      `مراقبة الخيار. تحديث الصفحة بعد ${settings.refreshSeconds} ثوانٍ.`,
      {
        nextRefreshAt:
          Date.now() +
          settings.refreshSeconds *
            1000,

        errorCode: "",
        errorDetails: null
      }
    );
  }

  async function handleEditPage() {
    installBookingSuccessWatcher();
    log("PAGE", "Completion page detected");

    notify(
      "صفحة إكمال الحجز",
      "تم فتح صفحة إكمال الحجز.",
      "page"
    );

    // The branch list may be empty until the platform accepts a company.
    installBranchObserver();
    await evaluateBranchFirst();
    if (!companyFlowStarted) companyFlow().catch(() => {});
  }

  async function recoverEngine() {
    await loadState();

    if (
      !settings.recoveryEnabled
    ) {
      return;
    }

    if (
      pageShowsRateLimit()
    ) {
      await chrome.runtime.sendMessage({
        type:
          "RATE_LIMIT_DETECTED"
      });

      return;
    }

    if (
      pageShowsExpiredSession()
    ) {
      await reportError(
        "SESSION_EXPIRED",
        "انتهت جلسة الدخول. سجل الدخول من جديد.",
        {},
        false
      );

      return;
    }

    log("RECOVERY", "Resuming company and branch monitoring");

    clearTimeout(
      refreshTimer
    );

    clearTimeout(
      branchErrorTimer
    );

    clearTimeout(
      branchDecisionTimer
    );

    refreshTimer =
      null;

    branchErrorTimer =
      null;

    branchDecisionTimer =
      null;

    pageObserver?.disconnect();
    branchObserver?.disconnect();

    pageObserver =
      null;

    branchObserver =
      null;

    observedBranchSelect =
      null;

    if (
      awaitingAutoConfirm
    ) {
      await setRuntime(
        "confirm",
        "تم التعافي. استعادة مراقبة التأكيد."
      );

      installConfirmObserver();

      return;
    }

    if (
      isEditPage()
    ) {
      branchFallbackMode =
        false;

      branchFirstDecisionDone =
        false;

      branchSelected = false;
      finalizingBooking = false;

      companyFlowStarted =
        false;

      installBranchObserver();

      await evaluateBranchFirst();
      if (!companyFlowStarted) companyFlow().catch(() => {});

      return;
    }

    if (
      isRequestPage()
    ) {
      await handleWaitingPage();

      return;
    }

    await reportError(
      "PAGE_NOT_SUPPORTED",
      "افتح صفحة الطلب أو صفحة إكمال الحجز.",
      {},
      false
    );
  }

  async function pauseForMouseInteraction() {
    if (mousePauseTriggered || !running || !settings.enabled || !settings.pauseOnMouseMove) return;
    mousePauseTriggered = true;
    clearEngine();
    pageNotify("info", "تم التحويل للوضع اليدوي", "تم إيقاف الأوامر الآلية بسبب حركة الماوس. أعد التشغيل من الإضافة للمتابعة.", false, 1.2);
    try {
      await chrome.runtime.sendMessage({ type: "MANUAL_TAKEOVER" });
    } catch {}
  }

  function installMousePause() {
    if (mousePauseListenerAttached) return;
    mousePauseListenerAttached = true;
    let previous = null;
    let observedToken = mouseSessionToken;
    document.addEventListener("mousemove", event => {
      if (observedToken !== mouseSessionToken) {
        observedToken = mouseSessionToken;
        previous = null;
      }
      if (!running || !settings.enabled || !settings.pauseOnMouseMove) {
        previous = null;
        return;
      }
      const point = {x: event.clientX, y: event.clientY};
      if (!previous) { previous = point; return; }
      const distance = Math.hypot(point.x - previous.x, point.y - previous.y);
      previous = point;
      const threshold = {low: 18, medium: 8, high: 3}[settings.mouseSensitivity] || 8;
      if (distance < threshold) return;
      pauseForMouseInteraction().catch(() => {});
    }, { passive: true, capture: true });
  }

  async function startEngine() {
    mouseSessionToken++;
    if (
      !await loadState()
    ) {
      return;
    }

    attachPassiveDiagnostics();
    installConfirmClickMonitor();
    installMousePause();
    mousePauseTriggered = false;

    if (normalize(document.body?.textContent || "").includes(normalize("صلاحيات غير كافية"))) {
      clearEngine();
      settings.enabled = false;
      await chrome.runtime.sendMessage({type:"PLATFORM_ACCESS_ERROR",status:403});
      return;
    }
    if (!settings.enabled) return;

    running = true;

    if (pageShowsRateLimit()) {
      await chrome.runtime.sendMessage({
        type: "RATE_LIMIT_DETECTED"
      });

      clearEngine();

      return;
    }

    if (pageShowsExpiredSession()) {
      await reportError(
        "SESSION_EXPIRED",
        "يبدو أن جلسة الدخول انتهت.",
        {},
        false
      );

      clearEngine();

      return;
    }

    if (isEditPage()) {
      await handleEditPage();
      return;
    }

    if (isRequestPage()) {
      await handleWaitingPage();
      return;
    }

    await setRuntime(
      "running",
      "افتح صفحة الطلب المطلوب."
    );
  }

  chrome.runtime.onMessage.addListener(
    (
      message,
      _sender,
      sendResponse
    ) => {
      if (typeof message?.type === "string" && message.type.startsWith("EVIDENCE_")) {
        return false;
      }
      (async () => {
        switch (message?.type) {
          case "START_BOOKING_ASSISTANT": {
            clearEngine();

            emitBookingSound.seen = new Set();

            companyFlowStarted = false;
            companyAttemptsUsed = 0;

            branchSelected = false;
            selectedBranchLabel = "";
            selectedBranchTargetName = "";

            awaitingAutoConfirm = false;
            confirmClicked = false;
            finalizingBooking = false;

            branchFallbackMode = false;
            branchFirstDecisionDone = false;

            await startEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "STOP_BOOKING_ASSISTANT": {
            clearEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "PAUSE_FOR_RATE_LIMIT": {
            clearEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "RESUME_AFTER_COOLDOWN": {
            location.reload();

            sendResponse({
              ok: true
            });

            break;
          }

          case "RECOVER_BOOKING_ASSISTANT": {
            await recoverEngine();

            sendResponse({
              ok: true
            });

            break;
          }

          case "PLATFORM_REQUEST_STATE": {
            platformRequestsPending=Math.max(0,Number(message.pending) || 0);
            if(message.status != null) platformLastCompletedAt=performance.now();
            if([401,403,419].includes(Number(message.status)) && running) {
              clearEngine();settings.enabled=false;
              await chrome.runtime.sendMessage({type:"PLATFORM_ACCESS_ERROR",status:Number(message.status)});
            } else if(Number(message.status) === 429) {
              clearEngine();
            } else {
              if(platformRequestsPending) {clearTimeout(branchListReadyTimer);branchListReadyTimer=null;branchListSnapshot=null;}
              notifyCompanyStateChange();
              if(!platformRequestsPending && running && !awaitingAutoConfirm) {
                evaluateBranchFirst().catch(()=>{});
                if(branchRefreshDeferred && companyIsConfirmed() && !branchCommitPending) {
                  branchRefreshDeferred=false;
                  ensureBranchAfterCompany(0).catch(()=>{});
                }
              }
              if(awaitingAutoConfirm && !companyRequestPending()) tryAutoConfirm().catch(()=>{});
            }
            sendResponse({ok:true});
            break;
          }

          case "DIAGNOSTIC_FLUSH": {
            await diagnostic.flush();
            sendResponse({ok:true});
            break;
          }

          case "DIAG_NETWORK_EVENT": {
            log(
              "NETWORK",
              "Platform request completed",
              message.event
            );

            sendResponse({
              ok: true
            });

            break;
          }

          default:
            sendResponse({
              ok: false,
              ignored: true
            });
        }
      })().catch(error => {
        try {
          sendResponse({
            ok: false,
            error:
              String(
                error?.message ||
                error
              )
          });
        } catch {}
      });

      return true;
    }
  );

  chrome.storage.onChanged.addListener(
    (changes, area) => {
      if (area !== "local") {
        return;
      }

      if (changes.bookingSettings) {
        const oldAutoConfirm = settings.autoConfirm;
        const oldBookingMode = settings.bookingMode;

        settings = {
          ...DEFAULT_SETTINGS,
          ...(changes.bookingSettings.newValue || {})
        };

        if (running && oldBookingMode !== settings.bookingMode) {
          clearEngine();
          chrome.runtime.sendMessage({type:"STOP_SESSION"}).catch(() => {});
          return;
        }

        if (running && !isCardBooking() && companyIsConfirmed() && !currentBranchIsCorrect() &&
            (settings.waitForTargetBranch !== changes.bookingSettings.oldValue?.waitForTargetBranch ||
             settings.branchRefreshSeconds !== changes.bookingSettings.oldValue?.branchRefreshSeconds)) {
          clearTimeout(refreshTimer);
          refreshTimer = null;
          ensureBranchAfterCompany(0).catch(() => {});
        }

        notifyCompanyStateChange();
        diagnostic.setEnabled(
          settings.diagnosticsEnabled
        );

        /*
         * إذا ألغى المستخدم التأكيد
         * التلقائي بعد اختيار الفرع،
         * توقف فورًا.
         */
        if (
          oldAutoConfirm &&
          !settings.autoConfirm &&
          awaitingAutoConfirm
        ) {
          awaitingAutoConfirm = false;

          stopAfterBranch()
            .catch(() => {});
        }
      }

      if (changes.branchCatalog) {
        catalog =
          Array.isArray(
            changes.branchCatalog.newValue
          )
            ? changes.branchCatalog.newValue
            : catalog;
        branchListSnapshot=null;
        notifyCompanyStateChange();
      }
    }
  );

  startEngine()
    .catch(console.error);

  function installBookingSuccessWatcher() {
    if (window.__CBL_SUCCESS_WATCHER__) return;
    window.__CBL_SUCCESS_WATCHER__ = true;
    let done = false;
    const check = async () => {
      if (done) return;
      const text = normalize(document.body?.innerText || "");
      if (!text.includes(normalize("يرجى التوجه الى الفرع"))) return;
      done = true;
      clearEngine();
      notify("تم تأكيد الحجز بنجاح", "يرجى التوجه إلى الفرع.", "booking_success");
      pageNotify("success", "✓ تم الحجز بنجاح", "يرجى التوجه إلى الفرع.", true, 8);
      await setRuntime("success", "تم تأكيد الحجز — يرجى التوجه إلى الفرع.", {nextRefreshAt:null,errorCode:"",errorDetails:null});
      observer.disconnect();
    };
    const observer = new MutationObserver(() => check().catch(()=>{}));
    observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
    check().catch(()=>{});
  }
})();
