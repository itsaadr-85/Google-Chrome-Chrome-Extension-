"use strict";

// Configuration only. Playback always goes through the background's live-page
// and quiet-mode checks; this module never creates audio or sends messages.
(() => {
  const toneNames = Object.freeze([
    "classic", "bell", "double", "rise", "soft", "pulse", "chime", "swift", "success",
    "spark", "wood", "beacon", "celebrate"
  ]);
  const toneSet = new Set(toneNames);
  const events = Object.freeze([
    "company_options", "company_selected", "branch_available", "confirm_submitted", "booking_success"
  ]);
  const defaults = Object.freeze({
    company_options: Object.freeze({ enabled: true, tone: "spark", volume: 80 }),
    company_selected: Object.freeze({ enabled: true, tone: "wood", volume: 80 }),
    branch_available: Object.freeze({ enabled: true, tone: "beacon", volume: 85 }),
    confirm_submitted: Object.freeze({ enabled: true, tone: "swift", volume: 75 }),
    booking_success: Object.freeze({ enabled: true, tone: "celebrate", volume: 90 })
  });
  const labels = Object.freeze({
    classic: "كلاسيكي", bell: "جرس", double: "مزدوج", rise: "صاعد", soft: "هادئ",
    pulse: "نبض", chime: "رنين", swift: "سريع", success: "نجاح",
    spark: "ومضة", wood: "نقرة", beacon: "إشارة", celebrate: "احتفال"
  });
  function normalizeEventSounds(input) {
    const source = input && typeof input === "object" && !Array.isArray(input) ? input : {};
    return Object.fromEntries(events.map(event => {
      const fallback = defaults[event];
      const value = source[event] && typeof source[event] === "object" && !Array.isArray(source[event]) ? source[event] : {};
      const volume = Number(value.volume);
      return [event, {
        enabled: typeof value.enabled === "boolean" ? value.enabled : fallback.enabled,
        tone: toneSet.has(value.tone) ? value.tone : fallback.tone,
        volume: value.volume != null && value.volume !== "" && Number.isFinite(volume)
          ? Math.round(Math.max(0, Math.min(100, volume))) : fallback.volume
      }];
    }));
  }
  function eventConfig(settings, event) {
    if (!events.includes(event) || settings?.sound === false || settings?.alertsMuted === true) return null;
    const config = normalizeEventSounds(settings?.eventSounds)[event];
    return config.enabled ? config : null;
  }
  function eventFromKind(kind) {
    return ({ option: "company_options", company: "company_selected", branch: "branch_available",
      booking_success: "booking_success", evidence_saved: "booking_success" })[kind] || null;
  }
  // The worker claims events after its permission/liveness checks, before
  // awaiting offscreen playback. Concurrent DOM/evidence reports sound once.
  const claimed = new Set();
  function claim(event, key = event, session = 0) {
    if (!events.includes(event)) return false;
    const id = `${session}:${event}:${String(key || event).slice(0, 128)}`;
    if (claimed.has(id)) return false;
    claimed.add(id);
    if (claimed.size > 128) claimed.delete(claimed.values().next().value);
    return true;
  }
  function resetClaims() { claimed.clear(); }
  globalThis.CBLBookAudio = Object.freeze({
    toneNames, labels, events, defaults, normalizeEventSounds, eventConfig, eventFromKind, claim, resetClaims
  });
})();
