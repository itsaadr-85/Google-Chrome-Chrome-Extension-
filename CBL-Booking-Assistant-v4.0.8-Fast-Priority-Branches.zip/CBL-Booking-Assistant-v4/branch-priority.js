"use strict";
(() => {
  const DEFAULT_ID="pair-tobruk-musaid";
  const cleanId=value=>typeof value === "string" ? value.trim().slice(0,160) : "";
  function normalize(settings={}) {
    const selectedBranchId=cleanId(settings.selectedBranchId) || DEFAULT_ID;
    const orderedIds=[selectedBranchId];
    for (const value of Array.isArray(settings.alternateBranchIds) ? settings.alternateBranchIds : []) {
      const id=cleanId(value);
      if(id && !orderedIds.includes(id)) orderedIds.push(id);
      if(orderedIds.length===3) break;
    }
    return {selectedBranchId,alternateBranchIds:orderedIds.slice(1),orderedIds};
  }
  function groups(settings,catalog=[]) {
    return normalize(settings).orderedIds.map(id=>{
      const item=catalog.find(item=>item.id === id);
      if(!item) return id === DEFAULT_ID ? {id,name:"طبرق أو امساعد",targets:["طبرق","امساعد"]} : {id,name:"",targets:[]};
      return {id,name:String(item.name || ""),targets:Array.isArray(item.targets) && item.targets.length ? item.targets : [item.name]};
    });
  }
  globalThis.CBLBranchPriority=Object.freeze({DEFAULT_ID,normalize,groups});
})();
