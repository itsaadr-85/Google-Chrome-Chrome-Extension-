"use strict";

importScripts("branch-data.js");
importScripts("evidence-background.js");

const PLATFORM_PATTERN = "https://fcms.cbl.gov.ly/*";
const COOLDOWN_ALARM = "cbl-v3-cooldown";

const COMPANY_MODES = new Set(["first_available", "random_from_5", "specific", "disabled"]);
const SOUND_TONES = new Set(["classic", "bell", "double", "rise", "soft", "pulse", "chime", "swift", "success"]);

const DEFAULT_SETTINGS = Object.freeze({
  enabled: false,
  bookingMode: "cash",
  companyResponseSeconds: 8,
  refreshSeconds: 5,
  selectedBranchId: "pair-tobruk-musaid",

  companyMode: "first_available",
  companyName: "",
  companyAttempts: 2,
  companySkipCount: 5,

  diagnosticsEnabled: false,
  recoveryEnabled: true,

  notifications: true,
  sound: true,
  soundTone: "bell",

  autoConfirm: true,
  autoResumeAfterRateLimit: true,

  pageNotifications: true,
  notificationPosition: "top-center",
  notificationDuration: 5,
  notificationCountdown: true,
  notificationPageBorder: true,
  pauseOnMouseMove: false,
  mouseSensitivity: "medium",
  performanceMode: true,
  waitForTargetBranch: true,
  branchRefreshSeconds: 2,
  notificationOpacity: 88,
  glassTheme: "midnight"
});

const DEFAULT_RUNTIME = Object.freeze({
  phase: "idle",
  message: "جاهز للتشغيل.",
  ownerTabId: null,

  startedAt: null,
  nextRefreshAt: null,

  cooldownUntil: null,
  rateLimitCount: 0,

  selectedBranch: "",
  selectedCompany: "",

  errorCode: "",
  errorDetails: null,

  updatedAt: 0
});

let creatingOffscreen = null;

// Metadata only: never read request bodies, cookies or authentication values.
const platformRequests = new Map();
const requestRestoreDeleted = new Set();
const requestRestoreClosedTabs = new Set();
let requestStateRestored = false;
let requestSaveQueue = Promise.resolve();
const requestStateInitialization = (async () => {
  const stored = await chrome.storage.session?.get("cblPendingPlatformRequests");
  for (const entry of stored?.cblPendingPlatformRequests || []) {
    if (!Array.isArray(entry) || entry.length !== 2) continue;
    const [requestId,tabId] = entry;
    if (typeof requestId !== "string" || !Number.isInteger(tabId) || tabId < 0) continue;
    if (!requestRestoreDeleted.has(requestId) && !requestRestoreClosedTabs.has(tabId) && !platformRequests.has(requestId)) {
      platformRequests.set(requestId,tabId);
    }
  }
})().catch(console.error).finally(() => {
  requestStateRestored = true;
  requestRestoreDeleted.clear();
  requestRestoreClosedTabs.clear();
});
function savePlatformRequests() {
  requestSaveQueue = requestSaveQueue.then(async () => {
    await requestStateInitialization;
    await chrome.storage.session?.set({cblPendingPlatformRequests:[...platformRequests.entries()]});
  }).catch(console.error);
  return requestSaveQueue;
}

function platformRequestCount(tabId) {
  return [...platformRequests.values()].filter(id => id === tabId).length;
}
function isPlatformLivewireRequest(details) {
  try {
    const url = new URL(details.url);
    return url.protocol === "https:" && details.tabId >= 0 && details.method === "POST" &&
      url.hostname === "fcms.cbl.gov.ly" && /\/livewire(?:\/|$)/i.test(url.pathname);
  } catch { return false; }
}
function sendPlatformRequestState(tabId, status = null) {
  const send = () => broadcast(tabId, {type:"PLATFORM_REQUEST_STATE",pending:platformRequestCount(tabId),status}).catch(() => {});
  if (requestStateRestored) send();
  else requestStateInitialization.then(send);
}
function completePlatformRequest(details) {
  if (!platformRequests.has(details.requestId)) {
    if (!requestStateRestored && isPlatformLivewireRequest(details)) {
      requestRestoreDeleted.add(details.requestId);
      sendPlatformRequestState(details.tabId,details.statusCode ?? null);
      savePlatformRequests();
    }
    return;
  }
  const tabId = platformRequests.get(details.requestId);
  platformRequests.delete(details.requestId);
  if (!requestStateRestored) requestRestoreDeleted.add(details.requestId);
  sendPlatformRequestState(tabId, details.statusCode ?? null);
  savePlatformRequests();
}

function normalizeSettings(input = {}) {
  return {
    ...DEFAULT_SETTINGS,
    ...input,

    refreshSeconds: Number.isFinite(Number(input.refreshSeconds))
      ? Math.round(Math.max(0.5, Math.min(30, Number(input.refreshSeconds))) * 10) / 10
      : 5,

    branchRefreshSeconds: Number.isFinite(Number(input.branchRefreshSeconds))
      ? Math.round(Math.max(0.5, Math.min(30, Number(input.branchRefreshSeconds))) * 10) / 10
      : 2,

    bookingMode: input.bookingMode === "card" ? "card" : "cash",
    companyResponseSeconds: Math.max(3, Math.min(30, Number(input.companyResponseSeconds) || 8)),

    companyMode: COMPANY_MODES.has(input.companyMode)
      ? input.companyMode
      : "first_available",

    companyAttempts: Math.max(1, Math.min(3, Number(input.companyAttempts) || 1)),
    companySkipCount: Math.max(0, Math.min(20,
      Math.floor(input.companySkipCount == null ? 5 : Number(input.companySkipCount) || 0))),
    mouseSensitivity: ["low", "medium", "high"].includes(input.mouseSensitivity)
      ? input.mouseSensitivity : "medium",

    soundTone: SOUND_TONES.has(input.soundTone)
      ? input.soundTone
      : "bell"
  };
}

async function ensureCatalog() {
  const stored = await chrome.storage.local.get("branchCatalog");

  if (Array.isArray(stored.branchCatalog) && stored.branchCatalog.length) {
    return stored.branchCatalog;
  }

  const catalog = CBL_BRANCH_LIBRARY.createDefaultCatalog();

  await chrome.storage.local.set({
    branchCatalog: catalog
  });

  return catalog;
}

async function getState() {
  const stored = await chrome.storage.local.get([
    "bookingSettings",
    "bookingRuntime"
  ]);

  return {
    settings: normalizeSettings(stored.bookingSettings || {}),

    runtime: {
      ...DEFAULT_RUNTIME,
      ...(stored.bookingRuntime || {})
    },

    catalog: await ensureCatalog()
  };
}

async function saveState(settings, runtime) {
  await chrome.storage.local.set({
    bookingSettings: normalizeSettings(settings),

    bookingRuntime: {
      ...DEFAULT_RUNTIME,
      ...runtime,
      updatedAt: Date.now()
    }
  });
}

async function initializeState() {
  await ensureCatalog();

  const { settings, runtime } = await getState();
  const migration = await chrome.storage.local.get("cblBranchFlowV362Migrated");
  // This requested trial enables confirmation once; the setting remains editable.
  if (!migration.cblBranchFlowV362Migrated) {
    await saveState(settings, runtime);
    await chrome.storage.local.set({cblBranchFlowV362Migrated:true});
  } else {
    await saveState(settings, runtime);
  }
}

async function updateBadge(phase) {
  const map = {
    running: ["●", "#15803d"],
    opening: ["↗", "#2563eb"],
    company: ["C", "#7c3aed"],
    branch: ["B", "#0f766e"],
    branch_wait: ["B", "#b45309"],
    confirm: ["✓", "#7c3aed"],
    confirm_pending: ["…", "#7c3aed"],
    branch_selected: ["B", "#0f766e"],
    success: ["✓", "#15803d"],
    cooldown: ["Ⅱ", "#b45309"],
    error: ["!", "#b91c1c"],
    manual: ["M", "#2563eb"]
  };

  const [text, color] = map[phase] || ["", "#64748b"];

  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
}

async function ensureOffscreen() {
  if (!chrome.offscreen) return false;

  if (
    typeof chrome.offscreen.hasDocument === "function" &&
    await chrome.offscreen.hasDocument()
  ) {
    return true;
  }

  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "تشغيل تنبيهات مساعد الحجز."
    }).finally(() => {
      creatingOffscreen = null;
    });
  }

  await creatingOffscreen;

  return true;
}

async function playSound(kind = "alert", toneOverride = "") {
  try {
    if (!await ensureOffscreen()) return;

    const { settings } = await getState();

    let tone = SOUND_TONES.has(toneOverride)
      ? toneOverride
      : settings.soundTone;

    if (kind === "stop") { tone = "double"; }
    if (kind === "booking_success") { tone = "success"; }

    await chrome.runtime.sendMessage({
      target: "offscreen",
      type: "PLAY_SOUND",
      kind,
      tone
    });
  } catch {}
}

async function notify(title, message, kind = "alert") {
  const { settings } = await getState();

  if (settings.notifications) {
    try {
      await chrome.notifications.create(`cbl-${Date.now()}`, {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon128.png"),
        title,
        message,
        priority: 2
      });
    } catch {}
  }

  if (settings.sound) {
    await playSound(kind);
  }
}

async function broadcast(tabId, message) {
  if (!Number.isInteger(tabId)) return false;

  try {
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch {
    return false;
  }
}

async function stopSession(
  reason = "تم إيقاف الإضافة.",
  phase = "idle",
  options = {}
) {
  const {
    notifyUser = false,
    kind = "stop",
    branch = "",
    broadcastStop = true
  } = options;

  const { settings, runtime } = await getState();
  const tabId = runtime.ownerTabId;

  await chrome.alarms.clear(COOLDOWN_ALARM);

  await saveState(
    {
      ...settings,
      enabled: false
    },
    {
      ...runtime,
      phase,
      message: reason,
      ownerTabId: null,
      nextRefreshAt: null,
      cooldownUntil: null,
      selectedBranch: branch || runtime.selectedBranch,
      errorCode: "",
      errorDetails: null
    }
  );

  await updateBadge(phase);

  if (broadcastStop) {
    await broadcast(tabId, {
      type: "STOP_BOOKING_ASSISTANT",
      reason
    });
  }

  if (notifyUser) {
    await notify(
      phase === "success"
        ? "اكتملت مهمة مساعد الحجز"
        : "تم إيقاف مساعد الحجز",
      reason,
      kind
    );
  }
}

function defaultCooldown(attempt) {
  const values = [
    15 * 60 * 1000,
    30 * 60 * 1000,
    60 * 60 * 1000
  ];

  return values[Math.min(Math.max(attempt - 1, 0), values.length - 1)];
}

function retryAfterMilliseconds(headers) {
  if (!Array.isArray(headers)) return null;

  const header = headers.find(item =>
    String(item.name || "").toLowerCase() === "retry-after"
  );

  if (!header?.value) return null;

  const value = String(header.value).trim();
  const seconds = Number(value);

  if (Number.isFinite(seconds) && seconds >= 0) {
    return seconds * 1000;
  }

  const date = Date.parse(value);

  return Number.isFinite(date)
    ? Math.max(0, date - Date.now())
    : null;
}

async function handleRateLimit(tabId, retryAfterMs = null) {
  const { settings, runtime } = await getState();

  if (!settings.enabled) return;

  if (
    Number.isInteger(runtime.ownerTabId) &&
    Number.isInteger(tabId) &&
    runtime.ownerTabId !== tabId
  ) {
    return;
  }

  const count = Number(runtime.rateLimitCount || 0) + 1;

  if (!settings.autoResumeAfterRateLimit || count > 3) {
    await stopSession(
      "تكرر HTTP 429. تم إيقاف الإضافة لحماية الجلسة.",
      "error",
      {
        notifyUser: true,
        kind: "warning"
      }
    );

    return;
  }

  const duration = Number.isFinite(retryAfterMs)
    ? Math.max(1000, retryAfterMs)
    : defaultCooldown(count);

  const until = Date.now() + duration;

  await saveState(settings, {
    ...runtime,
    phase: "cooldown",
    message: "HTTP 429 — انتظار آمن قبل الاستئناف.",
    cooldownUntil: until,
    nextRefreshAt: null,
    rateLimitCount: count,

    errorCode: "HTTP_429",

    errorDetails: {
      recoverable: false,
      reason: "يجب انتظار مهلة حماية المنصة."
    }
  });

  await chrome.alarms.create(COOLDOWN_ALARM, {
    when: until
  });

  await updateBadge("cooldown");

  await broadcast(runtime.ownerTabId, {
    type: "PAUSE_FOR_RATE_LIMIT",
    cooldownUntil: until
  });

  await notify(
    "توقف آمن",
    "تم اكتشاف HTTP 429 وسيتم انتظار المهلة.",
    "warning"
  );
}

async function resumeAfterCooldown() {
  const { settings, runtime } = await getState();

  if (!settings.enabled || runtime.phase !== "cooldown") {
    return;
  }

  await saveState(settings, {
    ...runtime,
    phase: "running",
    message: "انتهت مهلة التوقف. استئناف المراقبة.",
    cooldownUntil: null,
    nextRefreshAt: Date.now() + settings.refreshSeconds * 1000,
    errorCode: "",
    errorDetails: null
  });

  await updateBadge("running");

  await broadcast(runtime.ownerTabId, {
    type: "RESUME_AFTER_COOLDOWN"
  });
}

async function runLivewireAction(
  tabId,
  { method, componentId, contractId }
) {
  if (
    !Number.isInteger(tabId) ||
    !["openContractsSelect", "selectContract"].includes(method)
  ) {
    return {
      ok: false,
      error: "Invalid Livewire action"
    };
  }

  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",

    func: async (componentIdArg, methodArg, contractIdArg) => {
      try {
        const livewire = window.Livewire;
        const component = livewire?.find?.(componentIdArg);

        if (!component) {
          return {
            ok: false,
            error: "Livewire component not found"
          };
        }

        const wire = component.$wire || component;

        let result;

        if (typeof wire?.[methodArg] === "function") {
          result = methodArg === "selectContract"
            ? wire[methodArg](Number(contractIdArg))
            : wire[methodArg]();

        } else if (typeof component.call === "function") {
          result = methodArg === "selectContract"
            ? component.call(methodArg, Number(contractIdArg))
            : component.call(methodArg);

        } else if (typeof wire?.call === "function") {
          result = methodArg === "selectContract"
            ? wire.call(methodArg, Number(contractIdArg))
            : wire.call(methodArg);

        } else {
          return {
            ok: false,
            error: "Livewire method unavailable"
          };
        }

        await Promise.resolve(result);

        return { ok: true };

      } catch (error) {
        return {
          ok: false,
          error: String(error?.message || error)
        };
      }
    },

    args: [
      componentId,
      method,
      contractId
    ]
  });

  return results?.[0]?.result || {
    ok: false,
    error: "No Livewire result"
  };
}

chrome.runtime.onInstalled.addListener(() => {
  stateInitialization.catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  stateInitialization.catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") {
    return false;
  }

  // The evidence module owns its messages and replies separately.
  if (typeof message?.type === "string" && message.type.startsWith("EVIDENCE_")) {
    return false;
  }

  (async () => {
    await stateInitialization;
    await requestStateInitialization;
    switch (message?.type) {
      case "GET_STATE": {
        sendResponse({
          ok: true,
          platformRequestsPending: platformRequestCount(sender.tab?.id),
          ...(await getState()),
          tabId: sender.tab?.id ?? null
        });
        break;
      }

      case "START_SESSION": {
        const tabId = Number.isInteger(message.tabId)
          ? message.tabId
          : sender.tab?.id;

        const settings = normalizeSettings({
          ...message.settings,
          enabled: true
        });

        const runtime = {
          ...DEFAULT_RUNTIME,
          phase: "running",
          message: "بدأت مراقبة الطلب.",
          ownerTabId: tabId,
          startedAt: Date.now(),
          nextRefreshAt: Date.now() + settings.refreshSeconds * 1000
        };

        await chrome.alarms.clear(COOLDOWN_ALARM);
        await saveState(settings, runtime);
        await updateBadge("running");

        sendResponse({
          ok: true,
          settings,
          runtime
        });

        break;
      }

      case "STOP_SESSION": {
        await stopSession(
          "تم إيقاف المراقبة يدويًا.",
          "idle"
        );

        sendResponse({ ok: true });
        break;
      }

      case "MANUAL_TAKEOVER": {
        await stopSession("تم الإيقاف بسبب حركة الماوس.", "manual", {broadcastStop:false});
        sendResponse({ok:true});
        break;
      }

      case "COMPLETE_BRANCH_AND_STOP": {
        const branch = String(message.branch || "").trim();

        await stopSession(
          branch ? `تم اختيار الفرع: ${branch}. أكمل تأكيد الحجز يدويًا.` : "تم اعتماد شركة الصرافة. أكمل تأكيد حجز البطاقة يدويًا.",
          "branch_selected",
          {
            notifyUser: true,
            kind: "stop",
            branch
          }
        );

        sendResponse({ ok: true });
        break;
      }

      case "CONFIRM_SUBMITTED_WAIT_RESULT": {
        const branch = String(message.branch || "").trim();

        if ((await getState()).runtime.phase === "success") {
          sendResponse({ok:true});
          break;
        }

        await stopSession(
          "تم الضغط على تأكيد الحجز مرة واحدة؛ بانتظار نتيجة المنصة.",
          "confirm_pending",
          {
            notifyUser: false,
            branch,
            broadcastStop: false
          }
        );

        sendResponse({ ok: true });
        break;
      }

      case "MANUAL_BRANCH_REQUIRED_STOP": {
        const reason =
          String(
            message.reason ||
            "تم اعتماد شركة الصرافة. اختر فرعًا آخر يدويًا."
          );

        await stopSession(
          reason,
          "idle",
          {
            notifyUser: true,
            kind: "warning",
            broadcastStop: false
          }
        );

        sendResponse({
          ok: true
        });

        break;
      }


      case "GET_PLATFORM_REQUEST_STATE": {
        sendResponse({ok:true,pending:platformRequestCount(sender.tab?.id)});
        break;
      }

      case "PLATFORM_ACCESS_ERROR": {
        const status = Number(message.status);
        if (![401,403,419].includes(status)) { sendResponse({ok:false}); break; }
        const {runtime} = await getState();
        if (Number.isInteger(runtime.ownerTabId) && sender.tab?.id !== runtime.ownerTabId) {
          sendResponse({ok:false}); break;
        }
        await stopSession(status === 403 ? "رفضت المنصة الوصول (403 — صلاحيات غير كافية). تحقق من حالة الطلب وصلاحية الحساب في المنصة." : "انتهت جلسة المنصة أو رفضت التحقق من الجلسة. سجل الدخول من جديد.", "error", {notifyUser:true,kind:"warning"});
        sendResponse({ok:true});
        break;
      }

      case "SET_RUNTIME": {
        const { settings, runtime } = await getState();

        const nextRuntime = {
          ...runtime,
          ...(message.patch || {})
        };

        await saveState(settings, nextRuntime);
        await updateBadge(nextRuntime.phase);

        sendResponse({ ok: true });
        break;
      }

      case "NOTIFY": {
        await notify(
          message.title || "مساعد الحجز",
          message.message || "يوجد تحديث.",
          message.kind || "alert"
        );

        sendResponse({ ok: true });
        break;
      }

      case "PREVIEW_SOUND": {
        await playSound(
          "preview",
          SOUND_TONES.has(message.tone)
            ? message.tone
            : "bell"
        );

        sendResponse({ ok: true });
        break;
      }

      case "LIVEWIRE_ACTION": {
        const result = await runLivewireAction(
          sender.tab?.id,
          {
            method: String(message.method || ""),
            componentId: String(message.componentId || ""),
            contractId: message.contractId
          }
        );

        sendResponse({
          ok: result.ok,
          result
        });

        break;
      }

      case "RATE_LIMIT_DETECTED": {
        await handleRateLimit(sender.tab?.id);
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({
          ok: false,
          ignored: true
        });
    }

  })().catch(error => {
    console.error("CBL background error", error);

    try {
      sendResponse({
        ok: false,
        error: String(error?.message || error)
      });
    } catch {}
  });

  return true;
});

chrome.commands.onCommand.addListener(command => {
  if (command !== "stop-booking-assistant") {
    return;
  }

  stopSession(
    "تم الإيقاف الفوري بواسطة Ctrl+Shift+X.",
    "idle",
    {
      notifyUser: true,
      kind: "stop"
    }
  ).catch(console.error);
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === COOLDOWN_ALARM) {
    resumeAfterCooldown().catch(console.error);
  }
});

chrome.webRequest.onBeforeRequest.addListener(details => {
  if (!isPlatformLivewireRequest(details)) return;
  platformRequests.set(details.requestId, details.tabId);
  requestRestoreDeleted.delete(details.requestId);
  sendPlatformRequestState(details.tabId);
  savePlatformRequests();
}, {urls:[PLATFORM_PATTERN]});

chrome.webRequest.onErrorOccurred.addListener(details => {
  completePlatformRequest(details);
}, {urls:[PLATFORM_PATTERN]});

chrome.tabs.onRemoved.addListener(tabId => {
  if (!requestStateRestored) requestRestoreClosedTabs.add(tabId);
  for (const [requestId,id] of platformRequests) if (id === tabId) {
    platformRequests.delete(requestId);
    if (!requestStateRestored) requestRestoreDeleted.add(requestId);
  }
  savePlatformRequests();
});

chrome.webRequest.onCompleted.addListener(
  async details => {
    if (details.tabId < 0) return;
    completePlatformRequest(details);
    await stateInitialization;

    if (details.statusCode === 429) {
      await handleRateLimit(
        details.tabId,
        retryAfterMilliseconds(details.responseHeaders)
      );
    }

    const { settings } = await getState();

    if (!settings.diagnosticsEnabled) return;

    let pathname = "";

    try {
      pathname = new URL(details.url).pathname;
    } catch {}

    if (
      !pathname.includes("livewire") &&
      details.statusCode < 400
    ) {
      return;
    }

    await broadcast(details.tabId, {
      type: "DIAG_NETWORK_EVENT",
      event: {
        status: details.statusCode,
        method: details.method,
        path: pathname
      }
    });
  },
  {
    urls: [PLATFORM_PATTERN]
  },
  ["responseHeaders"]
);

const stateInitialization = initializeState().catch(console.error);
