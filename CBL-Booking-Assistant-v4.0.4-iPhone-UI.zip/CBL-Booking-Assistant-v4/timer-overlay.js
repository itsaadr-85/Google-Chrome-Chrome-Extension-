"use strict";
(() => {
  if (window.top !== window || window.__CBL_LIVE_TIMER_TRIAL__) return;
  window.__CBL_LIVE_TIMER_TRIAL__ = true;
  const defaults = {timerEnabled:true,timerDirection:"down",timerDecimals:true,
    timerStyle:"ring",timerAnchor:"center",timerSize:120,timerOpacity:85,
    timerX:.5,timerY:.5,timerWidth:145,timerHeight:145,timerMoved:false,performanceMode:true};
  let ui={...defaults}, settings={}, runtime={}, dragging=false;
  let host=null, value=null, label=null, circle=null, saveTimer=null;
  const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
  const KEY="cblTrialUiOptions";

  function anchor() {
    const placements={center:[.5,.5],top:[.5,.16],bottom:[.5,.84],right:[.84,.5],left:[.16,.5]};
    return ui.timerMoved ? [ui.timerX,ui.timerY] :
      (placements[ui.timerAnchor] || placements.center);
  }
  function position() {
    if (!host) return;
    const [x,y]=anchor();
    const w=host.offsetWidth || ui.timerWidth;
    const h=host.offsetHeight || ui.timerHeight;
    host.style.left=`${clamp(x*innerWidth-w/2,4,Math.max(4,innerWidth-w-4))}px`;
    host.style.top=`${clamp(y*innerHeight-h/2,4,Math.max(4,innerHeight-h-4))}px`;
  }
  function appearance() {
    if (!host) return;
    host.hidden = !ui.timerEnabled || !settings.enabled ||
      !["running","opening","company","branch","branch_wait","confirm"].includes(runtime.phase);
    host.style.width=`${clamp(Number(ui.timerWidth)||145,105,320)}px`;
    host.style.height=`${clamp(Number(ui.timerHeight)||145,83,300)}px`;
    host.style.opacity=String(clamp((Number(ui.timerOpacity)||85)/100,.3,1));
    host.dataset.style=["ring","digital","pill"].includes(ui.timerStyle) ? ui.timerStyle : "ring";
    host.dataset.theme=ui.appearanceVersion===1 ? String(ui.theme || "ios-dark") :
      (["light","sand","ios-light"].includes(ui.theme) ? "ios-light" : "ios-dark");
    host.dataset.performance=ui.performanceMode ? "on" : "off";
    value.style.fontSize=`${Math.round(clamp(Number(ui.timerSize)||120,70,200)/120*32)}px`;
    position();tick();
  }
  function tick() {
    if (!host || host.hidden) return;
    const up=ui.timerDirection==="up";
    const start=Number(runtime.startedAt), next=Number(runtime.nextRefreshAt);
    const seconds=up ? (start?Math.max(0,(Date.now()-start)/1000):0) :
      (next?Math.max(0,(next-Date.now())/1000):0);
    value.textContent = (!up && !next) ? "—" : `${seconds.toFixed(ui.timerDecimals?1:0)}s`;
    label.textContent = up ? "منذ البدء" : next ? "للتحديث" : "بانتظار المرحلة";
    const interval=Math.max(.5,Number(runtime.phase==="branch_wait" ? settings.branchRefreshSeconds : settings.refreshSeconds)||5);
    const fraction=up?Math.min(1,(seconds%interval)/interval):Math.min(1,seconds/interval);
    circle.style.background=`conic-gradient(var(--timer-accent,#28e4ed) ${fraction*100}%,var(--timer-track,rgba(255,255,255,.13)) 0)`;
  }
  async function savePosition() {
    if (!host) return;
    const rect=host.getBoundingClientRect();
    const next={...ui,timerMoved:true,
      timerX:clamp((rect.left+rect.width/2)/innerWidth,0,1),
      timerY:clamp((rect.top+rect.height/2)/innerHeight,0,1),
      timerWidth:Math.round(rect.width),timerHeight:Math.round(rect.height)};
    ui=next;
    await chrome.storage.local.set({[KEY]:next});
  }
  function mount() {
    if (host || !document.body) return;
    host=document.createElement("div");
    host.id="cbl-live-timer-trial";
    host.style.cssText="position:fixed;z-index:2147483646;pointer-events:none;overflow:hidden;min-width:105px;min-height:83px;max-width:320px;max-height:300px;box-sizing:border-box;";
    const root=host.attachShadow({mode:"closed"});
    root.innerHTML=`<style>
      :host{--timer-accent:#28e4ed;--timer-track:rgba(255,255,255,.13)}
      *{box-sizing:border-box} .frame{height:100%;width:100%;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;color:#ecfdff;font-family:Arial,Tahoma,sans-serif;background:rgba(3,22,43,.88);border:1px solid #28d6ed;border-radius:24px;box-shadow:0 0 19px rgba(0,213,239,.38)}
      .ring{position:absolute;inset:7px;border-radius:50%;background:conic-gradient(var(--timer-accent) 30%,var(--timer-track) 0);padding:7px}
      .ring::after{content:"";display:block;width:100%;height:100%;border-radius:50%;background:#051b31}
      .inner{position:relative;z-index:1;text-align:center;white-space:nowrap}
      .time{font-weight:800;direction:ltr;line-height:1.1;letter-spacing:.5px}
      .label{font-size:10px;color:#a9daef;margin-top:4px}.live{display:inline-block;padding:2px 6px;border:1px solid #1dd6a0;border-radius:10px;color:#5cf5d0;font-size:9px;margin-top:5px}
      .handle{pointer-events:auto;position:absolute;top:5px;left:6px;z-index:3;cursor:grab;touch-action:none;color:#8feaff;font-size:16px;line-height:1;user-select:none}
      .handle:active{cursor:grabbing}
      .resize-handle{position:absolute;right:5px;bottom:5px;z-index:3;width:15px;height:15px;pointer-events:auto;cursor:nwse-resize;touch-action:none;color:#8feaff;line-height:15px;font-size:14px;user-select:none}
      :host([data-style="digital"]) .ring,:host([data-style="pill"]) .ring{display:none}
      :host([data-style="digital"]) .frame{border-radius:12px}
      :host([data-style="pill"]) .frame{border-radius:80px}
      :host([data-theme="ios-dark"]){--timer-accent:#34dfa4;--timer-track:rgba(125,172,155,.18)}
      :host([data-theme="ios-light"]){--timer-accent:#07875f;--timer-track:rgba(65,124,94,.12)}
      :host([data-theme="ios-dark"]) .frame,:host([data-theme="ios-light"]) .frame{padding:8px;border-radius:26px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,Tahoma,sans-serif}
      :host([data-theme="ios-dark"]) .frame{color:#f4faf9;background:linear-gradient(155deg,rgba(24,58,54,.98),rgba(7,23,25,.98));border:1px solid rgba(94,164,145,.3);box-shadow:0 6px 20px rgba(0,0,0,.19),inset 0 1px rgba(255,255,255,.035)}
      :host([data-theme="ios-light"]) .frame{color:#182b28;background:linear-gradient(155deg,rgba(255,255,255,.98),rgba(244,248,246,.98));border:1px solid #d9e2df;box-shadow:0 5px 20px rgba(37,68,50,.11),inset 0 1px #fff}
      :host([data-theme="ios-dark"]) .ring,:host([data-theme="ios-light"]) .ring{inset:9px;padding:4px}
      :host([data-theme="ios-dark"]) .ring::after{background:#102a29}
      :host([data-theme="ios-light"]) .ring::after{background:#fbfdfc}
      :host([data-theme="ios-dark"]) .time,:host([data-theme="ios-light"]) .time{font-weight:720;letter-spacing:-.8px;font-variant-numeric:tabular-nums}
      :host([data-theme="ios-dark"]) .label,:host([data-theme="ios-light"]) .label{margin-top:5px;line-height:1.35;font-size:10px}
      :host([data-theme="ios-dark"]) .label{color:#9db6b7}
      :host([data-theme="ios-light"]) .label{color:#687d77}
      :host([data-theme="ios-dark"]) .live,:host([data-theme="ios-light"]) .live{margin-top:5px;padding:2px 7px;border:0;border-radius:6px;font-size:8px;font-weight:650;letter-spacing:.5px}
      :host([data-theme="ios-dark"]) .live{color:#34dfa4;background:rgba(36,214,151,.12)}
      :host([data-theme="ios-light"]) .live{color:#07875f;background:#e3f6ed}
      :host([data-theme="ios-dark"]) .handle,:host([data-theme="ios-light"]) .handle{top:6px;left:6px;width:20px;height:20px;line-height:20px;text-align:center;font-size:14px;border-radius:6px}
      :host([data-theme="ios-dark"]) .handle,:host([data-theme="ios-dark"]) .resize-handle{color:#9db6b7}
      :host([data-theme="ios-light"]) .handle,:host([data-theme="ios-light"]) .resize-handle{color:#687d77}
      :host([data-theme="ios-dark"][data-style="digital"]) .frame,:host([data-theme="ios-light"][data-style="digital"]) .frame{border-radius:19px}
      :host([data-theme="ios-dark"][data-style="pill"]) .frame,:host([data-theme="ios-light"][data-style="pill"]) .frame{border-radius:60px}
      :host([data-performance="on"]) .frame{box-shadow:none}
    </style><div class="frame"><div class="ring"></div><div class="handle" aria-label="اسحب العداد">✥</div><div class="resize-handle" aria-label="تغيير حجم العداد">↘</div><div class="inner"><div class="time">—</div><div class="label">للتحديث</div><span class="live">LIVE</span></div></div>`;
    value=root.querySelector(".time"); label=root.querySelector(".label"); circle=root.querySelector(".ring");
    root.querySelector(".handle").addEventListener("pointerdown",event=>{
      dragging=true;
      const original={x:event.clientX,y:event.clientY,left:host.offsetLeft,top:host.offsetTop};
      const move=e=>{
        host.style.left=`${clamp(original.left+e.clientX-original.x,4,Math.max(4,innerWidth-host.offsetWidth-4))}px`;
        host.style.top=`${clamp(original.top+e.clientY-original.y,4,Math.max(4,innerHeight-host.offsetHeight-4))}px`;
      };
      const end=()=>{dragging=false;window.removeEventListener("pointermove",move);window.removeEventListener("pointerup",end);savePosition().catch(()=>{});};
      window.addEventListener("pointermove",move);window.addEventListener("pointerup",end,{once:true});
      event.preventDefault();
    });
    root.querySelector(".resize-handle").addEventListener("pointerdown",event=>{
      dragging=true;
      const original={x:event.clientX,y:event.clientY,width:host.offsetWidth,height:host.offsetHeight};
      const move=e=>{
        host.style.width=`${clamp(original.width+e.clientX-original.x,105,320)}px`;
        host.style.height=`${clamp(original.height+e.clientY-original.y,83,300)}px`;
      };
      const end=()=>{dragging=false;window.removeEventListener("pointermove",move);window.removeEventListener("pointerup",end);savePosition().catch(()=>{});};
      window.addEventListener("pointermove",move);window.addEventListener("pointerup",end,{once:true});
      event.preventDefault();
    });
    document.body.append(host);
    new ResizeObserver(()=>{
      if (dragging || !host || host.hidden) return;
      if (Math.abs(host.offsetWidth-Number(ui.timerWidth))<2 &&
          Math.abs(host.offsetHeight-Number(ui.timerHeight))<2) return;
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer=setTimeout(()=>savePosition().catch(()=>{}),350);
    }).observe(host);
    appearance();
  }
  chrome.storage.onChanged.addListener((changes,area)=>{
    if (area!=="local") return;
    if (changes[KEY]) ui={...defaults,...changes[KEY].newValue};
    if (changes.bookingSettings) settings=changes.bookingSettings.newValue || {};
    if (changes.bookingRuntime) runtime=changes.bookingRuntime.newValue || {};
    if (!dragging) appearance();
  });
  window.addEventListener("resize",position,{passive:true});
  chrome.storage.local.get([KEY,"bookingSettings","bookingRuntime"]).then(stored=>{
    ui={...defaults,...(stored[KEY] || {})};settings=stored.bookingSettings || {};
    runtime=stored.bookingRuntime || {};
    mount();setInterval(tick,ui.timerDecimals?100:250);
  }).catch(()=>{});
})();
